package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.AppDatabase
import com.example.data.local.DataSeeder
import com.example.data.repository.TradingRepository
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    private lateinit var database: AppDatabase
    private lateinit var repository: TradingRepository

    @Before
    fun setup() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        database = AppDatabase.getInstance(context)
        repository = TradingRepository(database)
        runBlocking {
            DataSeeder.seedInitialData(database)
        }
    }

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Kunal Trader", appName)
    }

    @Test
    fun `verify default demo user login`() = runBlocking {
        val result = repository.login("kunal@trader.demo", "1234")
        assertTrue(result.isSuccess)
        assertEquals("Kunal Sharma", result.getOrNull()?.fullName)
    }

    @Test
    fun `verify new user signup and demo capital credit`() = runBlocking {
        val result = repository.registerUser(
            fullName = "Test Trader",
            email = "trader_test@demo.com",
            phone = "9812345678",
            pin = "4321"
        )
        assertTrue(result.isSuccess)
        val user = result.getOrNull()
        assertTrue(user != null)

        val loginResult = repository.login("trader_test@demo.com", "4321")
        assertTrue(loginResult.isSuccess)
    }

    @Test
    fun `verify password reset flow`() = runBlocking {
        val resetResult = repository.resetPassword("kunal@trader.demo", "9988")
        assertTrue(resetResult.isSuccess)

        val oldLogin = repository.login("kunal@trader.demo", "1234")
        assertTrue(oldLogin.isFailure)

        val newLogin = repository.login("kunal@trader.demo", "9988")
        assertTrue(newLogin.isSuccess)
    }
}
