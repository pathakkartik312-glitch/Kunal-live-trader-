package com.example.ui.screens.admin

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entities.BankAccountEntity
import com.example.data.local.entities.InstrumentEntity
import com.example.data.local.entities.UserEntity
import com.example.ui.components.EmptyStateView
import com.example.ui.components.MetricCard
import com.example.ui.components.StatusBadge
import com.example.ui.components.formatInr
import com.example.ui.theme.TradeGreen
import com.example.ui.theme.TradeGreenLight
import com.example.ui.theme.TradeRed
import com.example.ui.theme.TradeRedLight
import com.example.ui.viewmodel.AdminViewModel
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminLoginScreen(
    viewModel: AdminViewModel,
    onLoginSuccess: () -> Unit,
    onNavigateBack: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()
    var pin by remember { mutableStateOf("9999") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Admin Authorization", fontSize = 18.sp, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .size(72.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.secondaryContainer),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.AdminPanelSettings,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.secondary,
                    modifier = Modifier.size(38.dp)
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            Text("Admin Control Console", fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text(
                "Authorized personnel only. Enter master PIN (Default: 9999)",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(24.dp))

            OutlinedTextField(
                value = pin,
                onValueChange = { if (it.length <= 4) pin = it },
                label = { Text("Master Admin PIN") },
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                modifier = Modifier.fillMaxWidth().testTag("admin_pin_input"),
                shape = RoundedCornerShape(12.dp),
                singleLine = true
            )

            if (uiState.error != null) {
                Spacer(modifier = Modifier.height(10.dp))
                Text(uiState.error ?: "", color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
            }

            Spacer(modifier = Modifier.height(24.dp))

            Button(
                onClick = {
                    viewModel.adminLogin(pin, onLoginSuccess)
                },
                enabled = pin.length >= 4 && !uiState.isLoading,
                modifier = Modifier.fillMaxWidth().height(50.dp).testTag("admin_login_submit_btn"),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("Authenticate as Administrator", fontSize = 15.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminDashboardScreen(
    viewModel: AdminViewModel,
    onNavigateUsers: () -> Unit,
    onNavigateKyc: () -> Unit,
    onNavigateDeposits: () -> Unit,
    onNavigateWithdrawals: () -> Unit,
    onNavigateBanks: () -> Unit,
    onNavigateInstruments: () -> Unit,
    onNavigateTrades: () -> Unit,
    onNavigateAudit: () -> Unit,
    onNavigateNotifications: () -> Unit,
    onLogout: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Admin Control Portal", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        Text("Kunal Trader Master Exchange Console", fontSize = 11.sp, color = MaterialTheme.colorScheme.primary)
                    }
                },
                actions = {
                    IconButton(onClick = onLogout, modifier = Modifier.testTag("admin_logout_btn")) {
                        Icon(Icons.Default.Logout, contentDescription = "Logout")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(16.dp)
        ) {
            // High level KPI Metrics
            item {
                Text("Operational Summary", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(10.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    MetricCard(
                        title = "Total Users",
                        value = "${uiState.users.size}",
                        icon = Icons.Default.People,
                        modifier = Modifier.weight(1f)
                    )
                    MetricCard(
                        title = "Open Positions",
                        value = "${uiState.allPositions.size}",
                        icon = Icons.Default.TrendingUp,
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    MetricCard(
                        title = "Pending KYC",
                        value = "${uiState.pendingKycUsers.size}",
                        subtitle = "Needs verification",
                        icon = Icons.Default.VerifiedUser,
                        modifier = Modifier.weight(1f)
                    )
                    MetricCard(
                        title = "Pending Deposits",
                        value = "${uiState.pendingDeposits.size}",
                        subtitle = "Needs clearance",
                        icon = Icons.Default.AccountBalanceWallet,
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    MetricCard(
                        title = "Pending Withdrawals",
                        value = "${uiState.pendingWithdrawals.size}",
                        subtitle = "Disbursement queue",
                        icon = Icons.Default.MoneyOff,
                        modifier = Modifier.weight(1f)
                    )
                    MetricCard(
                        title = "Audit Records",
                        value = "${uiState.auditLogs.size}",
                        subtitle = "Immutable ledger",
                        icon = Icons.Default.Security,
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            item { Spacer(modifier = Modifier.height(24.dp)) }

            // Management Navigation Modules
            item {
                Text("Management Modules", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(10.dp))

                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    AdminMenuCard(
                        icon = Icons.Default.Group,
                        title = "User Management",
                        subtitle = "Add, edit, block, deactivate users & view portfolios",
                        count = uiState.users.size,
                        onClick = onNavigateUsers,
                        testTag = "admin_menu_users"
                    )
                    AdminMenuCard(
                        icon = Icons.Default.VerifiedUser,
                        title = "KYC Verification",
                        subtitle = "Review and approve/reject submitted user documents",
                        count = uiState.pendingKycUsers.size,
                        highlight = uiState.pendingKycUsers.isNotEmpty(),
                        onClick = onNavigateKyc,
                        testTag = "admin_menu_kyc"
                    )
                    AdminMenuCard(
                        icon = Icons.Default.AddCard,
                        title = "Deposit Clearance",
                        subtitle = "Verify UTR references & credit virtual margins",
                        count = uiState.pendingDeposits.size,
                        highlight = uiState.pendingDeposits.isNotEmpty(),
                        onClick = onNavigateDeposits,
                        testTag = "admin_menu_deposits"
                    )
                    AdminMenuCard(
                        icon = Icons.Default.CreditCardOff,
                        title = "Withdrawal Disbursals",
                        subtitle = "Approve payouts or reject with user refund",
                        count = uiState.pendingWithdrawals.size,
                        highlight = uiState.pendingWithdrawals.isNotEmpty(),
                        onClick = onNavigateWithdrawals,
                        testTag = "admin_menu_withdrawals"
                    )
                    AdminMenuCard(
                        icon = Icons.Default.AccountBalance,
                        title = "Admin Deposit Banks & UPI",
                        subtitle = "Configure official bank accounts shown to users",
                        count = uiState.allBankAccounts.count { it.isAdminDepositBank },
                        onClick = onNavigateBanks,
                        testTag = "admin_menu_banks"
                    )
                    AdminMenuCard(
                        icon = Icons.Default.ShowChart,
                        title = "Market Instruments & LTP",
                        subtitle = "Configure indices, base prices, lot sizes & trading status",
                        count = uiState.allInstruments.size,
                        onClick = onNavigateInstruments,
                        testTag = "admin_menu_instruments"
                    )
                    AdminMenuCard(
                        icon = Icons.Default.ReceiptLong,
                        title = "Trade Surveillance & Correction",
                        subtitle = "Cancel pending orders, correct trades with audit reasons",
                        count = uiState.allOrders.size,
                        onClick = onNavigateTrades,
                        testTag = "admin_menu_trades"
                    )
                    AdminMenuCard(
                        icon = Icons.Default.Campaign,
                        title = "Broadcast Notification",
                        subtitle = "Dispatch real-time announcements to traders",
                        onClick = onNavigateNotifications,
                        testTag = "admin_menu_notifications"
                    )
                    AdminMenuCard(
                        icon = Icons.Default.Shield,
                        title = "Immutable Audit Ledger",
                        subtitle = "Track all administrative actions, timestamps & reasons",
                        count = uiState.auditLogs.size,
                        onClick = onNavigateAudit,
                        testTag = "admin_menu_audit"
                    )
                }
            }
        }
    }
}

@Composable
fun AdminMenuCard(
    icon: ImageVector,
    title: String,
    subtitle: String,
    count: Int? = null,
    highlight: Boolean = false,
    onClick: () -> Unit,
    testTag: String = ""
) {
    Card(
        onClick = onClick,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.fillMaxWidth().testTag(testTag)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (highlight) MaterialTheme.colorScheme.errorContainer else MaterialTheme.colorScheme.primaryContainer),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = if (highlight) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(22.dp)
                    )
                }

                Column {
                    Text(title, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                    Text(subtitle, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                if (count != null) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (highlight) TradeRed else MaterialTheme.colorScheme.surfaceVariant)
                            .padding(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "$count",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (highlight) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                Icon(Icons.Default.ChevronRight, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

// User Management Screen
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminUsersScreen(
    viewModel: AdminViewModel,
    onSelectUser: (UserEntity) -> Unit,
    onNavigateBack: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()
    var showAddUserDialog by remember { mutableStateOf(false) }

    var fullName by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var pin by remember { mutableStateOf("1234") }
    var role by remember { mutableStateOf("USER") }
    var initialMargin by remember { mutableStateOf("500000") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("User Management (${uiState.users.size})", fontSize = 18.sp, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = { showAddUserDialog = true }, modifier = Modifier.testTag("admin_add_user_btn")) {
                        Icon(Icons.Default.PersonAdd, contentDescription = "Add User")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(16.dp)
        ) {
            items(uiState.users, key = { it.id }) { user ->
                Card(
                    onClick = { onSelectUser(user) },
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp).testTag("user_item_${user.id}"),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text(user.fullName, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                                if (user.role == "ADMIN") {
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(MaterialTheme.colorScheme.secondaryContainer)
                                            .padding(horizontal = 4.dp, vertical = 1.dp)
                                    ) {
                                        Text("ADMIN", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.secondary)
                                    }
                                }
                            }
                            Text("ID: #${user.id} • ${user.email} • ${user.phone}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            StatusBadge(status = user.status)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("KYC: ${user.kycStatus}", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
    }

    if (showAddUserDialog) {
        AlertDialog(
            onDismissRequest = { showAddUserDialog = false },
            title = { Text("Add New Demo User") },
            text = {
                Column(
                    modifier = Modifier.verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(
                        value = fullName,
                        onValueChange = { fullName = it },
                        label = { Text("Full Name") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = email,
                        onValueChange = { email = it },
                        label = { Text("Email") },
                        modifier = Modifier.fillMaxWidth(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email)
                    )
                    OutlinedTextField(
                        value = phone,
                        onValueChange = { phone = it },
                        label = { Text("Phone") },
                        modifier = Modifier.fillMaxWidth(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone)
                    )
                    OutlinedTextField(
                        value = pin,
                        onValueChange = { if (it.length <= 4) pin = it },
                        label = { Text("4-Digit PIN") },
                        modifier = Modifier.fillMaxWidth(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword)
                    )
                    OutlinedTextField(
                        value = initialMargin,
                        onValueChange = { initialMargin = it },
                        label = { Text("Initial Demo Margin (₹)") },
                        modifier = Modifier.fillMaxWidth(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (fullName.isNotBlank() && email.isNotBlank()) {
                            viewModel.addUser(
                                fullName = fullName,
                                email = email,
                                phone = phone,
                                pin = pin,
                                role = role,
                                initialMargin = initialMargin.toDoubleOrNull() ?: 500000.0
                            )
                            showAddUserDialog = false
                        }
                    }
                ) {
                    Text("Create User")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddUserDialog = false }) { Text("Cancel") }
            }
        )
    }
}

// User Detail & Portfolio View Screen
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminUserDetailScreen(
    viewModel: AdminViewModel,
    onNavigateBack: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()
    val user = uiState.selectedUser

    var showActionDialog by remember { mutableStateOf<String?>(null) } // "BLOCK", "UNBLOCK", "DEACTIVATE", "DELETE", "ADD_TRADE"
    var actionReason by remember { mutableStateOf("") }

    var editingOrder by remember { mutableStateOf<com.example.data.local.entities.OrderEntity?>(null) }
    var editPriceText by remember { mutableStateOf("") }
    var editQtyText by remember { mutableStateOf("") }
    var editStatusText by remember { mutableStateOf("EXECUTED") }
    var editReasonText by remember { mutableStateOf("") }

    var deletingOrder by remember { mutableStateOf<com.example.data.local.entities.OrderEntity?>(null) }
    var deleteAuditReason by remember { mutableStateOf("") }

    // Add Trade state variables
    var addSegment by remember { mutableStateOf("Stock") }
    var addSymbol by remember { mutableStateOf("RELIANCE") }
    var addName by remember { mutableStateOf("Reliance Industries Ltd") }
    var addSide by remember { mutableStateOf("BUY") }
    var addOrderType by remember { mutableStateOf("MARKET") }
    var addProductType by remember { mutableStateOf("CNC") }
    var addQtyText by remember { mutableStateOf("10") }
    var addPriceText by remember { mutableStateOf("2845.50") }
    var addStrikeText by remember { mutableStateOf("") }
    var addOptionType by remember { mutableStateOf("CE") }
    var addExpiryText by remember { mutableStateOf("28 MAR") }
    var addLotSizeText by remember { mutableStateOf("1") }
    var addNotesText by remember { mutableStateOf("Admin simulated test trade") }
    var addStatus by remember { mutableStateOf("EXECUTED") }

    if (user == null) {
        onNavigateBack()
        return
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("User: ${user.fullName}", fontSize = 18.sp, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(16.dp)
        ) {
            // Profile and Status Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(user.fullName, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                                Text("ID: #${user.id} • ${user.email} • ${user.phone}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            StatusBadge(status = user.status)
                        }

                        Spacer(modifier = Modifier.height(12.dp))
                        Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
                        Spacer(modifier = Modifier.height(10.dp))

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column {
                                Text("Available Margin", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(formatInr(uiState.selectedUserWallet?.availableMargin ?: 0.0), fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TradeGreen)
                            }
                            Column {
                                Text("Used Margin", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(formatInr(uiState.selectedUserWallet?.usedMargin ?: 0.0), fontSize = 14.sp, fontWeight = FontWeight.Bold)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("Realized P&L", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(formatInr(uiState.selectedUserWallet?.realizedPnl ?: 0.0, showSign = true), fontSize = 14.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            // User Management Actions
            item {
                Spacer(modifier = Modifier.height(14.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (user.status == "ACTIVE") {
                        Button(
                            onClick = { showActionDialog = "BLOCK" },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = TradeRed),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("Block User", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    } else {
                        Button(
                            onClick = { showActionDialog = "UNBLOCK" },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = TradeGreen),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("Unblock User", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    OutlinedButton(
                        onClick = { showActionDialog = "DELETE" },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = TradeRed),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Delete Demo User", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Button(
                    onClick = { showActionDialog = "ADD_TRADE" },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(Icons.Default.AddCircle, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Add Simulated Trade For User", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }
            }

            // User Orders & Trades
            item {
                Spacer(modifier = Modifier.height(20.dp))
                Text("User Orders & Trade History (${uiState.selectedUserOrders.size})", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(8.dp))
            }

            if (uiState.selectedUserOrders.isEmpty()) {
                item { Text("No orders or trades on this account.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }
            } else {
                items(uiState.selectedUserOrders, key = { it.id }) { ord ->
                    Card(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("${ord.side} ${ord.quantity} Qty • ${ord.symbol}", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                StatusBadge(status = ord.status)
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("Price: ₹${ord.price} • Type: ${ord.orderType} • Product: ${ord.productType} • Segment: ${ord.segment}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)

                            Spacer(modifier = Modifier.height(8.dp))

                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                if (ord.status == "PENDING") {
                                    OutlinedButton(
                                        onClick = { viewModel.adminCancelOrder(ord.id, "Admin order cancellation") },
                                        modifier = Modifier.weight(1f).height(32.dp),
                                        colors = ButtonDefaults.outlinedButtonColors(contentColor = TradeRed),
                                        shape = RoundedCornerShape(6.dp)
                                    ) {
                                        Text("Cancel Order", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                }

                                OutlinedButton(
                                    onClick = {
                                        editingOrder = ord
                                        editPriceText = ord.price.toString()
                                        editQtyText = ord.quantity.toString()
                                        editStatusText = ord.status
                                        editReasonText = ""
                                    },
                                    modifier = Modifier.weight(1f).height(32.dp),
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Text("Edit Trade", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }

                                OutlinedButton(
                                    onClick = {
                                        deletingOrder = ord
                                        deleteAuditReason = ""
                                    },
                                    modifier = Modifier.weight(1f).height(32.dp),
                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = TradeRed),
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Text("Delete Trade", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }

            // User Open Positions
            item {
                Spacer(modifier = Modifier.height(20.dp))
                Text("Open Positions (${uiState.selectedUserPositions.size})", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(8.dp))
            }

            if (uiState.selectedUserPositions.isEmpty()) {
                item { Text("No active positions for this user.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }
            } else {
                items(uiState.selectedUserPositions) { pos ->
                    Card(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Row(modifier = Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("${pos.side} ${pos.quantity} Qty • ${pos.symbol}", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            Text(formatInr(pos.pnl, showSign = true), fontSize = 13.sp, fontWeight = FontWeight.Bold, color = if (pos.pnl >= 0) TradeGreen else TradeRed)
                        }
                    }
                }
            }

            // User Holdings
            item {
                Spacer(modifier = Modifier.height(16.dp))
                Text("Holdings (${uiState.selectedUserHoldings.size})", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(8.dp))
            }

            if (uiState.selectedUserHoldings.isEmpty()) {
                item { Text("No demat holdings for this user.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }
            } else {
                items(uiState.selectedUserHoldings) { h ->
                    Card(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Row(modifier = Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("${h.symbol} (${h.quantity} Qty)", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            Text(formatInr(h.currentValue), fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }

    if (showActionDialog != null && showActionDialog != "ADD_TRADE") {
        val action = showActionDialog!!
        AlertDialog(
            onDismissRequest = { showActionDialog = null },
            title = { Text("Confirm $action") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Are you sure you want to $action user ${user.fullName}?")
                    OutlinedTextField(
                        value = actionReason,
                        onValueChange = { actionReason = it },
                        label = { Text("Mandatory Reason / Audit Remark") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val reason = actionReason.ifBlank { "Administrative operation" }
                        when (action) {
                            "BLOCK" -> viewModel.updateUserStatus(user, "BLOCKED", reason)
                            "UNBLOCK" -> viewModel.updateUserStatus(user, "ACTIVE", reason)
                            "DELETE" -> {
                                viewModel.deleteUser(user.id, reason)
                                onNavigateBack()
                            }
                        }
                        showActionDialog = null
                    }
                ) {
                    Text("Confirm")
                }
            },
            dismissButton = {
                TextButton(onClick = { showActionDialog = null }) { Text("Cancel") }
            }
        )
    }

    // Add Trade Dialog
    if (showActionDialog == "ADD_TRADE") {
        val segments = listOf("Stock", "Index", "Stock Option", "Index Option", "Commodity", "Commodity Option")
        val sides = listOf("BUY", "SELL")
        val orderTypes = listOf("MARKET", "LIMIT", "SL")
        val productTypes = listOf("CNC", "INTRADAY", "NRML")
        val statuses = listOf("EXECUTED", "PENDING")

        AlertDialog(
            onDismissRequest = { showActionDialog = null },
            title = { Text("Add Trade for ${user.fullName}") },
            text = {
                Column(
                    modifier = Modifier.verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text("Segment", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        segments.take(3).forEach { seg ->
                            FilterChip(
                                selected = addSegment == seg,
                                onClick = { addSegment = seg },
                                label = { Text(seg, fontSize = 10.sp) }
                            )
                        }
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        segments.drop(3).forEach { seg ->
                            FilterChip(
                                selected = addSegment == seg,
                                onClick = { addSegment = seg },
                                label = { Text(seg, fontSize = 10.sp) }
                            )
                        }
                    }

                    OutlinedTextField(
                        value = addSymbol,
                        onValueChange = { addSymbol = it.uppercase() },
                        label = { Text("Instrument / Symbol") },
                        placeholder = { Text("e.g. RELIANCE, NIFTY, GOLD, CRUDEOIL") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = addName,
                        onValueChange = { addName = it },
                        label = { Text("Instrument Name") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Side", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                sides.forEach { s ->
                                    FilterChip(
                                        selected = addSide == s,
                                        onClick = { addSide = s },
                                        label = { Text(s, fontSize = 11.sp) }
                                    )
                                }
                            }
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Status", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                statuses.forEach { st ->
                                    FilterChip(
                                        selected = addStatus == st,
                                        onClick = { addStatus = st },
                                        label = { Text(st, fontSize = 10.sp) }
                                    )
                                }
                            }
                        }
                    }

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = addQtyText,
                            onValueChange = { addQtyText = it },
                            label = { Text("Quantity") },
                            modifier = Modifier.weight(1f),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                        )
                        OutlinedTextField(
                            value = addPriceText,
                            onValueChange = { addPriceText = it },
                            label = { Text("Price (₹)") },
                            modifier = Modifier.weight(1f),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
                        )
                    }

                    if (addSegment.contains("Option", ignoreCase = true)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = addStrikeText,
                                onValueChange = { addStrikeText = it },
                                label = { Text("Strike Price") },
                                modifier = Modifier.weight(1f),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                            )
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Option Type", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    listOf("CE", "PE").forEach { ot ->
                                        FilterChip(
                                            selected = addOptionType == ot,
                                            onClick = { addOptionType = ot },
                                            label = { Text(ot, fontSize = 11.sp) }
                                        )
                                    }
                                }
                            }
                        }
                        OutlinedTextField(
                            value = addExpiryText,
                            onValueChange = { addExpiryText = it },
                            label = { Text("Expiry (e.g. 28 MAR)") },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    OutlinedTextField(
                        value = addNotesText,
                        onValueChange = { addNotesText = it },
                        label = { Text("Notes / Reason") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val qty = addQtyText.toIntOrNull() ?: 1
                        val prc = addPriceText.toDoubleOrNull() ?: 100.0
                        val strike = addStrikeText.toDoubleOrNull()
                        val isOpt = addSegment.contains("Option", ignoreCase = true)

                        viewModel.adminPlaceTradeForUser(
                            targetUserId = user.id,
                            segment = addSegment,
                            symbol = addSymbol.ifBlank { "RELIANCE" },
                            name = addName.ifBlank { addSymbol },
                            side = addSide,
                            orderType = addOrderType,
                            productType = addProductType,
                            quantity = qty,
                            price = prc,
                            strikePrice = if (isOpt) strike else null,
                            optionType = if (isOpt) addOptionType else null,
                            expiry = if (isOpt) addExpiryText else null,
                            lotSize = addLotSizeText.toIntOrNull() ?: 1,
                            notes = addNotesText,
                            status = addStatus
                        )
                        showActionDialog = null
                    }
                ) {
                    Text("Place User Trade")
                }
            },
            dismissButton = {
                TextButton(onClick = { showActionDialog = null }) { Text("Cancel") }
            }
        )
    }

    // Edit Trade Dialog
    if (editingOrder != null) {
        val ord = editingOrder!!
        AlertDialog(
            onDismissRequest = { editingOrder = null },
            title = { Text("Edit Trade #${ord.id} (${ord.symbol})") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = editQtyText,
                        onValueChange = { editQtyText = it },
                        label = { Text("Quantity") },
                        modifier = Modifier.fillMaxWidth(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                    )
                    OutlinedTextField(
                        value = editPriceText,
                        onValueChange = { editPriceText = it },
                        label = { Text("Execution Price (₹)") },
                        modifier = Modifier.fillMaxWidth(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        listOf("EXECUTED", "PENDING", "CANCELLED").forEach { st ->
                            FilterChip(
                                selected = editStatusText == st,
                                onClick = { editStatusText = st },
                                label = { Text(st, fontSize = 11.sp) }
                            )
                        }
                    }
                    OutlinedTextField(
                        value = editReasonText,
                        onValueChange = { editReasonText = it },
                        label = { Text("Reason for Modification") },
                        placeholder = { Text("e.g. Price adjustment, broker correction") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val p = editPriceText.toDoubleOrNull() ?: ord.price
                        val q = editQtyText.toIntOrNull() ?: ord.quantity
                        viewModel.adminEditTrade(
                            orderId = ord.id,
                            newPrice = p,
                            newQuantity = q,
                            newStatus = editStatusText,
                            reason = editReasonText.ifBlank { "Admin corrected trade parameters" }
                        )
                        editingOrder = null
                    }
                ) {
                    Text("Save Changes")
                }
            },
            dismissButton = {
                TextButton(onClick = { editingOrder = null }) { Text("Cancel") }
            }
        )
    }

    // Delete Trade Confirmation Dialog
    if (deletingOrder != null) {
        val ord = deletingOrder!!
        AlertDialog(
            onDismissRequest = { deletingOrder = null },
            title = { Text("Remove Trade #${ord.id}") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Are you sure you want to remove this trade?",
                        fontWeight = FontWeight.Bold,
                        color = TradeRed,
                        fontSize = 14.sp
                    )
                    Text("This action will recalculate the demo portfolio, positions, and P&L for ${user.fullName}.")
                    OutlinedTextField(
                        value = deleteAuditReason,
                        onValueChange = { deleteAuditReason = it },
                        label = { Text("Mandatory Audit Reason") },
                        placeholder = { Text("e.g. Duplicate order, user test trade cleanup") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.adminDeleteOrCorrectTrade(
                            orderId = ord.id,
                            auditReason = deleteAuditReason.ifBlank { "Trade deletion by administrator" }
                        )
                        deletingOrder = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = TradeRed)
                ) {
                    Text("Confirm Delete")
                }
            },
            dismissButton = {
                TextButton(onClick = { deletingOrder = null }) { Text("Cancel") }
            }
        )
    }
}

// KYC Verification Screen
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminKycScreen(
    viewModel: AdminViewModel,
    onNavigateBack: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()
    var selectedUserForReject by remember { mutableStateOf<UserEntity?>(null) }
    var rejectRemarks by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Pending KYC Approvals (${uiState.pendingKycUsers.size})", fontSize = 18.sp, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        if (uiState.pendingKycUsers.isEmpty()) {
            EmptyStateView(
                icon = Icons.Default.VerifiedUser,
                title = "No Pending KYC",
                subtitle = "All submitted documents have been reviewed!"
            )
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding),
                contentPadding = PaddingValues(16.dp)
            ) {
                items(uiState.pendingKycUsers, key = { it.id }) { user ->
                    Card(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(user.fullName, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                                StatusBadge(status = "KYC PENDING")
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("Email: ${user.email} • Phone: ${user.phone}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("Document: PAN/Aadhaar Proof Submitted", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary)

                            Spacer(modifier = Modifier.height(12.dp))

                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(
                                    onClick = { viewModel.verifyKyc(user.id, "VERIFIED", "Approved by KYC Administrator") },
                                    modifier = Modifier.weight(1f).height(40.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = TradeGreen),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text("Approve KYC", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }

                                OutlinedButton(
                                    onClick = { selectedUserForReject = user },
                                    modifier = Modifier.weight(1f).height(40.dp),
                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = TradeRed),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text("Reject", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (selectedUserForReject != null) {
        AlertDialog(
            onDismissRequest = { selectedUserForReject = null },
            title = { Text("Reject KYC Application") },
            text = {
                OutlinedTextField(
                    value = rejectRemarks,
                    onValueChange = { rejectRemarks = it },
                    label = { Text("Rejection Remarks") },
                    placeholder = { Text("e.g. Blurry ID proof, name mismatch") },
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.verifyKyc(selectedUserForReject!!.id, "REJECTED", rejectRemarks.ifBlank { "Document unreadable" })
                        selectedUserForReject = null
                    }
                ) {
                    Text("Confirm Reject")
                }
            },
            dismissButton = {
                TextButton(onClick = { selectedUserForReject = null }) { Text("Cancel") }
            }
        )
    }
}

// Deposit Clearance Screen
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminDepositsScreen(
    viewModel: AdminViewModel,
    onNavigateBack: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Deposit Clearance Queue (${uiState.pendingDeposits.size})", fontSize = 18.sp, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        if (uiState.pendingDeposits.isEmpty()) {
            EmptyStateView(
                icon = Icons.Default.CheckCircle,
                title = "No Pending Deposits",
                subtitle = "All virtual funds deposit requests have been cleared!"
            )
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding),
                contentPadding = PaddingValues(16.dp)
            ) {
                items(uiState.pendingDeposits, key = { it.id }) { tx ->
                    Card(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Deposit Request #${tx.id}", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                Text(formatInr(tx.amount), fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, color = TradeGreen)
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("User ID: #${tx.userId} • Bank: ${tx.bankAccount}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("UTR / Ref: ${tx.utrOrRef}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)

                            Spacer(modifier = Modifier.height(12.dp))

                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(
                                    onClick = { viewModel.approveDeposit(tx.id, "Verified UTR on banking portal") },
                                    modifier = Modifier.weight(1f).height(40.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = TradeGreen),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text("Approve & Credit", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }

                                OutlinedButton(
                                    onClick = { viewModel.rejectDeposit(tx.id, "Invalid UTR reference") },
                                    modifier = Modifier.weight(1f).height(40.dp),
                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = TradeRed),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text("Reject", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// Withdrawal Disbursal Screen
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminWithdrawalsScreen(
    viewModel: AdminViewModel,
    onNavigateBack: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Withdrawal Disbursals (${uiState.pendingWithdrawals.size})", fontSize = 18.sp, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        if (uiState.pendingWithdrawals.isEmpty()) {
            EmptyStateView(
                icon = Icons.Default.CheckCircle,
                title = "No Pending Withdrawals",
                subtitle = "All withdrawal requests have been processed!"
            )
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding),
                contentPadding = PaddingValues(16.dp)
            ) {
                items(uiState.pendingWithdrawals, key = { it.id }) { tx ->
                    Card(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Withdrawal #${tx.id}", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                Text(formatInr(tx.amount), fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, color = TradeRed)
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("User ID: #${tx.userId} • Destination: ${tx.bankAccount}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)

                            Spacer(modifier = Modifier.height(12.dp))

                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(
                                    onClick = { viewModel.approveWithdrawal(tx.id, "Disbursed via IMPS batch") },
                                    modifier = Modifier.weight(1f).height(40.dp),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text("Mark Disbursed", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }

                                OutlinedButton(
                                    onClick = { viewModel.rejectWithdrawal(tx.id, "Bank account details mismatch") },
                                    modifier = Modifier.weight(1f).height(40.dp),
                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = TradeRed),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text("Reject & Refund", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// Admin Banks Screen
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminBanksScreen(
    viewModel: AdminViewModel,
    onNavigateBack: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()
    var showAddDialog by remember { mutableStateOf(false) }

    var bankName by remember { mutableStateOf("") }
    var accountNumber by remember { mutableStateOf("") }
    var ifsc by remember { mutableStateOf("") }
    var holder by remember { mutableStateOf("KUNAL TRADER CLEARING CORP") }
    var upi by remember { mutableStateOf("") }

    val adminBanks = uiState.allBankAccounts.filter { it.isAdminDepositBank }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Admin Deposit Bank Accounts", fontSize = 18.sp, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = { showAddDialog = true }) {
                        Icon(Icons.Default.Add, contentDescription = "Add Admin Bank")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(16.dp)
        ) {
            items(adminBanks, key = { it.id }) { b ->
                Card(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(b.bankName, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                            Text("A/C: ${b.accountNumber} • IFSC: ${b.ifsc}", fontSize = 12.sp)
                            Text("Holder: ${b.accountHolder}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            if (b.upiId.isNotBlank()) {
                                Text("UPI: ${b.upiId}", fontSize = 11.sp, color = TradeGreen, fontWeight = FontWeight.Bold)
                            }
                        }
                        IconButton(onClick = { viewModel.deleteAdminBank(b.id) }) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete", tint = TradeRed)
                        }
                    }
                }
            }
        }
    }

    if (showAddDialog) {
        AlertDialog(
            onDismissRequest = { showAddDialog = false },
            title = { Text("Add Official Deposit Bank") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = bankName, onValueChange = { bankName = it }, label = { Text("Bank Name") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = accountNumber, onValueChange = { accountNumber = it }, label = { Text("Account Number") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = ifsc, onValueChange = { ifsc = it.uppercase() }, label = { Text("IFSC") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = holder, onValueChange = { holder = it }, label = { Text("Account Holder") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = upi, onValueChange = { upi = it }, label = { Text("UPI ID") }, modifier = Modifier.fillMaxWidth())
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (bankName.isNotBlank() && accountNumber.isNotBlank()) {
                            viewModel.addAdminBank(bankName, accountNumber, ifsc, holder, upi)
                            showAddDialog = false
                        }
                    }
                ) {
                    Text("Save")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddDialog = false }) { Text("Cancel") }
            }
        )
    }
}

// Admin Instruments & LTP Screen
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminInstrumentsScreen(
    viewModel: AdminViewModel,
    onNavigateBack: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()
    var editingInstrument by remember { mutableStateOf<InstrumentEntity?>(null) }
    var ltpText by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Instruments & Base Prices (${uiState.allInstruments.size})", fontSize = 18.sp, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(16.dp)
        ) {
            items(uiState.allInstruments, key = { it.symbol }) { inst ->
                Card(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(inst.symbol, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                            Text("${inst.name} • ${inst.segment}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }

                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Column(horizontalAlignment = Alignment.End) {
                                Text(formatInr(inst.ltp), fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                Text("Lot: ${inst.lotSize}", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            IconButton(onClick = {
                                editingInstrument = inst
                                ltpText = "${inst.ltp}"
                            }) {
                                Icon(Icons.Default.Edit, contentDescription = "Edit Price")
                            }
                        }
                    }
                }
            }
        }
    }

    if (editingInstrument != null) {
        AlertDialog(
            onDismissRequest = { editingInstrument = null },
            title = { Text("Update Price: ${editingInstrument!!.symbol}") },
            text = {
                OutlinedTextField(
                    value = ltpText,
                    onValueChange = { ltpText = it },
                    label = { Text("Base Price (LTP)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        val newPrice = ltpText.toDoubleOrNull() ?: editingInstrument!!.ltp
                        viewModel.saveInstrument(editingInstrument!!.copy(ltp = newPrice))
                        editingInstrument = null
                    }
                ) {
                    Text("Save Price")
                }
            },
            dismissButton = {
                TextButton(onClick = { editingInstrument = null }) { Text("Cancel") }
            }
        )
    }
}

// Admin Trade Surveillance & Deletion Screen
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminTradesScreen(
    viewModel: AdminViewModel,
    onNavigateBack: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()
    var selectedOrderForAuditAction by remember { mutableStateOf<com.example.data.local.entities.OrderEntity?>(null) }
    var auditReasonText by remember { mutableStateOf("") }

    var editingTrade by remember { mutableStateOf<com.example.data.local.entities.OrderEntity?>(null) }
    var editPriceText by remember { mutableStateOf("") }
    var editQtyText by remember { mutableStateOf("") }
    var editStatusText by remember { mutableStateOf("EXECUTED") }
    var editReasonText by remember { mutableStateOf("") }

    var showAddTradeDialog by remember { mutableStateOf(false) }
    var selectedUserForAdd by remember { mutableStateOf<Long>(1L) }
    var addSegment by remember { mutableStateOf("Stock") }
    var addSymbol by remember { mutableStateOf("RELIANCE") }
    var addName by remember { mutableStateOf("Reliance Industries Ltd") }
    var addSide by remember { mutableStateOf("BUY") }
    var addOrderType by remember { mutableStateOf("MARKET") }
    var addProductType by remember { mutableStateOf("CNC") }
    var addQtyText by remember { mutableStateOf("10") }
    var addPriceText by remember { mutableStateOf("2845.50") }
    var addStrikeText by remember { mutableStateOf("") }
    var addOptionType by remember { mutableStateOf("CE") }
    var addExpiryText by remember { mutableStateOf("28 MAR") }
    var addNotesText by remember { mutableStateOf("Admin simulated test trade") }
    var addStatus by remember { mutableStateOf("EXECUTED") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Trade Surveillance (${uiState.allOrders.size})", fontSize = 18.sp, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = { showAddTradeDialog = true }) {
                        Icon(Icons.Default.AddCircle, contentDescription = "Add Trade", tint = MaterialTheme.colorScheme.primary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(16.dp)
        ) {
            items(uiState.allOrders, key = { it.id }) { order ->
                Card(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Trade #${order.id} • User #${order.userId}", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            StatusBadge(status = order.status)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("${order.side} ${order.quantity} Qty • ${order.symbol} @ ₹${order.price} (${order.productType} • ${order.segment})", fontSize = 12.sp)

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            if (order.status == "PENDING") {
                                OutlinedButton(
                                    onClick = { viewModel.adminCancelOrder(order.id, "Surveillance force cancel") },
                                    modifier = Modifier.weight(1f).height(32.dp),
                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = TradeRed),
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Text("Cancel", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }

                            OutlinedButton(
                                onClick = {
                                    editingTrade = order
                                    editPriceText = order.price.toString()
                                    editQtyText = order.quantity.toString()
                                    editStatusText = order.status
                                    editReasonText = ""
                                },
                                modifier = Modifier.weight(1f).height(32.dp),
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text("Edit", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }

                            OutlinedButton(
                                onClick = {
                                    selectedOrderForAuditAction = order
                                    auditReasonText = ""
                                },
                                modifier = Modifier.weight(1f).height(32.dp),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = TradeRed),
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text("Delete Trade", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }

    if (selectedOrderForAuditAction != null) {
        val ord = selectedOrderForAuditAction!!
        AlertDialog(
            onDismissRequest = { selectedOrderForAuditAction = null },
            title = { Text("Remove Trade #${ord.id}") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Are you sure you want to remove this trade?",
                        fontWeight = FontWeight.Bold,
                        color = TradeRed,
                        fontSize = 14.sp
                    )
                    Text("Symbol: ${ord.symbol} (${ord.side} ${ord.quantity} Qty @ ₹${ord.price}) for User #${ord.userId}.")
                    OutlinedTextField(
                        value = auditReasonText,
                        onValueChange = { auditReasonText = it },
                        label = { Text("Mandatory Audit Reason") },
                        placeholder = { Text("e.g. Test cleanup, trade reconciliation") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val reason = auditReasonText.ifBlank { "Surveillance trade deletion" }
                        viewModel.adminDeleteOrCorrectTrade(ord.id, reason)
                        selectedOrderForAuditAction = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = TradeRed)
                ) {
                    Text("Confirm Delete")
                }
            },
            dismissButton = {
                TextButton(onClick = { selectedOrderForAuditAction = null }) { Text("Cancel") }
            }
        )
    }

    if (editingTrade != null) {
        val ord = editingTrade!!
        AlertDialog(
            onDismissRequest = { editingTrade = null },
            title = { Text("Edit Trade #${ord.id}") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = editQtyText,
                        onValueChange = { editQtyText = it },
                        label = { Text("Quantity") },
                        modifier = Modifier.fillMaxWidth(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                    )
                    OutlinedTextField(
                        value = editPriceText,
                        onValueChange = { editPriceText = it },
                        label = { Text("Price (₹)") },
                        modifier = Modifier.fillMaxWidth(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        listOf("EXECUTED", "PENDING", "CANCELLED").forEach { st ->
                            FilterChip(
                                selected = editStatusText == st,
                                onClick = { editStatusText = st },
                                label = { Text(st, fontSize = 11.sp) }
                            )
                        }
                    }
                    OutlinedTextField(
                        value = editReasonText,
                        onValueChange = { editReasonText = it },
                        label = { Text("Modification Reason") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val p = editPriceText.toDoubleOrNull() ?: ord.price
                        val q = editQtyText.toIntOrNull() ?: ord.quantity
                        viewModel.adminEditTrade(
                            orderId = ord.id,
                            newPrice = p,
                            newQuantity = q,
                            newStatus = editStatusText,
                            reason = editReasonText.ifBlank { "Admin modified trade parameters" }
                        )
                        editingTrade = null
                    }
                ) {
                    Text("Save Changes")
                }
            },
            dismissButton = {
                TextButton(onClick = { editingTrade = null }) { Text("Cancel") }
            }
        )
    }

    if (showAddTradeDialog) {
        val segments = listOf("Stock", "Index", "Stock Option", "Index Option", "Commodity", "Commodity Option")
        val sides = listOf("BUY", "SELL")
        val statuses = listOf("EXECUTED", "PENDING")

        AlertDialog(
            onDismissRequest = { showAddTradeDialog = false },
            title = { Text("Place Trade for User") },
            text = {
                Column(
                    modifier = Modifier.verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text("Select Target User", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    val traderUsers = uiState.users.filter { it.role == "USER" }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        traderUsers.forEach { u ->
                            FilterChip(
                                selected = selectedUserForAdd == u.id,
                                onClick = { selectedUserForAdd = u.id },
                                label = { Text("${u.fullName} (#${u.id})", fontSize = 10.sp) }
                            )
                        }
                    }

                    Text("Segment", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        segments.take(3).forEach { seg ->
                            FilterChip(
                                selected = addSegment == seg,
                                onClick = { addSegment = seg },
                                label = { Text(seg, fontSize = 10.sp) }
                            )
                        }
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        segments.drop(3).forEach { seg ->
                            FilterChip(
                                selected = addSegment == seg,
                                onClick = { addSegment = seg },
                                label = { Text(seg, fontSize = 10.sp) }
                            )
                        }
                    }

                    OutlinedTextField(
                        value = addSymbol,
                        onValueChange = { addSymbol = it.uppercase() },
                        label = { Text("Symbol / Instrument") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = addName,
                        onValueChange = { addName = it },
                        label = { Text("Instrument Name") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Side", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                sides.forEach { s ->
                                    FilterChip(
                                        selected = addSide == s,
                                        onClick = { addSide = s },
                                        label = { Text(s, fontSize = 11.sp) }
                                    )
                                }
                            }
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Status", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                statuses.forEach { st ->
                                    FilterChip(
                                        selected = addStatus == st,
                                        onClick = { addStatus = st },
                                        label = { Text(st, fontSize = 10.sp) }
                                    )
                                }
                            }
                        }
                    }

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = addQtyText,
                            onValueChange = { addQtyText = it },
                            label = { Text("Quantity") },
                            modifier = Modifier.weight(1f),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                        )
                        OutlinedTextField(
                            value = addPriceText,
                            onValueChange = { addPriceText = it },
                            label = { Text("Price (₹)") },
                            modifier = Modifier.weight(1f),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
                        )
                    }

                    if (addSegment.contains("Option", ignoreCase = true)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = addStrikeText,
                                onValueChange = { addStrikeText = it },
                                label = { Text("Strike") },
                                modifier = Modifier.weight(1f),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                            )
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Option Type", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    listOf("CE", "PE").forEach { ot ->
                                        FilterChip(
                                            selected = addOptionType == ot,
                                            onClick = { addOptionType = ot },
                                            label = { Text(ot, fontSize = 11.sp) }
                                        )
                                    }
                                }
                            }
                        }
                        OutlinedTextField(
                            value = addExpiryText,
                            onValueChange = { addExpiryText = it },
                            label = { Text("Expiry (e.g. 28 MAR)") },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    OutlinedTextField(
                        value = addNotesText,
                        onValueChange = { addNotesText = it },
                        label = { Text("Surveillance Reason / Remark") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val qty = addQtyText.toIntOrNull() ?: 1
                        val prc = addPriceText.toDoubleOrNull() ?: 100.0
                        val strike = addStrikeText.toDoubleOrNull()
                        val isOpt = addSegment.contains("Option", ignoreCase = true)

                        viewModel.adminPlaceTradeForUser(
                            targetUserId = selectedUserForAdd,
                            segment = addSegment,
                            symbol = addSymbol.ifBlank { "RELIANCE" },
                            name = addName.ifBlank { addSymbol },
                            side = addSide,
                            orderType = addOrderType,
                            productType = addProductType,
                            quantity = qty,
                            price = prc,
                            strikePrice = if (isOpt) strike else null,
                            optionType = if (isOpt) addOptionType else null,
                            expiry = if (isOpt) addExpiryText else null,
                            notes = addNotesText,
                            status = addStatus
                        )
                        showAddTradeDialog = false
                    }
                ) {
                    Text("Place Trade")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddTradeDialog = false }) { Text("Cancel") }
            }
        )
    }
}

// Admin Broadcast Notification Screen
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminNotificationsScreen(
    viewModel: AdminViewModel,
    onNavigateBack: () -> Unit
) {
    var title by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Broadcast System Notification", fontSize = 18.sp, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text("Dispatch Notification to All Active Traders", fontSize = 14.sp, fontWeight = FontWeight.Bold)

            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                label = { Text("Announcement Title") },
                placeholder = { Text("e.g. Market Expiry Alert / Scheduled Maintenance") },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            )

            OutlinedTextField(
                value = message,
                onValueChange = { message = it },
                label = { Text("Notification Message") },
                placeholder = { Text("e.g. Monthly F&O contracts expire today at 3:30 PM. Square off open positions.") },
                modifier = Modifier.fillMaxWidth().height(140.dp),
                shape = RoundedCornerShape(12.dp)
            )

            Button(
                onClick = {
                    if (title.isNotBlank() && message.isNotBlank()) {
                        viewModel.sendBroadcastNotification(title, message, 0)
                        title = ""
                        message = ""
                    }
                },
                enabled = title.isNotBlank() && message.isNotBlank(),
                modifier = Modifier.fillMaxWidth().height(50.dp),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("Dispatch Broadcast Notification", fontSize = 15.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

// Immutable Audit Log Viewer Screen
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminAuditLogsScreen(
    viewModel: AdminViewModel,
    onNavigateBack: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()
    val timeFormat = SimpleDateFormat("dd MMM yyyy, hh:mm:ss a", Locale.ENGLISH)

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Immutable Audit Ledger (${uiState.auditLogs.size})", fontSize = 18.sp, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(16.dp)
        ) {
            items(uiState.auditLogs, key = { it.id }) { log ->
                Card(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(log.action, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                            Text(timeFormat.format(Date(log.timestamp)), fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(log.details, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("Admin: ${log.adminUsername} (ID: #${log.adminId})", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f))
                    }
                }
            }
        }
    }
}
