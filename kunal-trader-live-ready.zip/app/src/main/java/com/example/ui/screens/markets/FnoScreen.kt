package com.example.ui.screens.markets

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entities.InstrumentEntity
import com.example.ui.components.EmptyStateView
import com.example.ui.components.OrderBottomSheet
import com.example.ui.components.formatInr
import com.example.ui.theme.TradeGreen
import com.example.ui.theme.TradeGreenLight
import com.example.ui.theme.TradeRed
import com.example.ui.theme.TradeRedLight
import com.example.ui.viewmodel.TradingViewModel
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FnoScreen(
    viewModel: TradingViewModel,
    onNavigateInstrument: (symbol: String) -> Unit,
    onNavigateOptionChain: (symbol: String) -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()
    var selectedCategory by remember { mutableStateOf("Index Options") }
    var orderModalInstrument by remember { mutableStateOf<InstrumentEntity?>(null) }
    var orderModalSide by remember { mutableStateOf("BUY") }

    val categories = listOf(
        "Index Options",
        "Stock Options",
        "Index Futures",
        "Stock Futures"
    )

    val displayedInstruments = remember(uiState.instruments, selectedCategory) {
        when (selectedCategory) {
            "Index Options" -> uiState.instruments.filter { it.segment == "INDEX" }
            "Stock Options" -> uiState.instruments.filter {
                it.segment == "CASH" && (
                    it.symbol in listOf("RELIANCE", "TCS", "HDFCBANK", "INFY", "ICICIBANK", "SBIN", "TATAMOTORS", "BAJFINANCE", "BHARTIARTL", "ITC", "LT", "MARUTI", "SUNPHARMA", "TITAN", "AXISBANK")
                )
            }
            "Index Futures" -> uiState.instruments.filter { it.segment == "FNO_INDEX" }
            "Stock Futures" -> uiState.instruments.filter { it.segment == "FNO_STOCK" }
            else -> uiState.instruments.filter { it.segment.startsWith("FNO") }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Futures & Options (F&O)", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        Text("NSE & BSE Derivatives Market", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            // Category Filter Tabs
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 14.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                categories.forEach { cat ->
                    val isSel = selectedCategory == cat
                    FilterChip(
                        selected = isSel,
                        onClick = { selectedCategory = cat },
                        label = { Text(cat, fontSize = 12.sp, fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal) },
                        modifier = Modifier.testTag("fno_cat_$cat"),
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                            selectedLabelColor = MaterialTheme.colorScheme.primary
                        )
                    )
                }
            }

            // Quick Option Chain Hero Grid for Major Benchmark Indices
            if (selectedCategory == "Index Options") {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 4.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text("Popular Index Option Chains", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf("NIFTY 50" to "NSE Nifty", "SENSEX" to "BSE Sensex", "BANKNIFTY" to "NSE Bank").forEach { (sym, sub) ->
                            val inst = uiState.instruments.find { it.symbol == sym }
                            Card(
                                onClick = { onNavigateOptionChain(sym) },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("fno_quick_chain_$sym"),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Text(sym, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                    Text(sub, fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = formatInr(inst?.ltp ?: 0.0),
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.ExtraBold
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(2.dp)
                                    ) {
                                        Icon(Icons.Default.TableChart, contentDescription = null, modifier = Modifier.size(12.dp), tint = MaterialTheme.colorScheme.primary)
                                        Text("Option Chain", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Instruments List
            if (displayedInstruments.isEmpty()) {
                EmptyStateView(
                    icon = Icons.Default.TrendingUp,
                    title = "No F&O Contracts Found",
                    subtitle = "Select another category to view contracts"
                )
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp)
                ) {
                    items(displayedInstruments, key = { it.symbol }) { inst ->
                        val isUp = inst.change >= 0

                        Card(
                            onClick = { onNavigateInstrument(inst.symbol) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .testTag("fno_item_${inst.symbol}"),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Text(
                                            text = inst.symbol,
                                            fontSize = 15.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                        Box(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(4.dp))
                                                .background(MaterialTheme.colorScheme.surfaceVariant)
                                                .padding(horizontal = 4.dp, vertical = 1.dp)
                                        ) {
                                            Text(
                                                text = if (inst.lotSize > 1) "Lot: ${inst.lotSize}" else inst.exchange,
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.SemiBold,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                        if (inst.expiry.isNotBlank()) {
                                            Box(
                                                modifier = Modifier
                                                    .clip(RoundedCornerShape(4.dp))
                                                    .background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f))
                                                    .padding(horizontal = 4.dp, vertical = 1.dp)
                                            ) {
                                                Text(
                                                    text = inst.expiry,
                                                    fontSize = 8.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = MaterialTheme.colorScheme.primary
                                                )
                                            }
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = inst.name,
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }

                                Column(horizontalAlignment = Alignment.End) {
                                    Text(
                                        text = formatInr(inst.ltp),
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = "${if (isUp) "+" else ""}${String.format(Locale.ENGLISH, "%.2f", inst.change)} (${if (isUp) "+" else ""}${String.format(Locale.ENGLISH, "%.2f", inst.changePercent)}%)",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isUp) TradeGreen else TradeRed
                                    )
                                }

                                Spacer(modifier = Modifier.width(10.dp))

                                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    // Option Chain Button for Indices & Optionable Stocks
                                    if (selectedCategory == "Index Options" || selectedCategory == "Stock Options" || inst.segment == "INDEX") {
                                        FilledTonalButton(
                                            onClick = { onNavigateOptionChain(inst.symbol) },
                                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                            shape = RoundedCornerShape(6.dp),
                                            modifier = Modifier
                                                .height(32.dp)
                                                .testTag("open_option_chain_${inst.symbol}")
                                        ) {
                                            Icon(Icons.Default.TableChart, contentDescription = null, modifier = Modifier.size(14.dp))
                                            Spacer(modifier = Modifier.width(3.dp))
                                            Text("Chain", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }

                                    if (inst.segment != "INDEX") {
                                        IconButton(
                                            onClick = {
                                                orderModalInstrument = inst
                                                orderModalSide = "BUY"
                                            },
                                            modifier = Modifier
                                                .size(32.dp)
                                                .clip(RoundedCornerShape(6.dp))
                                                .background(TradeGreenLight)
                                                .testTag("buy_fno_${inst.symbol}")
                                        ) {
                                            Text("B", color = TradeGreen, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                        }

                                        IconButton(
                                            onClick = {
                                                orderModalInstrument = inst
                                                orderModalSide = "SELL"
                                            },
                                            modifier = Modifier
                                                .size(32.dp)
                                                .clip(RoundedCornerShape(6.dp))
                                                .background(TradeRedLight)
                                                .testTag("sell_fno_${inst.symbol}")
                                        ) {
                                            Text("S", color = TradeRed, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (orderModalInstrument != null) {
        OrderBottomSheet(
            instrument = orderModalInstrument!!,
            initialSide = orderModalSide,
            availableMargin = uiState.wallet?.availableMargin ?: 500000.0,
            onDismiss = { orderModalInstrument = null },
            onSubmitOrder = { side, product, orderType, qty, limitP, triggerP ->
                viewModel.placeOrder(
                    symbol = orderModalInstrument!!.symbol,
                    name = orderModalInstrument!!.name,
                    segment = orderModalInstrument!!.segment,
                    orderType = orderType,
                    productType = product,
                    side = side,
                    quantity = qty,
                    price = limitP,
                    triggerPrice = triggerP
                )
                orderModalInstrument = null
            }
        )
    }
}
