package com.example.ui.screens.home

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.local.entities.InstrumentEntity
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.TradingViewModel
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: TradingViewModel,
    onNavigateInstrument: (symbol: String) -> Unit,
    onNavigateDeposit: () -> Unit,
    onNavigateOptionChain: (symbol: String) -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()
    var selectedWatchlistTab by remember { mutableStateOf("NIFTY 50") }
    var searchQuery by remember { mutableStateOf("") }
    var orderModalInstrument by remember { mutableStateOf<InstrumentEntity?>(null) }
    var orderModalSide by remember { mutableStateOf("BUY") }

    val wallet = uiState.wallet
    val totalInvested = uiState.holdings.sumOf { it.investedValue }
    val totalCurrent = uiState.holdings.sumOf { it.currentValue }
    val totalHoldingPnl = totalCurrent - totalInvested
    val positionsPnl = uiState.positions.sumOf { it.pnl }
    val totalPnl = totalHoldingPnl + positionsPnl + (wallet?.realizedPnl ?: 0.0)

    val indices = uiState.instruments.filter { it.segment == "INDEX" }

    val filteredInstruments = remember(uiState.instruments, uiState.watchlistItems, selectedWatchlistTab, searchQuery) {
        var list = uiState.instruments.filter { it.isActive }

        if (searchQuery.isNotBlank()) {
            list.filter {
                it.symbol.contains(searchQuery, ignoreCase = true) ||
                it.name.contains(searchQuery, ignoreCase = true)
            }
        } else {
            when (selectedWatchlistTab) {
                "Watchlist" -> {
                    val watchlistSymbols = uiState.watchlistItems.map { it.symbol }.toSet()
                    list.filter { watchlistSymbols.contains(it.symbol) }
                }
                "NIFTY 50" -> list.filter { it.indexCategory == "NIFTY 50" && it.segment == "CASH" }
                "SENSEX" -> list.filter { it.indexCategory == "SENSEX" && it.segment == "CASH" }
                "BANKNIFTY" -> list.filter { it.indexCategory == "BANKNIFTY" && it.segment == "CASH" }
                "F&O" -> list.filter { it.segment == "FNO_INDEX" || it.segment == "FNO_STOCK" }
                "MCX" -> list.filter { it.segment == "COMMODITY" }
                else -> list
            }
        }
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(bottom = 90.dp)
        ) {
            // App Header
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Surface(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(8.dp)),
                            color = MaterialTheme.colorScheme.primaryContainer,
                            shadowElevation = 2.dp
                        ) {
                            Image(
                                painter = painterResource(id = R.drawable.kunal_app_logo_1787548799128),
                                contentDescription = "Kunal Trader",
                                modifier = Modifier.fillMaxSize(),
                                contentScale = ContentScale.Crop
                            )
                        }
                        Column {
                            Text(
                                text = "Kunal Trader",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = MaterialTheme.colorScheme.onBackground
                            )
                            Text(
                                text = "Simulated Live Market",
                                fontSize = 11.sp,
                                color = TradeGreen,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        FilledTonalButton(
                            onClick = onNavigateDeposit,
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.testTag("add_funds_header_btn")
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Add Funds", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // Benchmark Indices Carousel (NIFTY 50, SENSEX, BANKNIFTY)
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                        .padding(horizontal = 16.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    indices.forEach { idx ->
                        Card(
                            onClick = { onNavigateInstrument(idx.symbol) },
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .width(180.dp)
                                .testTag("index_card_${idx.symbol}")
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    text = idx.symbol,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = formatInr(idx.ltp),
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    val isUp = idx.change >= 0
                                    Text(
                                        text = "${if (isUp) "+" else ""}${String.format(Locale.ENGLISH, "%.2f", idx.change)} (${if (isUp) "+" else ""}${String.format(Locale.ENGLISH, "%.2f", idx.changePercent)}%)",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isUp) TradeGreen else TradeRed
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Portfolio & Balance Hero Card
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("Virtual Margin Available", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(
                                    text = formatInr(wallet?.availableMargin ?: 500000.0),
                                    fontSize = 22.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("Total Portfolio P&L", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                val isProfitable = totalPnl >= 0
                                Text(
                                    text = formatInr(totalPnl, showSign = true),
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isProfitable) TradeGreen else TradeRed
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))
                        Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text("Invested (Holdings)", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(formatInr(totalInvested), fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface)
                            }
                            Column {
                                Text("Current Value", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(formatInr(totalCurrent), fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("Used Margin", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(formatInr(wallet?.usedMargin ?: 0.0), fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface)
                            }
                        }
                    }
                }
            }

            // Search Bar
            item {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Search stocks, indices, futures, MCX...", fontSize = 13.sp) },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(Icons.Default.Clear, contentDescription = "Clear")
                            }
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp)
                        .testTag("watchlist_search_input"),
                    shape = RoundedCornerShape(12.dp),
                    singleLine = true
                )
            }

            // Watchlist Tab Pills
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                        .padding(horizontal = 16.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf("Watchlist", "NIFTY 50", "SENSEX", "BANKNIFTY", "F&O", "MCX").forEach { tab ->
                        val isSel = (selectedWatchlistTab == tab)
                        FilterChip(
                            selected = isSel,
                            onClick = { selectedWatchlistTab = tab },
                            label = { Text(tab, fontSize = 12.sp, fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal) },
                            modifier = Modifier.testTag("tab_$tab"),
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                                selectedLabelColor = MaterialTheme.colorScheme.primary
                            )
                        )
                    }
                }
            }

            // Instrument List Section
            if (filteredInstruments.isEmpty()) {
                item {
                    EmptyStateView(
                        icon = Icons.Default.SearchOff,
                        title = "No Instruments Found",
                        subtitle = "Try searching for a different stock name or symbol"
                    )
                }
            } else {
                items(filteredInstruments, key = { it.symbol }) { inst ->
                    val isUp = inst.change >= 0
                    val isInWatchlist = uiState.watchlistItems.any { it.symbol == inst.symbol }

                    Card(
                        onClick = { onNavigateInstrument(inst.symbol) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 4.dp)
                            .testTag("instrument_row_${inst.symbol}"),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Left: Symbol, Name & Exchange
                            Column(modifier = Modifier.weight(1f)) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Text(
                                        text = inst.symbol,
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(MaterialTheme.colorScheme.surfaceVariant)
                                            .padding(horizontal = 4.dp, vertical = 1.dp)
                                    ) {
                                        Text(
                                            text = inst.exchange,
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = inst.name,
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }

                            // Middle/Right: Price & Change
                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = formatInr(inst.ltp),
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "${if (isUp) "+" else ""}${String.format(Locale.ENGLISH, "%.2f", inst.change)} (${if (isUp) "+" else ""}${String.format(Locale.ENGLISH, "%.2f", inst.changePercent)}%)",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isUp) TradeGreen else TradeRed
                                )
                            }

                            Spacer(modifier = Modifier.width(10.dp))

                            // Quick Buy / Option Chain Action
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                IconButton(
                                    onClick = {
                                        orderModalInstrument = inst
                                        orderModalSide = "BUY"
                                    },
                                    modifier = Modifier
                                        .size(32.dp)
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(TradeGreenLight)
                                        .testTag("quick_buy_${inst.symbol}")
                                ) {
                                    Text("B", color = TradeGreen, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                }

                                IconButton(
                                    onClick = {
                                        orderModalInstrument = inst
                                        orderModalSide = "SELL"
                                    },
                                    modifier = Modifier
                                        .size(32.dp)
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(TradeRedLight)
                                        .testTag("quick_sell_${inst.symbol}")
                                ) {
                                    Text("S", color = TradeRed, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                }

                                IconButton(
                                    onClick = { viewModel.toggleWatchlist(inst.symbol) },
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(
                                        imageVector = if (isInWatchlist) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                                        contentDescription = "Watchlist",
                                        tint = if (isInWatchlist) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Quick Order Bottom Sheet
    if (orderModalInstrument != null) {
        OrderBottomSheet(
            instrument = orderModalInstrument!!,
            initialSide = orderModalSide,
            availableMargin = wallet?.availableMargin ?: 500000.0,
            onDismiss = { orderModalInstrument = null },
            onSubmitOrder = { side, product, orderType, qty, limitP, triggerP ->
                viewModel.placeOrder(
                    symbol = orderModalInstrument!!.symbol,
                    name = orderModalInstrument!!.name,
                    segment = orderModalInstrument!!.segment,
                    orderType = orderType,
                    productType = product,
                    side = side,
                    quantity = qty,
                    price = limitP,
                    triggerPrice = triggerP
                )
                orderModalInstrument = null
            }
        )
    }
}
