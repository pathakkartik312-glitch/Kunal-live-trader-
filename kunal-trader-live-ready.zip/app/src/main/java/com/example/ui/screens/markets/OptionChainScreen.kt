package com.example.ui.screens.markets

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.TableChart
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entities.InstrumentEntity
import com.example.data.local.entities.OptionStrikeEntity
import com.example.ui.components.EmptyStateView
import com.example.ui.components.OrderBottomSheet
import com.example.ui.components.formatInr
import com.example.ui.components.formatQuantity
import com.example.ui.theme.TradeGreen
import com.example.ui.theme.TradeRed
import com.example.ui.viewmodel.TradingViewModel
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OptionChainScreen(
    symbol: String,
    viewModel: TradingViewModel,
    onNavigateBack: () -> Unit
) {
    val cleanSymbol = remember(symbol) {
        val trimmed = symbol.trim()
        if (trimmed.isEmpty()) "NIFTY 50" else trimmed
    }

    val uiState by viewModel.uiState.collectAsState()

    // Safely resolve the underlying instrument or construct a reliable fallback model
    val underlying = remember(uiState.instruments, cleanSymbol) {
        val found = uiState.instruments.find { it.symbol.equals(cleanSymbol, ignoreCase = true) }
            ?: uiState.instruments.find { 
                cleanSymbol.contains(it.symbol, ignoreCase = true) || it.symbol.contains(cleanSymbol, ignoreCase = true) 
            }
            ?: uiState.instruments.find { 
                (cleanSymbol.startsWith("NIFTY", ignoreCase = true) && it.symbol.startsWith("NIFTY", ignoreCase = true)) ||
                (cleanSymbol.startsWith("SENSEX", ignoreCase = true) && it.symbol.startsWith("SENSEX", ignoreCase = true))
            }

        found ?: InstrumentEntity(
            symbol = cleanSymbol,
            name = when {
                cleanSymbol.contains("NIFTY 50", ignoreCase = true) || cleanSymbol.equals("NIFTY", ignoreCase = true) -> "Nifty 50 Benchmark Index"
                cleanSymbol.contains("SENSEX", ignoreCase = true) -> "BSE SENSEX 30 Benchmark Index"
                cleanSymbol.contains("BANKNIFTY", ignoreCase = true) -> "Nifty Bank Index"
                cleanSymbol.contains("GOLD", ignoreCase = true) -> "Gold 1Kg MCX Futures"
                cleanSymbol.contains("SILVER", ignoreCase = true) -> "Silver 30Kg MCX Futures"
                cleanSymbol.contains("CRUDEOIL", ignoreCase = true) -> "Crude Oil 100 BBL MCX"
                cleanSymbol.contains("NATURALGAS", ignoreCase = true) -> "Natural Gas 1250 mmBtu MCX"
                cleanSymbol.contains("RELIANCE", ignoreCase = true) -> "Reliance Industries Ltd"
                cleanSymbol.contains("TCS", ignoreCase = true) -> "Tata Consultancy Services"
                cleanSymbol.contains("HDFCBANK", ignoreCase = true) -> "HDFC Bank Ltd"
                cleanSymbol.contains("INFY", ignoreCase = true) -> "Infosys Ltd"
                else -> "$cleanSymbol Derivative"
            },
            segment = if (cleanSymbol in listOf("NIFTY 50", "NIFTY", "SENSEX", "BANKNIFTY")) "INDEX" else if (cleanSymbol in listOf("GOLD", "SILVER", "CRUDEOIL", "NATURALGAS")) "COMMODITY" else "CASH",
            exchange = if (cleanSymbol.contains("SENSEX", ignoreCase = true)) "BSE" else if (cleanSymbol in listOf("GOLD", "SILVER", "CRUDEOIL", "NATURALGAS")) "MCX" else "NSE",
            ltp = when {
                cleanSymbol.contains("SENSEX", ignoreCase = true) -> 83120.50
                cleanSymbol.contains("BANKNIFTY", ignoreCase = true) -> 51840.20
                cleanSymbol.contains("GOLD", ignoreCase = true) -> 75200.0
                cleanSymbol.contains("SILVER", ignoreCase = true) -> 88500.0
                cleanSymbol.contains("CRUDEOIL", ignoreCase = true) -> 6240.0
                cleanSymbol.contains("NATURALGAS", ignoreCase = true) -> 195.0
                cleanSymbol.contains("RELIANCE", ignoreCase = true) -> 3015.0
                cleanSymbol.contains("TCS", ignoreCase = true) -> 4520.0
                cleanSymbol.contains("HDFCBANK", ignoreCase = true) -> 1665.0
                cleanSymbol.contains("INFY", ignoreCase = true) -> 1945.0
                else -> 25420.75
            },
            openPrice = 25400.0,
            highPrice = 25500.0,
            lowPrice = 25350.0,
            closePrice = 25380.0,
            change = 40.75,
            changePercent = 0.16,
            lotSize = when {
                cleanSymbol.contains("BANKNIFTY", ignoreCase = true) -> 15
                cleanSymbol.contains("SENSEX", ignoreCase = true) -> 10
                cleanSymbol.contains("GOLD", ignoreCase = true) -> 1
                cleanSymbol.contains("SILVER", ignoreCase = true) -> 1
                cleanSymbol.contains("CRUDEOIL", ignoreCase = true) -> 100
                cleanSymbol.contains("NATURALGAS", ignoreCase = true) -> 1250
                cleanSymbol.contains("RELIANCE", ignoreCase = true) -> 250
                cleanSymbol.contains("TCS", ignoreCase = true) -> 175
                cleanSymbol.contains("HDFCBANK", ignoreCase = true) -> 550
                cleanSymbol.contains("INFY", ignoreCase = true) -> 400
                else -> 25
            }
        )
    }

    val dbStrikes by viewModel.getOptionChain(cleanSymbol).collectAsState(initial = emptyList())

    // Expiry options
    val defaultExpiries = listOf("28 SEP 2026", "05 OCT 2026", "19 OCT 2026", "29 OCT 2026")
    var selectedExpiry by remember { mutableStateOf("28 SEP 2026") }

    var orderModalInstrument by remember { mutableStateOf<InstrumentEntity?>(null) }
    var orderModalSide by remember { mutableStateOf("BUY") }

    val spotPrice = remember(underlying) {
        if (underlying.ltp > 0) underlying.ltp else 25400.0
    }

    // Safely generate or filter strikes
    val effectiveStrikes = remember(dbStrikes, spotPrice, cleanSymbol, selectedExpiry) {
        try {
            if (dbStrikes.isNotEmpty()) {
                dbStrikes
            } else {
                // Determine appropriate strike interval
                val step = when {
                    cleanSymbol.contains("SENSEX", ignoreCase = true) -> 500.0
                    cleanSymbol.contains("BANKNIFTY", ignoreCase = true) -> 100.0
                    cleanSymbol.contains("GOLD", ignoreCase = true) -> 500.0
                    cleanSymbol.contains("SILVER", ignoreCase = true) -> 1000.0
                    cleanSymbol.contains("CRUDEOIL", ignoreCase = true) -> 100.0
                    cleanSymbol.contains("NATURALGAS", ignoreCase = true) -> 5.0
                    cleanSymbol.contains("TCS", ignoreCase = true) -> 50.0
                    cleanSymbol.contains("RELIANCE", ignoreCase = true) -> 50.0
                    cleanSymbol.contains("HDFCBANK", ignoreCase = true) -> 20.0
                    cleanSymbol.contains("INFY", ignoreCase = true) -> 20.0
                    spotPrice > 40000 -> 500.0
                    spotPrice > 10000 -> 100.0
                    spotPrice > 2000 -> 50.0
                    spotPrice > 500 -> 20.0
                    spotPrice > 100 -> 5.0
                    else -> 1.0
                }

                val roundedAtm = (Math.round(spotPrice / step) * step)
                val generated = mutableListOf<OptionStrikeEntity>()
                val shortSymbol = cleanSymbol.replace(" ", "").take(8).uppercase(Locale.ENGLISH)

                for (i in -6..6) {
                    val strike = roundedAtm + (i * step)
                    val dist = strike - spotPrice
                    val basePremium = Math.max(step * 0.8, 15.0)

                    val callLtp = if (dist < 0) {
                        // In the Money Call
                        basePremium + Math.abs(dist) * 0.95
                    } else {
                        // Out of the Money Call
                        Math.max(step * 0.04, basePremium - (dist * 0.65))
                    }

                    val putLtp = if (dist > 0) {
                        // In the Money Put
                        basePremium + dist * 0.95
                    } else {
                        // Out of the Money Put
                        Math.max(step * 0.04, basePremium - (Math.abs(dist) * 0.65))
                    }

                    val callOi = (650000L - Math.abs(dist * 20).toLong()).coerceAtLeast(35000L)
                    val putOi = (680000L - Math.abs(dist * 20).toLong()).coerceAtLeast(38000L)

                    generated.add(
                        OptionStrikeEntity(
                            id = (i + 100).toLong(),
                            underlyingSymbol = cleanSymbol,
                            expiryDate = selectedExpiry,
                            strikePrice = strike,
                            callSymbol = "${shortSymbol}24SEP${strike.toInt()}CE",
                            callLtp = Math.round(callLtp * 100.0) / 100.0,
                            callChange = Math.round((-(dist / (step * 2.0)) * 5.0) * 10.0) / 10.0,
                            callOi = callOi,
                            callIv = 15.8 + (Math.abs(dist) / (step * 10.0)),
                            putSymbol = "${shortSymbol}24SEP${strike.toInt()}PE",
                            putLtp = Math.round(putLtp * 100.0) / 100.0,
                            putChange = Math.round(((dist / (step * 2.0)) * 5.0) * 10.0) / 10.0,
                            putOi = putOi,
                            putIv = 16.4 + (Math.abs(dist) / (step * 10.0))
                        )
                    )
                }
                generated
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    val filteredStrikes = remember(effectiveStrikes, selectedExpiry) {
        val matches = effectiveStrikes.filter { it.expiryDate.equals(selectedExpiry, ignoreCase = true) }
        if (matches.isNotEmpty()) matches else effectiveStrikes
    }

    val totalCallOi = remember(filteredStrikes) {
        try { filteredStrikes.sumOf { it.callOi } } catch (e: Exception) { 0L }
    }
    val totalPutOi = remember(filteredStrikes) {
        try { filteredStrikes.sumOf { it.putOi } } catch (e: Exception) { 0L }
    }
    val pcrRatio = remember(totalCallOi, totalPutOi) {
        if (totalCallOi > 0) {
            String.format(Locale.ENGLISH, "%.2f", totalPutOi.toDouble() / totalCallOi.toDouble())
        } else {
            "1.00"
        }
    }

    val isUnderlyingUp = (underlying.change >= 0)

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = "${underlying.symbol} Option Chain",
                                fontSize = 17.sp,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Surface(
                                color = MaterialTheme.colorScheme.primaryContainer,
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    text = underlying.exchange,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                )
                            }
                        }
                        Text(
                            text = "Spot: ${formatInr(spotPrice)} (${if (isUnderlyingUp) "+" else ""}${String.format(Locale.ENGLISH, "%.2f", underlying.change)} / ${if (isUnderlyingUp) "+" else ""}${String.format(Locale.ENGLISH, "%.2f", underlying.changePercent)}%)",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = if (isUnderlyingUp) TradeGreen else TradeRed
                        )
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = onNavigateBack,
                        modifier = Modifier.testTag("option_chain_back_button")
                    ) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            // Expiry Date Selector Chips
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 14.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                defaultExpiries.forEach { exp ->
                    val isSel = (selectedExpiry == exp)
                    FilterChip(
                        selected = isSel,
                        onClick = { selectedExpiry = exp },
                        label = {
                            Text(
                                text = "Exp: $exp",
                                fontSize = 11.sp,
                                fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        modifier = Modifier.testTag("expiry_chip_$exp"),
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                            selectedLabelColor = MaterialTheme.colorScheme.primary
                        )
                    )
                }
            }

            // PCR & Open Interest Analytics Bar
            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 2.dp),
                shape = RoundedCornerShape(8.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Total Call OI: ${formatQuantity(totalCallOi)}",
                        fontSize = 11.sp,
                        color = TradeGreen,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "PCR: $pcrRatio",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "Total Put OI: ${formatQuantity(totalPutOi)}",
                        fontSize = 11.sp,
                        color = TradeRed,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            // Table Column Headers: CALLS (CE) | STRIKE | PUTS (PE)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .padding(vertical = 8.dp, horizontal = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Call Side
                Text(
                    text = "CE OI",
                    fontSize = 10.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.weight(1.1f),
                    textAlign = TextAlign.Center
                )
                Text(
                    text = "CALL (₹)",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = TradeGreen,
                    modifier = Modifier.weight(1.3f),
                    textAlign = TextAlign.End
                )

                // Strike Center
                Text(
                    text = "STRIKE",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.weight(1.4f),
                    textAlign = TextAlign.Center
                )

                // Put Side
                Text(
                    text = "PUT (₹)",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = TradeRed,
                    modifier = Modifier.weight(1.3f),
                    textAlign = TextAlign.Start
                )
                Text(
                    text = "PE OI",
                    fontSize = 10.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.weight(1.1f),
                    textAlign = TextAlign.Center
                )
            }

            // Strikes List or Safe Empty State
            if (filteredStrikes.isEmpty()) {
                EmptyStateView(
                    icon = Icons.Default.TableChart,
                    title = "Option Chain Data Unavailable",
                    subtitle = "No option chain contracts found for $cleanSymbol on $selectedExpiry"
                )
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .testTag("option_chain_table"),
                    contentPadding = PaddingValues(bottom = 80.dp)
                ) {
                    itemsIndexed(
                        items = filteredStrikes,
                        key = { index, item ->
                            "${item.underlyingSymbol}_${item.expiryDate}_${item.strikePrice}_${item.callSymbol}_${item.putSymbol}_$index"
                        }
                    ) { index, item ->
                        val step = if (filteredStrikes.size > 1) {
                            Math.abs(filteredStrikes[1].strikePrice - filteredStrikes[0].strikePrice).coerceAtLeast(1.0)
                        } else 50.0

                        val isAtm = Math.abs(item.strikePrice - spotPrice) <= (step * 0.6)
                        val isCallItm = item.strikePrice < spotPrice
                        val isPutItm = item.strikePrice > spotPrice

                        val callBg = if (isCallItm) MaterialTheme.colorScheme.primary.copy(alpha = 0.08f) else Color.Transparent
                        val putBg = if (isPutItm) MaterialTheme.colorScheme.error.copy(alpha = 0.08f) else Color.Transparent

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 1.dp)
                                .then(
                                    if (isAtm) Modifier.background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.18f))
                                    else Modifier
                                )
                                .testTag("strike_row_${item.strikePrice.toInt()}"),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // CE OI & CE LTP (Tap to Trade CE)
                            Row(
                                modifier = Modifier
                                    .weight(2.4f)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(callBg)
                                    .clickable {
                                        orderModalInstrument = InstrumentEntity(
                                            symbol = item.callSymbol,
                                            name = "${item.underlyingSymbol} ${item.strikePrice.toInt()} CE",
                                            segment = if (underlying.segment == "COMMODITY") "COMMODITY" else "FNO_INDEX",
                                            exchange = underlying.exchange,
                                            ltp = item.callLtp,
                                            openPrice = item.callLtp,
                                            highPrice = item.callLtp * 1.1,
                                            lowPrice = item.callLtp * 0.9,
                                            closePrice = (item.callLtp - item.callChange).coerceAtLeast(0.05),
                                            change = item.callChange,
                                            changePercent = if (item.callLtp > 0) (item.callChange / item.callLtp) * 100.0 else 0.0,
                                            lotSize = underlying.lotSize
                                        )
                                        orderModalSide = "BUY"
                                    }
                                    .padding(vertical = 8.dp, horizontal = 4.dp)
                                    .testTag("trade_ce_${item.strikePrice.toInt()}"),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = formatQuantity(item.callOi),
                                    fontSize = 10.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.weight(1.1f),
                                    textAlign = TextAlign.Center
                                )
                                Column(
                                    modifier = Modifier.weight(1.3f),
                                    horizontalAlignment = Alignment.End
                                ) {
                                    Text(
                                        text = String.format(Locale.ENGLISH, "%.2f", item.callLtp),
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = TradeGreen
                                    )
                                    Text(
                                        text = "${if (item.callChange >= 0) "+" else ""}${String.format(Locale.ENGLISH, "%.1f", item.callChange)}",
                                        fontSize = 9.sp,
                                        color = if (item.callChange >= 0) TradeGreen else TradeRed
                                    )
                                }
                            }

                            // Strike Price Badge (Center)
                            Box(
                                modifier = Modifier
                                    .weight(1.4f)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(if (isAtm) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant)
                                    .padding(vertical = 6.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(
                                        text = if (item.strikePrice >= 1000) "${item.strikePrice.toInt()}" else String.format(Locale.ENGLISH, "%.1f", item.strikePrice),
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = if (isAtm) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
                                    )
                                    if (isAtm) {
                                        Text(
                                            text = "ATM",
                                            fontSize = 8.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.onPrimary
                                        )
                                    }
                                }
                            }

                            // PE LTP & PE OI (Tap to Trade PE)
                            Row(
                                modifier = Modifier
                                    .weight(2.4f)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(putBg)
                                    .clickable {
                                        orderModalInstrument = InstrumentEntity(
                                            symbol = item.putSymbol,
                                            name = "${item.underlyingSymbol} ${item.strikePrice.toInt()} PE",
                                            segment = if (underlying.segment == "COMMODITY") "COMMODITY" else "FNO_INDEX",
                                            exchange = underlying.exchange,
                                            ltp = item.putLtp,
                                            openPrice = item.putLtp,
                                            highPrice = item.putLtp * 1.1,
                                            lowPrice = item.putLtp * 0.9,
                                            closePrice = (item.putLtp - item.putChange).coerceAtLeast(0.05),
                                            change = item.putChange,
                                            changePercent = if (item.putLtp > 0) (item.putChange / item.putLtp) * 100.0 else 0.0,
                                            lotSize = underlying.lotSize
                                        )
                                        orderModalSide = "BUY"
                                    }
                                    .padding(vertical = 8.dp, horizontal = 4.dp)
                                    .testTag("trade_pe_${item.strikePrice.toInt()}"),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(
                                    modifier = Modifier.weight(1.3f),
                                    horizontalAlignment = Alignment.Start
                                ) {
                                    Text(
                                        text = String.format(Locale.ENGLISH, "%.2f", item.putLtp),
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = TradeRed
                                    )
                                    Text(
                                        text = "${if (item.putChange >= 0) "+" else ""}${String.format(Locale.ENGLISH, "%.1f", item.putChange)}",
                                        fontSize = 9.sp,
                                        color = if (item.putChange >= 0) TradeGreen else TradeRed
                                    )
                                }
                                Text(
                                    text = formatQuantity(item.putOi),
                                    fontSize = 10.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.weight(1.1f),
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    if (orderModalInstrument != null) {
        OrderBottomSheet(
            instrument = orderModalInstrument!!,
            initialSide = orderModalSide,
            availableMargin = uiState.wallet?.availableMargin ?: 500000.0,
            onDismiss = { orderModalInstrument = null },
            onSubmitOrder = { side, product, orderType, qty, limitP, triggerP ->
                viewModel.placeOrder(
                    symbol = orderModalInstrument!!.symbol,
                    name = orderModalInstrument!!.name,
                    segment = orderModalInstrument!!.segment,
                    orderType = orderType,
                    productType = product,
                    side = side,
                    quantity = qty,
                    price = limitP,
                    triggerPrice = triggerP
                )
                orderModalInstrument = null
            }
        )
    }
}
