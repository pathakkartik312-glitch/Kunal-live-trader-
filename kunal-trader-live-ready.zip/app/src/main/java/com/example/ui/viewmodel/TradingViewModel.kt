package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.entities.*
import com.example.data.repository.TradingRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class TradingUiState(
    val currentUser: UserEntity? = null,
    val wallet: WalletEntity? = null,
    val instruments: List<InstrumentEntity> = emptyList(),
    val watchlistItems: List<WatchlistItemEntity> = emptyList(),
    val holdings: List<HoldingEntity> = emptyList(),
    val positions: List<PositionEntity> = emptyList(),
    val orders: List<OrderEntity> = emptyList(),
    val transactions: List<TransactionEntity> = emptyList(),
    val bankAccounts: List<BankAccountEntity> = emptyList(),
    val adminDepositBanks: List<BankAccountEntity> = emptyList(),
    val notifications: List<NotificationEntity> = emptyList(),
    val selectedSegment: String = "CASH",
    val searchQuery: String = "",
    val isLoading: Boolean = false,
    val message: String? = null,
    val error: String? = null
)

class TradingViewModel(
    private val repository: TradingRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(TradingUiState())
    val uiState: StateFlow<TradingUiState> = _uiState.asStateFlow()

    private val _currentUserId = MutableStateFlow(1L) // Default to Demo User (Kunal)
    val currentUserId: StateFlow<Long> = _currentUserId.asStateFlow()

    init {
        loadData()
    }

    private fun loadData() {
        viewModelScope.launch {
            // Observe current user
            _currentUserId.flatMapLatest { userId ->
                repository.getUser(userId)
            }.collect { user ->
                _uiState.update { it.copy(currentUser = user) }
            }
        }

        viewModelScope.launch {
            _currentUserId.flatMapLatest { userId ->
                repository.getWallet(userId)
            }.collect { wallet ->
                _uiState.update { it.copy(wallet = wallet) }
            }
        }

        viewModelScope.launch {
            repository.getActiveInstruments().collect { list ->
                _uiState.update { it.copy(instruments = list) }
            }
        }

        viewModelScope.launch {
            _currentUserId.flatMapLatest { userId ->
                repository.getHoldingsForUser(userId)
            }.collect { list ->
                _uiState.update { it.copy(holdings = list) }
            }
        }

        viewModelScope.launch {
            _currentUserId.flatMapLatest { userId ->
                repository.getAllPositionsForUser(userId)
            }.collect { list ->
                _uiState.update { it.copy(positions = list) }
            }
        }

        viewModelScope.launch {
            _currentUserId.flatMapLatest { userId ->
                repository.getOrdersForUser(userId)
            }.collect { list ->
                _uiState.update { it.copy(orders = list) }
            }
        }

        viewModelScope.launch {
            _currentUserId.flatMapLatest { userId ->
                repository.getWatchlist(userId)
            }.collect { list ->
                _uiState.update { it.copy(watchlistItems = list) }
            }
        }

        viewModelScope.launch {
            _currentUserId.flatMapLatest { userId ->
                repository.getTransactions(userId)
            }.collect { list ->
                _uiState.update { it.copy(transactions = list) }
            }
        }

        viewModelScope.launch {
            _currentUserId.flatMapLatest { userId ->
                repository.getBankAccountsForUser(userId)
            }.collect { list ->
                _uiState.update { it.copy(bankAccounts = list) }
            }
        }

        viewModelScope.launch {
            repository.getAdminDepositBanks().collect { list ->
                _uiState.update { it.copy(adminDepositBanks = list) }
            }
        }

        viewModelScope.launch {
            _currentUserId.flatMapLatest { userId ->
                repository.getNotifications(userId)
            }.collect { list ->
                _uiState.update { it.copy(notifications = list) }
            }
        }
    }

    fun switchUser(userId: Long) {
        _currentUserId.value = userId
    }

    fun login(emailOrPhone: String, pin: String, onSuccess: () -> Unit) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, error = null) }
            val result = repository.login(emailOrPhone, pin)
            result.onSuccess { user ->
                _currentUserId.value = user.id
                _uiState.update { it.copy(isLoading = false, currentUser = user, message = "Login successful. Welcome, ${user.fullName}!") }
                onSuccess()
            }.onFailure { err ->
                _uiState.update { it.copy(isLoading = false, error = err.message ?: "Invalid mobile/email or password") }
            }
        }
    }

    fun loginWithOtp(phoneOrEmail: String, onSuccess: () -> Unit) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, error = null) }
            val result = repository.loginWithOtp(phoneOrEmail)
            result.onSuccess { user ->
                _currentUserId.value = user.id
                _uiState.update { it.copy(isLoading = false, currentUser = user, message = "OTP verified! Welcome, ${user.fullName}") }
                onSuccess()
            }.onFailure { err ->
                _uiState.update { it.copy(isLoading = false, error = err.message ?: "OTP Login failed") }
            }
        }
    }

    fun resetPassword(phoneOrEmail: String, newPin: String, onSuccess: () -> Unit) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, error = null) }
            val result = repository.resetPassword(phoneOrEmail, newPin)
            result.onSuccess { user ->
                _uiState.update { it.copy(isLoading = false, message = "Password updated successfully! Please login with your new password.") }
                onSuccess()
            }.onFailure { err ->
                _uiState.update { it.copy(isLoading = false, error = err.message ?: "Password reset failed") }
            }
        }
    }

    fun logout(onSuccess: () -> Unit) {
        _currentUserId.value = 0L
        _uiState.update { it.copy(currentUser = null, message = "Logged out successfully") }
        onSuccess()
    }

    fun register(fullName: String, email: String, phone: String, pin: String, onSuccess: () -> Unit) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, error = null) }
            val result = repository.registerUser(fullName, email, phone, pin)
            result.onSuccess { user ->
                _currentUserId.value = user.id
                _uiState.update { it.copy(isLoading = false, currentUser = user, message = "Account created successfully with ₹5,00,000 demo margin!") }
                onSuccess()
            }.onFailure { err ->
                _uiState.update { it.copy(isLoading = false, error = err.message ?: "Registration failed") }
            }
        }
    }

    fun toggleWatchlist(symbol: String) {
        val userId = _currentUserId.value
        val isCurrentlyIn = _uiState.value.watchlistItems.any { it.symbol == symbol }
        viewModelScope.launch {
            repository.toggleWatchlist(userId, symbol, isCurrentlyIn)
        }
    }

    fun placeOrder(
        symbol: String,
        name: String,
        segment: String,
        orderType: String,
        productType: String,
        side: String,
        quantity: Int,
        price: Double,
        triggerPrice: Double = 0.0
    ) {
        val userId = _currentUserId.value
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, error = null) }
            val result = repository.placeOrder(
                userId = userId,
                symbol = symbol,
                name = name,
                segment = segment,
                orderType = orderType,
                productType = productType,
                side = side,
                quantity = quantity,
                price = price,
                triggerPrice = triggerPrice
            )
            result.onSuccess { order ->
                _uiState.update {
                    it.copy(
                        isLoading = false,
                        message = "${order.side} order for ${order.quantity} Qty of ${order.symbol} placed (${order.status})"
                    )
                }
            }.onFailure { err ->
                _uiState.update { it.copy(isLoading = false, error = err.message) }
            }
        }
    }

    fun cancelOrder(orderId: Long) {
        val userId = _currentUserId.value
        viewModelScope.launch {
            val result = repository.cancelOrder(orderId, userId)
            result.onSuccess {
                _uiState.update { it.copy(message = "Order cancelled successfully") }
            }.onFailure { err ->
                _uiState.update { it.copy(error = err.message) }
            }
        }
    }

    fun exitPosition(position: PositionEntity) {
        // Place counter market order
        val oppositeSide = if (position.side == "BUY") "SELL" else "BUY"
        placeOrder(
            symbol = position.symbol,
            name = position.name,
            segment = position.segment,
            orderType = "MARKET",
            productType = position.productType,
            side = oppositeSide,
            quantity = position.quantity,
            price = position.ltp
        )
    }

    fun requestDeposit(amount: Double, utr: String, bankName: String, onSuccess: () -> Unit) {
        val userId = _currentUserId.value
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, error = null) }
            try {
                repository.requestDeposit(userId, amount, utr, bankName)
                _uiState.update { it.copy(isLoading = false, message = "Deposit request for ₹$amount submitted!") }
                onSuccess()
            } catch (e: Exception) {
                _uiState.update { it.copy(isLoading = false, error = e.message) }
            }
        }
    }

    fun requestWithdrawal(amount: Double, bankAccountStr: String, onSuccess: () -> Unit) {
        val userId = _currentUserId.value
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, error = null) }
            val result = repository.requestWithdrawal(userId, amount, bankAccountStr)
            result.onSuccess {
                _uiState.update { it.copy(isLoading = false, message = "Withdrawal request for ₹$amount submitted!") }
                onSuccess()
            }.onFailure { err ->
                _uiState.update { it.copy(isLoading = false, error = err.message) }
            }
        }
    }

    fun addBankAccount(bankName: String, accountNumber: String, ifsc: String, holder: String, upi: String) {
        val userId = _currentUserId.value
        viewModelScope.launch {
            repository.addBankAccount(
                BankAccountEntity(
                    userId = userId,
                    bankName = bankName,
                    accountNumber = accountNumber,
                    ifsc = ifsc,
                    accountHolder = holder,
                    upiId = upi,
                    isPrimary = _uiState.value.bankAccounts.isEmpty()
                )
            )
            _uiState.update { it.copy(message = "Bank account added successfully") }
        }
    }

    fun deleteBankAccount(id: Long) {
        viewModelScope.launch {
            repository.deleteBankAccount(id)
            _uiState.update { it.copy(message = "Bank account removed") }
        }
    }

    fun submitKyc(docType: String, docNumber: String, onSuccess: () -> Unit) {
        val userId = _currentUserId.value
        viewModelScope.launch {
            repository.submitKyc(userId, docType, docNumber)
            _uiState.update { it.copy(message = "KYC documents submitted for review") }
            onSuccess()
        }
    }

    fun markNotificationsRead() {
        val userId = _currentUserId.value
        viewModelScope.launch {
            repository.markAllNotificationsRead(userId)
        }
    }

    fun clearMessage() {
        _uiState.update { it.copy(message = null, error = null) }
    }

    fun getOptionChain(symbol: String): Flow<List<OptionStrikeEntity>> = repository.getOptionChain(symbol)
}
