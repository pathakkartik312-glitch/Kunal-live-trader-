package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CandlestickChart
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.TradeGreen
import com.example.ui.theme.TradeRed
import java.util.Locale
import kotlin.random.Random

data class CandleData(
    val timeLabel: String,
    val open: Double,
    val high: Double,
    val low: Double,
    val close: Double,
    val volume: Long
)

@Composable
fun StockChart(
    basePrice: Double,
    modifier: Modifier = Modifier
) {
    var selectedTimeframe by remember { mutableStateOf("1D") }
    var isCandleMode by remember { mutableStateOf(true) }
    var touchIndex by remember { mutableStateOf<Int?>(null) }

    // Generate realistic historical candle data points based on timeframe and base price
    val candleList = remember(basePrice, selectedTimeframe) {
        generateChartData(basePrice, selectedTimeframe)
    }

    val activeCandle = if (touchIndex != null && touchIndex!! in candleList.indices) {
        candleList[touchIndex!!]
    } else {
        candleList.lastOrNull()
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
            .padding(14.dp)
    ) {
        // Chart Header with active price info & chart type toggles
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                val currentPrice = activeCandle?.close ?: basePrice
                val openRef = candleList.firstOrNull()?.open ?: basePrice
                val diff = currentPrice - openRef
                val diffPct = (diff / openRef) * 100.0
                val isUp = diff >= 0

                Text(
                    text = formatInr(currentPrice),
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = "${if (isUp) "+" else ""}${String.format(Locale.ENGLISH, "%.2f", diff)} (${if (isUp) "+" else ""}${String.format(Locale.ENGLISH, "%.2f", diffPct)}%)",
                        color = if (isUp) TradeGreen else TradeRed,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = "• ${activeCandle?.timeLabel ?: "Live"}",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 11.sp
                    )
                }
            }

            // Candlestick vs Line Chart Switcher
            Row(
                modifier = Modifier
                    .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(8.dp))
                    .padding(2.dp),
                horizontalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                IconButton(
                    onClick = { isCandleMode = true },
                    modifier = Modifier.size(32.dp).testTag("candlestick_toggle")
                ) {
                    Icon(
                        imageVector = Icons.Default.CandlestickChart,
                        contentDescription = "Candlestick Chart",
                        tint = if (isCandleMode) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                        modifier = Modifier.size(18.dp)
                    )
                }
                IconButton(
                    onClick = { isCandleMode = false },
                    modifier = Modifier.size(32.dp).testTag("line_toggle")
                ) {
                    Icon(
                        imageVector = Icons.Default.ShowChart,
                        contentDescription = "Line Chart",
                        tint = if (!isCandleMode) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Main Chart Canvas
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(200.dp)
                .pointerInput(candleList) {
                    detectTapGestures(
                        onPress = { offset ->
                            val itemWidth = size.width / candleList.size.toFloat()
                            val idx = (offset.x / itemWidth).toInt().coerceIn(0, candleList.size - 1)
                            touchIndex = idx
                            tryAwaitRelease()
                            touchIndex = null
                        }
                    )
                }
                .pointerInput(candleList) {
                    detectDragGestures(
                        onDragStart = { offset ->
                            val itemWidth = size.width / candleList.size.toFloat()
                            val idx = (offset.x / itemWidth).toInt().coerceIn(0, candleList.size - 1)
                            touchIndex = idx
                        },
                        onDragEnd = { touchIndex = null },
                        onDragCancel = { touchIndex = null },
                        onDrag = { change, _ ->
                            val itemWidth = size.width / candleList.size.toFloat()
                            val idx = (change.position.x / itemWidth).toInt().coerceIn(0, candleList.size - 1)
                            touchIndex = idx
                        }
                    )
                }
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                if (candleList.isEmpty()) return@Canvas

                val minPrice = candleList.minOf { it.low } * 0.998
                val maxPrice = candleList.maxOf { it.high } * 1.002
                val priceRange = (maxPrice - minPrice).coerceAtLeast(1.0)

                val count = candleList.size
                val itemWidth = size.width / count
                val candleBodyWidth = (itemWidth * 0.65f).coerceAtLeast(2f)

                // Draw subtle horizontal grid lines
                val gridLines = 4
                for (i in 0..gridLines) {
                    val y = size.height * (i.toFloat() / gridLines)
                    drawLine(
                        color = Color.White.copy(alpha = 0.05f),
                        start = Offset(0f, y),
                        end = Offset(size.width, y),
                        strokeWidth = 1.dp.toPx()
                    )
                }

                if (isCandleMode) {
                    // Render Candlesticks
                    candleList.forEachIndexed { i, candle ->
                        val isBullish = candle.close >= candle.open
                        val color = if (isBullish) TradeGreen else TradeRed

                        val centerX = (i * itemWidth) + (itemWidth / 2f)
                        val highY = size.height - (((candle.high - minPrice) / priceRange) * size.height).toFloat()
                        val lowY = size.height - (((candle.low - minPrice) / priceRange) * size.height).toFloat()
                        val openY = size.height - (((candle.open - minPrice) / priceRange) * size.height).toFloat()
                        val closeY = size.height - (((candle.close - minPrice) / priceRange) * size.height).toFloat()

                        // Draw wick
                        drawLine(
                            color = color,
                            start = Offset(centerX, highY),
                            end = Offset(centerX, lowY),
                            strokeWidth = 1.5.dp.toPx(),
                            cap = StrokeCap.Round
                        )

                        // Draw candle body
                        val topY = Math.min(openY, closeY)
                        val bottomY = Math.max(openY, closeY)
                        val bodyHeight = (bottomY - topY).coerceAtLeast(2.dp.toPx())

                        drawRect(
                            color = color,
                            topLeft = Offset(centerX - (candleBodyWidth / 2f), topY),
                            size = Size(candleBodyWidth, bodyHeight)
                        )
                    }
                } else {
                    // Render Line Chart with gradient area
                    val linePath = Path()
                    val areaPath = Path()

                    candleList.forEachIndexed { i, candle ->
                        val x = (i * itemWidth) + (itemWidth / 2f)
                        val y = size.height - (((candle.close - minPrice) / priceRange) * size.height).toFloat()

                        if (i == 0) {
                            linePath.moveTo(x, y)
                            areaPath.moveTo(x, size.height)
                            areaPath.lineTo(x, y)
                        } else {
                            linePath.lineTo(x, y)
                            areaPath.lineTo(x, y)
                        }
                    }
                    val lastX = ((candleList.size - 1) * itemWidth) + (itemWidth / 2f)
                    areaPath.lineTo(lastX, size.height)
                    areaPath.close()

                    val isUpTrend = (candleList.last().close >= candleList.first().open)
                    val lineColor = if (isUpTrend) TradeGreen else TradeRed

                    // Draw area gradient
                    drawPath(
                        path = areaPath,
                        brush = Brush.verticalGradient(
                            colors = listOf(lineColor.copy(alpha = 0.35f), Color.Transparent),
                            startY = 0f,
                            endY = size.height
                        )
                    )

                    // Draw main stroke
                    drawPath(
                        path = linePath,
                        color = lineColor,
                        style = Stroke(width = 2.5.dp.toPx(), cap = StrokeCap.Round)
                    )
                }

                // Crosshair tracking line if touched
                if (touchIndex != null && touchIndex!! in candleList.indices) {
                    val idx = touchIndex!!
                    val candle = candleList[idx]
                    val x = (idx * itemWidth) + (itemWidth / 2f)
                    val y = size.height - (((candle.close - minPrice) / priceRange) * size.height).toFloat()

                    // Vertical dashed-like crosshair
                    drawLine(
                        color = Color.White.copy(alpha = 0.5f),
                        start = Offset(x, 0f),
                        end = Offset(x, size.height),
                        strokeWidth = 1.dp.toPx()
                    )

                    // Dot at price point
                    drawCircle(
                        color = Color.White,
                        radius = 4.dp.toPx(),
                        center = Offset(x, y)
                    )
                    drawCircle(
                        color = if (candle.close >= candle.open) TradeGreen else TradeRed,
                        radius = 2.5.dp.toPx(),
                        center = Offset(x, y)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Timeframe selector bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            val timeframes = listOf("1D", "1W", "1M", "1Y", "5Y")
            timeframes.forEach { tf ->
                val isSelected = (selectedTimeframe == tf)
                TextButton(
                    onClick = { selectedTimeframe = tf },
                    modifier = Modifier.height(32.dp).testTag("tf_$tf"),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 0.dp),
                    colors = ButtonDefaults.textButtonColors(
                        containerColor = if (isSelected) MaterialTheme.colorScheme.primaryContainer else Color.Transparent,
                        contentColor = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                    ),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = tf,
                        fontSize = 12.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                    )
                }
            }
        }
    }
}

private fun generateChartData(basePrice: Double, timeframe: String): List<CandleData> {
    val count = when (timeframe) {
        "1D" -> 25
        "1W" -> 28
        "1M" -> 30
        "1Y" -> 36
        "5Y" -> 40
        else -> 25
    }

    val result = mutableListOf<CandleData>()
    var current = basePrice * (when (timeframe) {
        "1D" -> 0.985
        "1W" -> 0.96
        "1M" -> 0.92
        "1Y" -> 0.82
        "5Y" -> 0.65
        else -> 0.985
    })

    val rand = Random(basePrice.toInt() + timeframe.hashCode())

    for (i in 0 until count) {
        val delta = current * (rand.nextDouble(-0.02, 0.024))
        val open = current
        val close = (current + delta).coerceAtLeast(1.0)
        val high = Math.max(open, close) + (Math.abs(delta) * rand.nextDouble(0.2, 0.8))
        val low = Math.min(open, close) - (Math.abs(delta) * rand.nextDouble(0.2, 0.8))
        val vol = rand.nextLong(15000, 850000)

        val timeLabel = when (timeframe) {
            "1D" -> "${9 + (i * 6 / 25)}:${String.format(Locale.ENGLISH, "%02d", (i * 15) % 60)}"
            "1W" -> "Day ${i + 1}"
            "1M" -> "Sep ${i + 1}"
            "1Y" -> "Month ${i + 1}"
            "5Y" -> "202${i / 8}"
            else -> "$i"
        }

        result.add(
            CandleData(
                timeLabel = timeLabel,
                open = Math.round(open * 100.0) / 100.0,
                high = Math.round(high * 100.0) / 100.0,
                low = Math.round(low * 100.0) / 100.0,
                close = Math.round(close * 100.0) / 100.0,
                volume = vol
            )
        )
        current = close
    }
    return result
}
