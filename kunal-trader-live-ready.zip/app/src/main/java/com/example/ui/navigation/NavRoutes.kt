package com.example.ui.navigation

object NavRoutes {
    const val SPLASH = "splash"
    const val LOGIN = "login"
    const val SIGNUP = "signup"
    const val FORGOT_PASSWORD = "forgot_password"
    const val OTP_VERIFY = "otp_verify/{phone}"
    const val MAIN_APP = "main_app"
    const val INSTRUMENT_DETAIL = "instrument_detail/{symbol}"
    const val OPTION_CHAIN = "option_chain/{symbol}"
    const val DEPOSIT = "deposit"
    const val WITHDRAW = "withdraw"
    const val BANK_ACCOUNTS = "bank_accounts"
    const val KYC_UPLOAD = "kyc_upload"
    const val NOTIFICATIONS = "notifications"
    const val SUPPORT = "support"

    // Admin Routes
    const val ADMIN_LOGIN = "admin_login"
    const val ADMIN_DASHBOARD = "admin_dashboard"
    const val ADMIN_USERS = "admin_users"
    const val ADMIN_USER_DETAIL = "admin_user_detail"
    const val ADMIN_KYC = "admin_kyc"
    const val ADMIN_DEPOSITS = "admin_deposits"
    const val ADMIN_WITHDRAWALS = "admin_withdrawals"
    const val ADMIN_BANKS = "admin_banks"
    const val ADMIN_INSTRUMENTS = "admin_instruments"
    const val ADMIN_TRADES = "admin_trades"
    const val ADMIN_AUDIT_LOGS = "admin_audit_logs"
    const val ADMIN_NOTIFICATIONS = "admin_notifications"

    fun otpVerify(phone: String): String {
        val encoded = try { java.net.URLEncoder.encode(phone, "UTF-8") } catch (e: Exception) { phone }
        return "otp_verify/$encoded"
    }

    fun instrumentDetail(symbol: String): String {
        val encoded = try { java.net.URLEncoder.encode(symbol, "UTF-8") } catch (e: Exception) { symbol }
        return "instrument_detail/$encoded"
    }

    fun optionChain(symbol: String): String {
        val encoded = try { java.net.URLEncoder.encode(symbol, "UTF-8") } catch (e: Exception) { symbol }
        return "option_chain/$encoded"
    }
}
