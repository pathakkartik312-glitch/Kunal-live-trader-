package com.example.ui.screens

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.screens.home.HomeScreen
import com.example.ui.screens.markets.FnoScreen
import com.example.ui.screens.markets.McxScreen
import com.example.ui.screens.orders.OrdersPositionsHoldingsScreen
import com.example.ui.screens.profile.ProfileScreen
import com.example.ui.screens.wallet.WalletScreen
import com.example.ui.viewmodel.TradingViewModel

sealed class BottomNavItem(
    val route: String,
    val title: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector
) {
    object Watchlist : BottomNavItem("watchlist", "Watchlist", Icons.Filled.TrendingUp, Icons.Outlined.TrendingUp)
    object Fno : BottomNavItem("fno", "F&O", Icons.Filled.CandlestickChart, Icons.Outlined.CandlestickChart)
    object Mcx : BottomNavItem("mcx", "MCX", Icons.Filled.Diamond, Icons.Outlined.Diamond)
    object Orders : BottomNavItem("orders", "Orders", Icons.Filled.ReceiptLong, Icons.Outlined.ReceiptLong)
    object Profile : BottomNavItem("profile", "Profile", Icons.Filled.Person, Icons.Outlined.Person)
}

@Composable
fun MainAppScreen(
    viewModel: TradingViewModel,
    onNavigateInstrument: (symbol: String) -> Unit,
    onNavigateOptionChain: (symbol: String) -> Unit,
    onNavigateDeposit: () -> Unit,
    onNavigateWithdraw: () -> Unit,
    onNavigateBanks: () -> Unit,
    onNavigateKyc: () -> Unit,
    onNavigateNotifications: () -> Unit,
    onNavigateSupport: () -> Unit,
    onNavigateAdmin: () -> Unit,
    onLogout: () -> Unit
) {
    var currentTab by remember { mutableStateOf<BottomNavItem>(BottomNavItem.Watchlist) }
    val items = listOf(
        BottomNavItem.Watchlist,
        BottomNavItem.Fno,
        BottomNavItem.Mcx,
        BottomNavItem.Orders,
        BottomNavItem.Profile
    )

    Scaffold(
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface,
                tonalElevation = 6.dp
            ) {
                items.forEach { item ->
                    val isSelected = (currentTab == item)
                    NavigationBarItem(
                        selected = isSelected,
                        onClick = { currentTab = item },
                        icon = {
                            Icon(
                                imageVector = if (isSelected) item.selectedIcon else item.unselectedIcon,
                                contentDescription = item.title
                            )
                        },
                        label = { Text(item.title, fontSize = 11.sp) },
                        modifier = Modifier.testTag("nav_tab_${item.route}"),
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = MaterialTheme.colorScheme.primary,
                            selectedTextColor = MaterialTheme.colorScheme.primary,
                            indicatorColor = MaterialTheme.colorScheme.primaryContainer
                        )
                    )
                }
            }
        }
    ) { padding ->
        Surface(modifier = Modifier.padding(padding)) {
            when (currentTab) {
                BottomNavItem.Watchlist -> HomeScreen(
                    viewModel = viewModel,
                    onNavigateInstrument = onNavigateInstrument,
                    onNavigateDeposit = onNavigateDeposit,
                    onNavigateOptionChain = onNavigateOptionChain
                )
                BottomNavItem.Fno -> FnoScreen(
                    viewModel = viewModel,
                    onNavigateInstrument = onNavigateInstrument,
                    onNavigateOptionChain = onNavigateOptionChain
                )
                BottomNavItem.Mcx -> McxScreen(
                    viewModel = viewModel,
                    onNavigateInstrument = onNavigateInstrument,
                    onNavigateOptionChain = onNavigateOptionChain
                )
                BottomNavItem.Orders -> OrdersPositionsHoldingsScreen(
                    viewModel = viewModel,
                    onNavigateInstrument = onNavigateInstrument
                )
                BottomNavItem.Profile -> ProfileScreen(
                    viewModel = viewModel,
                    onNavigateKyc = onNavigateKyc,
                    onNavigateBanks = onNavigateBanks,
                    onNavigateNotifications = onNavigateNotifications,
                    onNavigateSupport = onNavigateSupport,
                    onNavigateAdmin = onNavigateAdmin,
                    onLogout = onLogout
                )
            }
        }
    }
}
