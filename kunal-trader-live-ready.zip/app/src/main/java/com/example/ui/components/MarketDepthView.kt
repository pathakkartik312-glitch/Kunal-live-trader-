package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.TradeGreen
import com.example.ui.theme.TradeGreenLight
import com.example.ui.theme.TradeRed
import com.example.ui.theme.TradeRedLight
import java.util.Locale
import kotlin.random.Random

data class DepthLevel(
    val bidOrders: Int,
    val bidQty: Long,
    val bidPrice: Double,
    val askPrice: Double,
    val askOrders: Int,
    val askQty: Long
)

@Composable
fun MarketDepthView(
    ltp: Double,
    modifier: Modifier = Modifier
) {
    val depthLevels = remember(ltp) {
        val rand = Random(ltp.toInt() + 42)
        val levels = mutableListOf<DepthLevel>()
        for (i in 1..5) {
            val bidP = ltp - (i * 0.15)
            val askP = ltp + (i * 0.15)
            levels.add(
                DepthLevel(
                    bidOrders = rand.nextInt(1, 18),
                    bidQty = rand.nextLong(200, 15000),
                    bidPrice = Math.round(bidP * 100.0) / 100.0,
                    askPrice = Math.round(askP * 100.0) / 100.0,
                    askOrders = rand.nextInt(1, 18),
                    askQty = rand.nextLong(200, 15000)
                )
            )
        }
        levels
    }

    val totalBidQty = depthLevels.sumOf { it.bidQty }
    val totalAskQty = depthLevels.sumOf { it.askQty }
    val total = (totalBidQty + totalAskQty).toFloat().coerceAtLeast(1f)
    val bidRatio = totalBidQty.toFloat() / total

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .padding(14.dp)
    ) {
        Text(
            text = "Market Depth (L2)",
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
        )

        Spacer(modifier = Modifier.height(10.dp))

        // Column Headers
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("Orders", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.weight(1f))
            Text("Bid Qty", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.weight(1f), textAlign = TextAlign.End)
            Text("Bid (₹)", fontSize = 11.sp, color = TradeGreen, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1.2f), textAlign = TextAlign.End)
            Spacer(modifier = Modifier.width(12.dp))
            Text("Ask (₹)", fontSize = 11.sp, color = TradeRed, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1.2f))
            Text("Ask Qty", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.weight(1f))
            Text("Orders", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.weight(1f), textAlign = TextAlign.End)
        }

        Spacer(modifier = Modifier.height(6.dp))

        // 5 Rows
        depthLevels.forEach { level ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 3.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("${level.bidOrders}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.weight(1f))
                Text(formatQuantity(level.bidQty), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface, modifier = Modifier.weight(1f), textAlign = TextAlign.End)
                Text(String.format(Locale.ENGLISH, "%.2f", level.bidPrice), fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = TradeGreen, modifier = Modifier.weight(1.2f), textAlign = TextAlign.End)
                Spacer(modifier = Modifier.width(12.dp))
                Text(String.format(Locale.ENGLISH, "%.2f", level.askPrice), fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = TradeRed, modifier = Modifier.weight(1.2f))
                Text(formatQuantity(level.askQty), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface, modifier = Modifier.weight(1f))
                Text("${level.askOrders}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.weight(1f), textAlign = TextAlign.End)
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Ratio Bar (Total Buy vs Total Sell)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = "Total Buy: ${formatQuantity(totalBidQty)} (${String.format(Locale.ENGLISH, "%.1f", bidRatio * 100)}%)",
                color = TradeGreen,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Total Sell: ${formatQuantity(totalAskQty)} (${String.format(Locale.ENGLISH, "%.1f", (1f - bidRatio) * 100)}%)",
                color = TradeRed,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )
        }

        Spacer(modifier = Modifier.height(4.dp))
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(6.dp)
                .clip(RoundedCornerShape(3.dp))
        ) {
            Box(
                modifier = Modifier
                    .weight(bidRatio.coerceIn(0.05f, 0.95f))
                    .fillMaxHeight()
                    .background(TradeGreen)
            )
            Box(
                modifier = Modifier
                    .weight((1f - bidRatio).coerceIn(0.05f, 0.95f))
                    .fillMaxHeight()
                    .background(TradeRed)
            )
        }
    }
}
