package com.example.ui.screens.details

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entities.InstrumentEntity
import com.example.ui.components.MarketDepthView
import com.example.ui.components.StockChart
import com.example.ui.components.formatInr
import com.example.ui.theme.TradeGreen
import com.example.ui.theme.TradeRed
import com.example.ui.viewmodel.TradingViewModel
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun IndexDetailScreen(
    symbol: String,
    viewModel: TradingViewModel,
    onNavigateBack: () -> Unit,
    onNavigateOptionChain: (symbol: String) -> Unit,
    onNavigateStock: (symbol: String) -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()
    val indexInst = uiState.instruments.find { it.symbol == symbol } ?: InstrumentEntity(
        symbol = symbol,
        name = if (symbol == "SENSEX") "BSE SENSEX 30 Benchmark Index" else if (symbol == "BANKNIFTY") "Nifty Bank Index" else "Nifty 50 Index",
        segment = "INDEX",
        exchange = if (symbol == "SENSEX") "BSE" else "NSE",
        ltp = if (symbol == "SENSEX") 83120.50 else if (symbol == "BANKNIFTY") 51840.20 else 25420.75,
        openPrice = if (symbol == "SENSEX") 82950.0 else if (symbol == "BANKNIFTY") 51700.0 else 25380.0,
        highPrice = if (symbol == "SENSEX") 83300.0 else if (symbol == "BANKNIFTY") 52050.0 else 25490.0,
        lowPrice = if (symbol == "SENSEX") 82900.0 else if (symbol == "BANKNIFTY") 51650.0 else 25350.0,
        closePrice = if (symbol == "SENSEX") 82890.0 else if (symbol == "BANKNIFTY") 51680.0 else 25360.0,
        change = if (symbol == "SENSEX") 230.50 else if (symbol == "BANKNIFTY") 160.20 else 60.75,
        changePercent = 0.28
    )

    val isUp = indexInst.change >= 0

    // Filter constituent stocks for this index
    val constituentStocks = remember(uiState.instruments, symbol) {
        when (symbol) {
            "SENSEX" -> uiState.instruments.filter { it.indexCategory == "SENSEX" && it.segment == "CASH" }
            "BANKNIFTY" -> uiState.instruments.filter { it.indexCategory == "BANKNIFTY" && it.segment == "CASH" }
            else -> uiState.instruments.filter { it.indexCategory == "NIFTY 50" && it.segment == "CASH" }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(indexInst.symbol, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(MaterialTheme.colorScheme.primaryContainer)
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = indexInst.exchange,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                        Text(indexInst.name, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        },
        bottomBar = {
            Surface(
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 8.dp
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 10.dp)
                        .navigationBarsPadding(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Button(
                        onClick = { onNavigateOptionChain(indexInst.symbol) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("index_view_option_chain_btn"),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.TableChart, contentDescription = null, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "View ${indexInst.symbol} Option Chain",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp)
        ) {
            // Index Hero Header Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("Spot Price", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(
                                    text = formatInr(indexInst.ltp),
                                    fontSize = 24.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("Today's Change", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(
                                    text = "${if (isUp) "+" else ""}${String.format(Locale.ENGLISH, "%.2f", indexInst.change)} (${if (isUp) "+" else ""}${String.format(Locale.ENGLISH, "%.2f", indexInst.changePercent)}%)",
                                    fontSize = 17.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isUp) TradeGreen else TradeRed
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))
                        Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                        Spacer(modifier = Modifier.height(12.dp))

                        // Fast Option Chain Hero Action Button
                        FilledTonalButton(
                            onClick = { onNavigateOptionChain(indexInst.symbol) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(44.dp)
                                .testTag("hero_option_chain_${indexInst.symbol}"),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.FormatListNumbered, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Open ${indexInst.symbol} Option Chain (Calls & Puts)", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            item { Spacer(modifier = Modifier.height(14.dp)) }

            // Candlestick / Line Chart
            item {
                StockChart(
                    basePrice = indexInst.ltp,
                    modifier = Modifier.fillMaxWidth()
                )
            }

            item { Spacer(modifier = Modifier.height(14.dp)) }

            // Market Depth
            item {
                MarketDepthView(
                    ltp = indexInst.ltp,
                    modifier = Modifier.fillMaxWidth()
                )
            }

            item { Spacer(modifier = Modifier.height(16.dp)) }

            // Key Statistics & Day Range
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text("Day's Range & Key Stats", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text("Day Low", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(formatInr(indexInst.lowPrice), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("Day High", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(formatInr(indexInst.highPrice), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))
                        Row(modifier = Modifier.fillMaxWidth()) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Open", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(formatInr(indexInst.openPrice), fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                                Spacer(modifier = Modifier.height(8.dp))
                                Text("Prev Close", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(formatInr(indexInst.closePrice), fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                            }
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Exchange", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(indexInst.exchange, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                                Spacer(modifier = Modifier.height(8.dp))
                                Text("Derivatives", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text("F&O Available (Weekly/Monthly)", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary)
                            }
                        }
                    }
                }
            }

            item { Spacer(modifier = Modifier.height(16.dp)) }

            // Index Constituents Header
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "${indexInst.symbol} Constituent Stocks (${constituentStocks.size})",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                }
            }

            item { Spacer(modifier = Modifier.height(8.dp)) }

            // Constituent Stocks List
            items(constituentStocks, key = { it.symbol }) { stock ->
                val stockUp = stock.change >= 0
                Card(
                    onClick = { onNavigateStock(stock.symbol) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 3.dp)
                        .testTag("constituent_stock_${stock.symbol}"),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(stock.symbol, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                            Text(stock.name, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(formatInr(stock.ltp), fontSize = 14.sp, fontWeight = FontWeight.Bold)
                            Text(
                                text = "${if (stockUp) "+" else ""}${String.format(Locale.ENGLISH, "%.2f", stock.change)} (${if (stockUp) "+" else ""}${String.format(Locale.ENGLISH, "%.2f", stock.changePercent)}%)",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (stockUp) TradeGreen else TradeRed
                            )
                        }
                    }
                }
            }

            item { Spacer(modifier = Modifier.height(20.dp)) }
        }
    }
}
