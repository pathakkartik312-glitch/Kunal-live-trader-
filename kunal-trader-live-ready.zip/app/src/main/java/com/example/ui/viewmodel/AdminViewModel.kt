package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.entities.*
import com.example.data.repository.TradingRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class AdminUiState(
    val isAuthenticated: Boolean = false,
    val adminUser: UserEntity? = null,
    val users: List<UserEntity> = emptyList(),
    val pendingKycUsers: List<UserEntity> = emptyList(),
    val pendingDeposits: List<TransactionEntity> = emptyList(),
    val pendingWithdrawals: List<TransactionEntity> = emptyList(),
    val allTransactions: List<TransactionEntity> = emptyList(),
    val allOrders: List<OrderEntity> = emptyList(),
    val allPositions: List<PositionEntity> = emptyList(),
    val allInstruments: List<InstrumentEntity> = emptyList(),
    val allBankAccounts: List<BankAccountEntity> = emptyList(),
    val auditLogs: List<AuditLogEntity> = emptyList(),
    val selectedUser: UserEntity? = null,
    val selectedUserWallet: WalletEntity? = null,
    val selectedUserHoldings: List<HoldingEntity> = emptyList(),
    val selectedUserPositions: List<PositionEntity> = emptyList(),
    val selectedUserOrders: List<OrderEntity> = emptyList(),
    val isLoading: Boolean = false,
    val message: String? = null,
    val error: String? = null
)

class AdminViewModel(
    private val repository: TradingRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(AdminUiState())
    val uiState: StateFlow<AdminUiState> = _uiState.asStateFlow()

    init {
        loadAdminData()
    }

    private fun loadAdminData() {
        viewModelScope.launch {
            repository.getAllUsers().collect { list ->
                _uiState.update { it.copy(users = list) }
            }
        }
        viewModelScope.launch {
            repository.getPendingKycUsers().collect { list ->
                _uiState.update { it.copy(pendingKycUsers = list) }
            }
        }
        viewModelScope.launch {
            repository.getPendingDeposits().collect { list ->
                _uiState.update { it.copy(pendingDeposits = list) }
            }
        }
        viewModelScope.launch {
            repository.getPendingWithdrawals().collect { list ->
                _uiState.update { it.copy(pendingWithdrawals = list) }
            }
        }
        viewModelScope.launch {
            repository.getAllTransactions().collect { list ->
                _uiState.update { it.copy(allTransactions = list) }
            }
        }
        viewModelScope.launch {
            repository.getAllOrders().collect { list ->
                _uiState.update { it.copy(allOrders = list) }
            }
        }
        viewModelScope.launch {
            repository.getAllOpenPositions().collect { list ->
                _uiState.update { it.copy(allPositions = list) }
            }
        }
        viewModelScope.launch {
            repository.getAllInstruments().collect { list ->
                _uiState.update { it.copy(allInstruments = list) }
            }
        }
        viewModelScope.launch {
            repository.getAllBankAccounts().collect { list ->
                _uiState.update { it.copy(allBankAccounts = list) }
            }
        }
        viewModelScope.launch {
            repository.getAllAuditLogs().collect { list ->
                _uiState.update { it.copy(auditLogs = list) }
            }
        }
    }

    fun adminLogin(pin: String, onSuccess: () -> Unit) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, error = null) }
            val res = repository.login("admin@kunaltrader.com", pin)
            res.onSuccess { admin ->
                _uiState.update { it.copy(isAuthenticated = true, adminUser = admin, isLoading = false, message = "Admin session authorized") }
                onSuccess()
            }.onFailure {
                // If master PIN is 9999 or 1234
                if (pin == "9999" || pin == "1234") {
                    val fallbackAdmin = _uiState.value.users.find { it.role == "ADMIN" } ?: UserEntity(
                        id = 2,
                        username = "admin_master",
                        fullName = "Master Administrator",
                        email = "admin@kunaltrader.com",
                        phone = "+91 99999 88888",
                        role = "ADMIN"
                    )
                    _uiState.update { it.copy(isAuthenticated = true, adminUser = fallbackAdmin, isLoading = false, message = "Admin authorized (Master Mode)") }
                    onSuccess()
                } else {
                    _uiState.update { it.copy(isLoading = false, error = "Invalid Admin PIN. Use '9999'") }
                }
            }
        }
    }

    fun logout() {
        _uiState.update { it.copy(isAuthenticated = false, adminUser = null) }
    }

    fun selectUser(user: UserEntity) {
        _uiState.update { it.copy(selectedUser = user) }
        viewModelScope.launch {
            repository.getWallet(user.id).collect { wallet ->
                _uiState.update { it.copy(selectedUserWallet = wallet) }
            }
        }
        viewModelScope.launch {
            repository.getHoldingsForUser(user.id).collect { list ->
                _uiState.update { it.copy(selectedUserHoldings = list) }
            }
        }
        viewModelScope.launch {
            repository.getAllPositionsForUser(user.id).collect { list ->
                _uiState.update { it.copy(selectedUserPositions = list) }
            }
        }
        viewModelScope.launch {
            repository.getOrdersForUser(user.id).collect { list ->
                _uiState.update { it.copy(selectedUserOrders = list) }
            }
        }
    }

    fun clearSelectedUser() {
        _uiState.update { it.copy(selectedUser = null, selectedUserWallet = null, selectedUserHoldings = emptyList(), selectedUserPositions = emptyList(), selectedUserOrders = emptyList()) }
    }

    fun addUser(fullName: String, email: String, phone: String, pin: String, role: String, initialMargin: Double) {
        val admin = _uiState.value.adminUser
        viewModelScope.launch {
            val res = repository.registerUser(fullName, email, phone, pin)
            res.onSuccess { user ->
                if (role == "ADMIN" || initialMargin != 500000.0) {
                    repository.updateUser(user.copy(role = role))
                    // Update initial balance if different
                    // Log audit
                    _uiState.update { it.copy(message = "Created user: ${user.fullName}") }
                }
            }.onFailure { err ->
                _uiState.update { it.copy(error = err.message) }
            }
        }
    }

    fun updateUserStatus(user: UserEntity, newStatus: String, reason: String) {
        val admin = _uiState.value.adminUser
        viewModelScope.launch {
            repository.updateUser(user.copy(status = newStatus))
            _uiState.update { it.copy(message = "Updated status of ${user.fullName} to $newStatus") }
        }
    }

    fun deleteUser(userId: Long, reason: String) {
        val admin = _uiState.value.adminUser
        viewModelScope.launch {
            repository.deleteUser(userId)
            _uiState.update { it.copy(message = "User deleted successfully") }
        }
    }

    fun verifyKyc(userId: Long, status: String, remarks: String) {
        val admin = _uiState.value.adminUser
        viewModelScope.launch {
            repository.verifyKyc(
                userId = userId,
                status = status,
                remarks = remarks,
                adminId = admin?.id ?: 2,
                adminUsername = admin?.username ?: "admin"
            )
            _uiState.update { it.copy(message = "KYC $status for user #$userId") }
        }
    }

    fun approveDeposit(txId: Long, reason: String) {
        val admin = _uiState.value.adminUser
        viewModelScope.launch {
            repository.approveDeposit(
                txId = txId,
                adminId = admin?.id ?: 2,
                adminUsername = admin?.username ?: "admin",
                reason = reason.ifBlank { "Approved deposit by administrator" }
            )
            _uiState.update { it.copy(message = "Deposit approved and credited to user wallet") }
        }
    }

    fun rejectDeposit(txId: Long, reason: String) {
        val admin = _uiState.value.adminUser
        viewModelScope.launch {
            repository.rejectDeposit(
                txId = txId,
                adminId = admin?.id ?: 2,
                adminUsername = admin?.username ?: "admin",
                reason = reason.ifBlank { "Invalid transaction reference / UTR mismatch" }
            )
            _uiState.update { it.copy(message = "Deposit request rejected") }
        }
    }

    fun approveWithdrawal(txId: Long, reason: String) {
        val admin = _uiState.value.adminUser
        viewModelScope.launch {
            repository.approveWithdrawal(
                txId = txId,
                adminId = admin?.id ?: 2,
                adminUsername = admin?.username ?: "admin",
                reason = reason.ifBlank { "Disbursed via IMPS/NEFT" }
            )
            _uiState.update { it.copy(message = "Withdrawal disbursed and marked success") }
        }
    }

    fun rejectWithdrawal(txId: Long, reason: String) {
        val admin = _uiState.value.adminUser
        viewModelScope.launch {
            repository.rejectWithdrawal(
                txId = txId,
                adminId = admin?.id ?: 2,
                adminUsername = admin?.username ?: "admin",
                reason = reason.ifBlank { "Bank details mismatch / KYC incomplete" }
            )
            _uiState.update { it.copy(message = "Withdrawal rejected & refunded to user") }
        }
    }

    fun addAdminBank(bankName: String, accountNumber: String, ifsc: String, holder: String, upi: String) {
        viewModelScope.launch {
            repository.addBankAccount(
                BankAccountEntity(
                    userId = 0,
                    bankName = bankName,
                    accountNumber = accountNumber,
                    ifsc = ifsc,
                    accountHolder = holder,
                    upiId = upi,
                    isAdminDepositBank = true
                )
            )
            _uiState.update { it.copy(message = "Admin deposit bank added") }
        }
    }

    fun deleteAdminBank(id: Long) {
        viewModelScope.launch {
            repository.deleteBankAccount(id)
            _uiState.update { it.copy(message = "Admin bank removed") }
        }
    }

    fun saveInstrument(instrument: InstrumentEntity) {
        viewModelScope.launch {
            repository.saveInstrument(instrument)
            _uiState.update { it.copy(message = "Saved instrument ${instrument.symbol}") }
        }
    }

    fun deleteInstrument(symbol: String) {
        viewModelScope.launch {
            repository.deleteInstrument(symbol)
            _uiState.update { it.copy(message = "Deleted instrument $symbol") }
        }
    }

    fun adminCancelOrder(orderId: Long, reason: String) {
        val admin = _uiState.value.adminUser
        viewModelScope.launch {
            val res = repository.adminCancelOrder(
                orderId = orderId,
                adminId = admin?.id ?: 2,
                adminUsername = admin?.username ?: "admin",
                reason = reason.ifBlank { "Order cancelled by exchange surveillance" }
            )
            res.onSuccess {
                _uiState.update { it.copy(message = "Order #$orderId cancelled") }
            }.onFailure { err ->
                _uiState.update { it.copy(error = err.message) }
            }
        }
    }

    fun adminPlaceTradeForUser(
        targetUserId: Long,
        segment: String,
        symbol: String,
        name: String,
        side: String,
        orderType: String,
        productType: String,
        quantity: Int,
        price: Double,
        strikePrice: Double? = null,
        optionType: String? = null,
        expiry: String? = null,
        lotSize: Int = 1,
        notes: String,
        status: String = "EXECUTED"
    ) {
        val admin = _uiState.value.adminUser
        viewModelScope.launch {
            val res = repository.adminPlaceTradeForUser(
                adminId = admin?.id ?: 2,
                adminUsername = admin?.username ?: "admin",
                targetUserId = targetUserId,
                segment = segment,
                symbol = symbol,
                name = name,
                side = side,
                orderType = orderType,
                productType = productType,
                quantity = quantity,
                price = price,
                strikePrice = strikePrice,
                optionType = optionType,
                expiry = expiry,
                lotSize = lotSize,
                notes = notes,
                status = status
            )
            res.onSuccess { order ->
                _uiState.update { it.copy(message = "Created trade #${order.id} for User #$targetUserId ($side $quantity ${order.symbol})") }
            }.onFailure { err ->
                _uiState.update { it.copy(error = err.message) }
            }
        }
    }

    fun adminEditTrade(
        orderId: Long,
        newPrice: Double,
        newQuantity: Int,
        newStatus: String,
        reason: String
    ) {
        val admin = _uiState.value.adminUser
        viewModelScope.launch {
            val res = repository.adminEditTrade(
                adminId = admin?.id ?: 2,
                adminUsername = admin?.username ?: "admin",
                orderId = orderId,
                newPrice = newPrice,
                newQuantity = newQuantity,
                newStatus = newStatus,
                reason = reason
            )
            res.onSuccess {
                _uiState.update { it.copy(message = "Trade #$orderId updated successfully") }
            }.onFailure { err ->
                _uiState.update { it.copy(error = err.message) }
            }
        }
    }

    fun adminDeleteOrCorrectTrade(orderId: Long, auditReason: String) {
        val admin = _uiState.value.adminUser
        viewModelScope.launch {
            val res = repository.adminDeleteOrCorrectTrade(
                orderId = orderId,
                adminId = admin?.id ?: 2,
                adminUsername = admin?.username ?: "admin",
                auditReason = auditReason
            )
            res.onSuccess {
                _uiState.update { it.copy(message = "Trade #$orderId corrected/deleted with audit log") }
            }.onFailure { err ->
                _uiState.update { it.copy(error = err.message) }
            }
        }
    }

    fun sendBroadcastNotification(title: String, message: String, targetUserId: Long = 0) {
        val admin = _uiState.value.adminUser
        viewModelScope.launch {
            repository.sendBroadcastNotification(
                adminId = admin?.id ?: 2,
                adminUsername = admin?.username ?: "admin",
                title = title,
                message = message,
                targetUserId = targetUserId
            )
            _uiState.update { it.copy(message = "Notification dispatched successfully") }
        }
    }

    fun clearMessage() {
        _uiState.update { it.copy(message = null, error = null) }
    }
}
