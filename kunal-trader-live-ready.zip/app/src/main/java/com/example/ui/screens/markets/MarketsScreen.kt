package com.example.ui.screens.markets

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entities.InstrumentEntity
import com.example.ui.components.EmptyStateView
import com.example.ui.components.OrderBottomSheet
import com.example.ui.components.formatInr
import com.example.ui.theme.TradeGreen
import com.example.ui.theme.TradeGreenLight
import com.example.ui.theme.TradeRed
import com.example.ui.theme.TradeRedLight
import com.example.ui.viewmodel.TradingViewModel
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MarketsScreen(
    viewModel: TradingViewModel,
    onNavigateInstrument: (symbol: String) -> Unit,
    onNavigateOptionChain: (symbol: String) -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()
    var selectedCategory by remember { mutableStateOf("Index Options") }
    var orderModalInstrument by remember { mutableStateOf<InstrumentEntity?>(null) }
    var orderModalSide by remember { mutableStateOf("BUY") }

    val categories = listOf(
        "Index Options",
        "Index Futures",
        "Stock Options",
        "Stock Futures",
        "Commodity Market",
        "Cash Equities"
    )

    val displayedInstruments = remember(uiState.instruments, selectedCategory) {
        when (selectedCategory) {
            "Index Options" -> uiState.instruments.filter { it.segment == "INDEX" }
            "Index Futures" -> uiState.instruments.filter { it.segment == "FNO_INDEX" }
            "Stock Options" -> uiState.instruments.filter { it.segment == "CASH" && (it.symbol == "RELIANCE" || it.symbol == "TCS" || it.symbol == "HDFCBANK" || it.symbol == "INFY" || it.symbol == "ICICIBANK") }
            "Stock Futures" -> uiState.instruments.filter { it.segment == "FNO_STOCK" }
            "Commodity Market" -> uiState.instruments.filter { it.segment == "COMMODITY" }
            "Cash Equities" -> uiState.instruments.filter { it.segment == "CASH" }
            else -> uiState.instruments
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text("F&O & Commodity Markets", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            // Category horizontal tabs
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 14.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                categories.forEach { cat ->
                    val isSel = selectedCategory == cat
                    FilterChip(
                        selected = isSel,
                        onClick = { selectedCategory = cat },
                        label = { Text(cat, fontSize = 12.sp, fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal) },
                        modifier = Modifier.testTag("market_cat_$cat"),
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                            selectedLabelColor = MaterialTheme.colorScheme.primary
                        )
                    )
                }
            }

            // Quick Option Chain Shortcut Banner for Index Options & Commodities
            if (selectedCategory == "Index Options" || selectedCategory == "Commodity Market" || selectedCategory == "Stock Options") {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 6.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.ViewStream,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary
                            )
                            Column {
                                Text(
                                    text = if (selectedCategory == "Commodity Market") "Commodity Option Chains" else "Live Option Chains",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Inspect all strike prices, CE/PE Greeks & Open Interest",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        Button(
                            onClick = {
                                val target = if (selectedCategory == "Commodity Market") "GOLD"
                                else if (selectedCategory == "Stock Options") "RELIANCE"
                                else "NIFTY 50"
                                onNavigateOptionChain(target)
                            },
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.testTag("open_option_chain_banner_btn")
                        ) {
                            Text("Open Chain", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // Market Instruments List
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp)
            ) {
                items(displayedInstruments, key = { it.symbol }) { inst ->
                    val isUp = inst.change >= 0

                    Card(
                        onClick = { onNavigateInstrument(inst.symbol) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .testTag("market_item_${inst.symbol}"),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Text(
                                        text = inst.symbol,
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(MaterialTheme.colorScheme.surfaceVariant)
                                            .padding(horizontal = 4.dp, vertical = 1.dp)
                                    ) {
                                        Text(
                                            text = if (inst.lotSize > 1) "Lot: ${inst.lotSize}" else inst.exchange,
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = inst.name,
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = formatInr(inst.ltp),
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "${if (isUp) "+" else ""}${String.format(Locale.ENGLISH, "%.2f", inst.change)} (${if (isUp) "+" else ""}${String.format(Locale.ENGLISH, "%.2f", inst.changePercent)}%)",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isUp) TradeGreen else TradeRed
                                )
                            }

                            Spacer(modifier = Modifier.width(10.dp))

                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                if (inst.segment == "INDEX" || inst.symbol == "RELIANCE" || inst.symbol == "GOLD" || inst.symbol == "CRUDEOIL") {
                                    IconButton(
                                        onClick = { onNavigateOptionChain(inst.symbol) },
                                        modifier = Modifier
                                            .size(32.dp)
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(MaterialTheme.colorScheme.primaryContainer)
                                    ) {
                                        Icon(Icons.Default.TableChart, contentDescription = "Option Chain", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                                    }
                                }

                                IconButton(
                                    onClick = {
                                        orderModalInstrument = inst
                                        orderModalSide = "BUY"
                                    },
                                    modifier = Modifier
                                        .size(32.dp)
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(TradeGreenLight)
                                ) {
                                    Text("B", color = TradeGreen, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                }

                                IconButton(
                                    onClick = {
                                        orderModalInstrument = inst
                                        orderModalSide = "SELL"
                                    },
                                    modifier = Modifier
                                        .size(32.dp)
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(TradeRedLight)
                                ) {
                                    Text("S", color = TradeRed, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (orderModalInstrument != null) {
        OrderBottomSheet(
            instrument = orderModalInstrument!!,
            initialSide = orderModalSide,
            availableMargin = uiState.wallet?.availableMargin ?: 500000.0,
            onDismiss = { orderModalInstrument = null },
            onSubmitOrder = { side, product, orderType, qty, limitP, triggerP ->
                viewModel.placeOrder(
                    symbol = orderModalInstrument!!.symbol,
                    name = orderModalInstrument!!.name,
                    segment = orderModalInstrument!!.segment,
                    orderType = orderType,
                    productType = product,
                    side = side,
                    quantity = qty,
                    price = limitP,
                    triggerPrice = triggerP
                )
                orderModalInstrument = null
            }
        )
    }
}
