package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Brand Colors - Kunal Trader
val BrandPrimary = Color(0xFF00C087) // Trading Green / Growth
val BrandPrimaryDark = Color(0xFF00A36C)
val BrandSecondary = Color(0xFF1E293B) // Slate Dark
val BrandAccent = Color(0xFF6366F1) // Indigo Accent
val GoldAccent = Color(0xFFF59E0B) // Commodity Gold

// Trading Semantic Colors
val TradeGreen = Color(0xFF00C087) // Bullish / Buy / Profit
val TradeGreenLight = Color(0x1A00C087)
val TradeRed = Color(0xFFEB5757) // Bearish / Sell / Loss
val TradeRedLight = Color(0x1AEB5757)

// Dark Theme Surfaces (Modern Trading Terminal)
val DarkBackground = Color(0xFF0B0F19)
val DarkSurface = Color(0xFF131B2E)
val DarkSurfaceVariant = Color(0xFF1E293B)
val DarkSurfaceBorder = Color(0xFF2E3D5B)

val TextPrimaryDark = Color(0xFFF8FAFC)
val TextSecondaryDark = Color(0xFF94A3B8)
val TextMutedDark = Color(0xFF64748B)

// Light Theme Surfaces
val LightBackground = Color(0xFFF4F6F9)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFEDF2F7)
val LightSurfaceBorder = Color(0xFFE2E8F0)

val TextPrimaryLight = Color(0xFF0F172A)
val TextSecondaryLight = Color(0xFF475569)
val TextMutedLight = Color(0xFF94A3B8)

// Status Badges
val StatusPending = Color(0xFFF59E0B)
val StatusApproved = Color(0xFF10B981)
val StatusRejected = Color(0xFFEF4444)
val StatusExecuted = Color(0xFF3B82F6)
