package com.example.ui.screens.details

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entities.InstrumentEntity
import com.example.ui.components.*
import com.example.ui.theme.TradeGreen
import com.example.ui.theme.TradeRed
import com.example.ui.viewmodel.TradingViewModel
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InstrumentDetailScreen(
    symbol: String,
    viewModel: TradingViewModel,
    onNavigateBack: () -> Unit,
    onNavigateOptionChain: (symbol: String) -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()
    val instrument = uiState.instruments.find { it.symbol == symbol } ?: InstrumentEntity(
        symbol = symbol,
        name = symbol,
        segment = "CASH",
        exchange = "NSE",
        ltp = 2500.0,
        openPrice = 2480.0,
        highPrice = 2520.0,
        lowPrice = 2470.0,
        closePrice = 2485.0,
        change = 15.0,
        changePercent = 0.60
    )

    val isInWatchlist = uiState.watchlistItems.any { it.symbol == instrument.symbol }
    var orderModalSide by remember { mutableStateOf<String?>(null) }

    val isUp = instrument.change >= 0

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(instrument.symbol, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                        Text("${instrument.name} • ${instrument.exchange}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = { viewModel.toggleWatchlist(instrument.symbol) }) {
                        Icon(
                            imageVector = if (isInWatchlist) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                            contentDescription = "Bookmark",
                            tint = if (isInWatchlist) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        },
        bottomBar = {
            Surface(
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 8.dp
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 10.dp)
                        .navigationBarsPadding(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    val hasOptionChain = instrument.segment == "INDEX" || 
                            instrument.segment == "COMMODITY" || 
                            instrument.segment == "CASH"

                    if (hasOptionChain) {
                        OutlinedButton(
                            onClick = { onNavigateOptionChain(instrument.symbol) },
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("detail_option_chain_btn"),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.TableChart, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Option Chain", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Button(
                        onClick = { orderModalSide = "BUY" },
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("detail_buy_btn"),
                        colors = ButtonDefaults.buttonColors(containerColor = TradeGreen),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("BUY", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    }

                    Button(
                        onClick = { orderModalSide = "SELL" },
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("detail_sell_btn"),
                        colors = ButtonDefaults.buttonColors(containerColor = TradeRed),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("SELL", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    }
                }
            }
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 10.dp)
        ) {
            // Interactive Candlestick / Line Chart Component
            StockChart(
                basePrice = instrument.ltp,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(16.dp))

            // 5-Level Market Depth Order Book
            MarketDepthView(
                ltp = instrument.ltp,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Performance & Key Stats Grid
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text("Performance & Limits", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(12.dp))

                    // Day Range Bar
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("Today's Low", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(formatInr(instrument.lowPrice), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("Today's High", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(formatInr(instrument.highPrice), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    val dayRange = (instrument.highPrice - instrument.lowPrice).coerceAtLeast(0.01)
                    val currentPos = ((instrument.ltp - instrument.lowPrice) / dayRange).toFloat().coerceIn(0.05f, 0.95f)

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(3.dp))
                            .background(MaterialTheme.colorScheme.surface)
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth(currentPos)
                                .fillMaxHeight()
                                .background(MaterialTheme.colorScheme.primary)
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Statistics Table
                    Row(modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Open", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(formatInr(instrument.openPrice), fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                            Spacer(modifier = Modifier.height(10.dp))
                            Text("Prev. Close", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(formatInr(instrument.closePrice), fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                            Spacer(modifier = Modifier.height(10.dp))
                            Text("Lower Circuit", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(formatInr(instrument.closePrice * 0.90), fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = TradeRed)
                        }

                        Column(modifier = Modifier.weight(1f)) {
                            Text("Volume", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(formatQuantity(instrument.volume), fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                            Spacer(modifier = Modifier.height(10.dp))
                            Text("Lot Size", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("${instrument.lotSize}", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                            Spacer(modifier = Modifier.height(10.dp))
                            Text("Upper Circuit", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(formatInr(instrument.closePrice * 1.10), fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = TradeGreen)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))
        }
    }

    if (orderModalSide != null) {
        OrderBottomSheet(
            instrument = instrument,
            initialSide = orderModalSide!!,
            availableMargin = uiState.wallet?.availableMargin ?: 500000.0,
            onDismiss = { orderModalSide = null },
            onSubmitOrder = { side, product, orderType, qty, limitP, triggerP ->
                viewModel.placeOrder(
                    symbol = instrument.symbol,
                    name = instrument.name,
                    segment = instrument.segment,
                    orderType = orderType,
                    productType = product,
                    side = side,
                    quantity = qty,
                    price = limitP,
                    triggerPrice = triggerP
                )
                orderModalSide = null
            }
        )
    }
}
