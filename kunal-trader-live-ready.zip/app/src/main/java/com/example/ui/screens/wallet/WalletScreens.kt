package com.example.ui.screens.wallet

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.ClipboardManager
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entities.TransactionEntity
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.TradingViewModel
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WalletScreen(
    viewModel: TradingViewModel,
    onNavigateDeposit: () -> Unit,
    onNavigateWithdraw: () -> Unit,
    onNavigateBanks: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()
    val wallet = uiState.wallet
    var selectedTxFilter by remember { mutableStateOf("ALL") }

    val filteredTransactions = remember(uiState.transactions, selectedTxFilter) {
        when (selectedTxFilter) {
            "DEPOSIT" -> uiState.transactions.filter { it.type == "DEPOSIT" }
            "WITHDRAWAL" -> uiState.transactions.filter { it.type == "WITHDRAWAL" }
            else -> uiState.transactions
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Demo Wallet & Funds", fontSize = 18.sp, fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(16.dp)
        ) {
            // Virtual Wallet Balance Hero Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Total Virtual Balance", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(MaterialTheme.colorScheme.primaryContainer)
                                    .padding(horizontal = 8.dp, vertical = 3.dp)
                            ) {
                                Text("DEMO FUNDS", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = formatInr(wallet?.totalBalance ?: 500000.0),
                            fontSize = 28.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = MaterialTheme.colorScheme.onSurface
                        )

                        Spacer(modifier = Modifier.height(14.dp))
                        Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
                        Spacer(modifier = Modifier.height(12.dp))

                        Row(modifier = Modifier.fillMaxWidth()) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Available Margin", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(formatInr(wallet?.availableMargin ?: 500000.0), fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TradeGreen)
                            }
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Used Margin", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(formatInr(wallet?.usedMargin ?: 0.0), fontSize = 14.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                            }
                        }
                    }
                }
            }

            // Quick Actions: Deposit, Withdraw, Bank Accounts
            item {
                Spacer(modifier = Modifier.height(14.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = onNavigateDeposit,
                        modifier = Modifier.weight(1f).height(46.dp).testTag("wallet_deposit_btn"),
                        colors = ButtonDefaults.buttonColors(containerColor = TradeGreen),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.AddCircle, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Add Funds", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }

                    OutlinedButton(
                        onClick = onNavigateWithdraw,
                        modifier = Modifier.weight(1f).height(46.dp).testTag("wallet_withdraw_btn"),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.ArrowOutward, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Withdraw", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            // Manage Bank Accounts row
            item {
                Spacer(modifier = Modifier.height(12.dp))
                OutlinedCard(
                    onClick = onNavigateBanks,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth().testTag("manage_banks_card")
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(Icons.Default.AccountBalance, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Column {
                                Text("Linked Bank Accounts", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                Text("${uiState.bankAccounts.size} account(s) added", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                        Icon(Icons.Default.ChevronRight, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }

            // Transaction History Section
            item {
                Spacer(modifier = Modifier.height(20.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Transaction History", fontSize = 15.sp, fontWeight = FontWeight.Bold)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("ALL", "DEPOSIT", "WITHDRAWAL").forEach { filter ->
                            val isSel = selectedTxFilter == filter
                            FilterChip(
                                selected = isSel,
                                onClick = { selectedTxFilter = filter },
                                label = { Text(if (filter == "ALL") "All" else filter.lowercase().capitalize(), fontSize = 11.sp) },
                                modifier = Modifier.height(28.dp)
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
            }

            if (filteredTransactions.isEmpty()) {
                item {
                    EmptyStateView(
                        icon = Icons.Default.Receipt,
                        title = "No Transactions Found",
                        subtitle = "Your deposit and withdrawal logs will appear here."
                    )
                }
            } else {
                items(filteredTransactions, key = { it.id }) { tx ->
                    TransactionItemRow(tx = tx)
                }
            }
        }
    }
}

@Composable
fun TransactionItemRow(tx: TransactionEntity) {
    val isDeposit = tx.type == "DEPOSIT"
    val timeFormat = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.ENGLISH)
    val timeStr = timeFormat.format(Date(tx.timestamp))

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(if (isDeposit) TradeGreenLight else TradeRedLight),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (isDeposit) Icons.Default.ArrowDownward else Icons.Default.ArrowUpward,
                        contentDescription = null,
                        tint = if (isDeposit) TradeGreen else TradeRed,
                        modifier = Modifier.size(20.dp)
                    )
                }
                Column {
                    Text(
                        text = if (isDeposit) "Funds Deposit" else "Funds Withdrawal",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "$timeStr • ${tx.bankAccount}",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    if (tx.utrOrRef.isNotBlank()) {
                        Text(
                            text = "Ref: ${tx.utrOrRef}",
                            fontSize = 10.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                        )
                    }
                }
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = "${if (isDeposit) "+" else "-"}${formatInr(tx.amount)}",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isDeposit) TradeGreen else TradeRed
                )
                Spacer(modifier = Modifier.height(2.dp))
                StatusBadge(status = tx.status)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DepositScreen(
    viewModel: TradingViewModel,
    onNavigateBack: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()
    var amountText by remember { mutableStateOf("100000") }
    var utrText by remember { mutableStateOf("") }
    var selectedAdminBank by remember { mutableStateOf("HDFC Bank (Demo Escrow)") }
    val clipboardManager: ClipboardManager = LocalClipboardManager.current

    val adminBanks = uiState.adminDepositBanks.ifEmpty {
        listOf(
            com.example.data.local.entities.BankAccountEntity(
                userId = 0L,
                bankName = "HDFC Bank (Demo Clearing)",
                accountNumber = "50200098765432",
                ifsc = "HDFC0000128",
                accountHolder = "KUNAL TRADER CLEARING CORP",
                upiId = "kunaltrader@hdfcbank",
                isAdminDepositBank = true
            )
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Deposit Demo Funds", fontSize = 18.sp, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
        ) {
            Text("Enter Deposit Amount", fontSize = 13.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(modifier = Modifier.height(6.dp))

            OutlinedTextField(
                value = amountText,
                onValueChange = { amountText = it.filter { c -> c.isDigit() } },
                leadingIcon = { Text("₹", fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 12.dp)) },
                modifier = Modifier.fillMaxWidth().testTag("deposit_amount_input"),
                shape = RoundedCornerShape(12.dp),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Preset Amount Chips
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf(50000, 100000, 200000, 500000).forEach { amt ->
                    FilterChip(
                        selected = amountText == amt.toString(),
                        onClick = { amountText = amt.toString() },
                        label = { Text("+₹${amt / 1000}K", fontSize = 11.sp) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Official Demo Escrow Account Card
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text("Official Demo Escrow Details", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.height(10.dp))

                    val activeBank = adminBanks.first()
                    Text("Account Holder: ${activeBank.accountHolder}", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("Bank: ${activeBank.bankName}", fontSize = 12.sp)
                    Text("A/C No: ${activeBank.accountNumber}", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Text("IFSC Code: ${activeBank.ifsc}", fontSize = 12.sp)
                    if (activeBank.upiId.isNotBlank()) {
                        Text("UPI ID: ${activeBank.upiId}", fontSize = 12.sp, color = TradeGreen, fontWeight = FontWeight.Bold)
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedButton(
                        onClick = {
                            clipboardManager.setText(AnnotatedString("${activeBank.accountNumber} ${activeBank.ifsc}"))
                        },
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Copy Bank Details", fontSize = 12.sp)
                    }
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            OutlinedTextField(
                value = utrText,
                onValueChange = { utrText = it },
                label = { Text("Enter 12-digit UTR / Reference No.") },
                placeholder = { Text("e.g. 482910394821 or UPI/1234") },
                modifier = Modifier.fillMaxWidth().testTag("deposit_utr_input"),
                shape = RoundedCornerShape(12.dp),
                singleLine = true
            )

            Spacer(modifier = Modifier.height(24.dp))

            Button(
                onClick = {
                    val amt = amountText.toDoubleOrNull() ?: 0.0
                    val finalUtr = utrText.ifBlank { "UPI/DEMO/${System.currentTimeMillis() % 1000000}" }
                    viewModel.requestDeposit(amt, finalUtr, selectedAdminBank, onNavigateBack)
                },
                enabled = (amountText.toDoubleOrNull() ?: 0.0) > 0,
                modifier = Modifier.fillMaxWidth().height(50.dp).testTag("submit_deposit_btn"),
                colors = ButtonDefaults.buttonColors(containerColor = TradeGreen),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("Submit Demo Deposit Request", fontSize = 15.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WithdrawScreen(
    viewModel: TradingViewModel,
    onNavigateBack: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()
    var amountText by remember { mutableStateOf("50000") }
    var selectedBank by remember { mutableStateOf(uiState.bankAccounts.firstOrNull()?.bankName ?: "Primary Bank") }

    val available = uiState.wallet?.availableMargin ?: 500000.0

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Withdraw Funds", fontSize = 18.sp, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
        ) {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text("Available for Withdrawal", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(formatInr(available), fontSize = 22.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            Text("Withdrawal Amount", fontSize = 13.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(modifier = Modifier.height(6.dp))

            OutlinedTextField(
                value = amountText,
                onValueChange = { amountText = it.filter { c -> c.isDigit() } },
                leadingIcon = { Text("₹", fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 12.dp)) },
                modifier = Modifier.fillMaxWidth().testTag("withdraw_amount_input"),
                shape = RoundedCornerShape(12.dp),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true
            )

            Spacer(modifier = Modifier.height(16.dp))

            Text("Select Destination Bank", fontSize = 13.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(modifier = Modifier.height(8.dp))

            if (uiState.bankAccounts.isEmpty()) {
                Text("No linked bank account. Default demo bank will be used.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            } else {
                uiState.bankAccounts.forEach { acc ->
                    val isSel = selectedBank == acc.bankName
                    OutlinedCard(
                        onClick = { selectedBank = acc.bankName },
                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                        colors = CardDefaults.outlinedCardColors(containerColor = if (isSel) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.2f) else MaterialTheme.colorScheme.surface)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(acc.bankName, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                Text("A/C: ${acc.accountNumber} • ${acc.ifsc}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            RadioButton(selected = isSel, onClick = { selectedBank = acc.bankName })
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            val amt = amountText.toDoubleOrNull() ?: 0.0
            Button(
                onClick = {
                    viewModel.requestWithdrawal(amt, selectedBank, onNavigateBack)
                },
                enabled = amt > 0 && amt <= available,
                modifier = Modifier.fillMaxWidth().height(50.dp).testTag("submit_withdraw_btn"),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("Submit Demo Withdrawal", fontSize = 15.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BankManagementScreen(
    viewModel: TradingViewModel,
    onNavigateBack: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()
    var showAddDialog by remember { mutableStateOf(false) }

    var bankName by remember { mutableStateOf("") }
    var accountNumber by remember { mutableStateOf("") }
    var ifsc by remember { mutableStateOf("") }
    var holder by remember { mutableStateOf(uiState.currentUser?.fullName ?: "Kunal Sharma") }
    var upi by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Bank Accounts", fontSize = 18.sp, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = { showAddDialog = true }, modifier = Modifier.testTag("add_bank_btn")) {
                        Icon(Icons.Default.Add, contentDescription = "Add Bank")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(16.dp)
        ) {
            if (uiState.bankAccounts.isEmpty()) {
                item {
                    EmptyStateView(
                        icon = Icons.Default.AccountBalance,
                        title = "No Bank Accounts",
                        subtitle = "Add your bank account for demo deposits and withdrawals.",
                        actionText = "Add Bank Account",
                        onAction = { showAddDialog = true }
                    )
                }
            } else {
                items(uiState.bankAccounts, key = { it.id }) { acc ->
                    Card(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(14.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(acc.bankName, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                                Text("A/C: ${acc.accountNumber}", fontSize = 13.sp)
                                Text("IFSC: ${acc.ifsc} • Holder: ${acc.accountHolder}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                if (acc.upiId.isNotBlank()) {
                                    Text("UPI: ${acc.upiId}", fontSize = 11.sp, color = TradeGreen)
                                }
                            }
                            IconButton(onClick = { viewModel.deleteBankAccount(acc.id) }) {
                                Icon(Icons.Default.Delete, contentDescription = "Delete", tint = TradeRed)
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAddDialog) {
        AlertDialog(
            onDismissRequest = { showAddDialog = false },
            title = { Text("Add Bank Account") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = bankName,
                        onValueChange = { bankName = it },
                        label = { Text("Bank Name") },
                        placeholder = { Text("e.g. Axis Bank, SBI, HDFC") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = accountNumber,
                        onValueChange = { accountNumber = it },
                        label = { Text("Account Number") },
                        modifier = Modifier.fillMaxWidth(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                    )
                    OutlinedTextField(
                        value = ifsc,
                        onValueChange = { ifsc = it.uppercase() },
                        label = { Text("IFSC Code") },
                        placeholder = { Text("e.g. UTIB0000123") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = holder,
                        onValueChange = { holder = it },
                        label = { Text("Account Holder Name") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = upi,
                        onValueChange = { upi = it },
                        label = { Text("UPI ID (Optional)") },
                        placeholder = { Text("e.g. user@okhdfcbank") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (bankName.isNotBlank() && accountNumber.isNotBlank() && ifsc.isNotBlank()) {
                            viewModel.addBankAccount(bankName, accountNumber, ifsc, holder, upi)
                            showAddDialog = false
                        }
                    }
                ) {
                    Text("Save Account")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddDialog = false }) { Text("Cancel") }
            }
        )
    }
}
