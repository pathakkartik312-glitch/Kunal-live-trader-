package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entities.InstrumentEntity
import com.example.ui.theme.TradeGreen
import com.example.ui.theme.TradeRed
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OrderBottomSheet(
    instrument: InstrumentEntity,
    initialSide: String = "BUY", // "BUY" or "SELL"
    availableMargin: Double,
    onDismiss: () -> Unit,
    onSubmitOrder: (side: String, productType: String, orderType: String, quantity: Int, price: Double, triggerPrice: Double) -> Unit
) {
    var side by remember { mutableStateOf(initialSide) }
    var productType by remember {
        mutableStateOf(
            if (instrument.segment == "CASH") "DELIVERY"
            else if (instrument.segment == "FNO_INDEX" || instrument.segment == "FNO_STOCK") "INTRADAY"
            else "NORMAL"
        )
    }
    var orderType by remember { mutableStateOf("MARKET") } // "MARKET", "LIMIT", "SL"

    val lotSize = instrument.lotSize.coerceAtLeast(1)
    var quantityText by remember { mutableStateOf("$lotSize") }
    var limitPriceText by remember { mutableStateOf(String.format(Locale.ENGLISH, "%.2f", instrument.ltp)) }
    var triggerPriceText by remember { mutableStateOf(String.format(Locale.ENGLISH, "%.2f", instrument.ltp * 0.98)) }

    val quantity = quantityText.toIntOrNull() ?: lotSize
    val limitPrice = limitPriceText.toDoubleOrNull() ?: instrument.ltp
    val triggerPrice = triggerPriceText.toDoubleOrNull() ?: (instrument.ltp * 0.98)

    val effectivePrice = if (orderType == "MARKET") instrument.ltp else limitPrice
    val requiredMargin = effectivePrice * quantity
    val hasSufficientMargin = (side == "SELL" && productType == "DELIVERY") || (availableMargin >= requiredMargin)

    val isBuy = (side == "BUY")
    val themeColor = if (isBuy) TradeGreen else TradeRed

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = MaterialTheme.colorScheme.surface,
        dragHandle = {
            Box(
                modifier = Modifier
                    .padding(vertical = 10.dp)
                    .width(40.dp)
                    .height(4.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f))
            )
        }
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 10.dp)
                .navigationBarsPadding()
        ) {
            // Header: Symbol, Name, LTP, Close Button
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = instrument.symbol,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "${instrument.name} • ${instrument.exchange}",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = formatInr(instrument.ltp),
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "${if (instrument.change >= 0) "+" else ""}${String.format(Locale.ENGLISH, "%.2f", instrument.changePercent)}%",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = if (instrument.change >= 0) TradeGreen else TradeRed
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close")
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Buy / Sell Tabs
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .padding(4.dp)
            ) {
                Button(
                    onClick = { side = "BUY" },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("tab_buy"),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (side == "BUY") TradeGreen else Color.Transparent,
                        contentColor = if (side == "BUY") Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                    ),
                    shape = RoundedCornerShape(8.dp),
                    elevation = null
                ) {
                    Text("BUY", fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = { side = "SELL" },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("tab_sell"),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (side == "SELL") TradeRed else Color.Transparent,
                        contentColor = if (side == "SELL") Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                    ),
                    shape = RoundedCornerShape(8.dp),
                    elevation = null
                ) {
                    Text("SELL", fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Product Type Selector
            Text("Product Type", fontSize = 12.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (instrument.segment == "CASH") {
                    listOf("DELIVERY" to "Delivery (CNC)", "INTRADAY" to "Intraday (MIS)").forEach { (key, label) ->
                        val isSel = productType == key
                        FilterChip(
                            selected = isSel,
                            onClick = { productType = key },
                            label = { Text(label, fontSize = 12.sp) },
                            modifier = Modifier.weight(1f).testTag("product_$key"),
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = themeColor.copy(alpha = 0.2f),
                                selectedLabelColor = themeColor
                            )
                        )
                    }
                } else {
                    listOf("INTRADAY" to "Intraday (MIS)", "NORMAL" to "Overnight (NRML)").forEach { (key, label) ->
                        val isSel = productType == key
                        FilterChip(
                            selected = isSel,
                            onClick = { productType = key },
                            label = { Text(label, fontSize = 12.sp) },
                            modifier = Modifier.weight(1f).testTag("product_$key"),
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = themeColor.copy(alpha = 0.2f),
                                selectedLabelColor = themeColor
                            )
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Order Type Selector
            Text("Order Type", fontSize = 12.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf("MARKET" to "Market", "LIMIT" to "Limit", "SL" to "Stop Loss (SL)").forEach { (key, label) ->
                    val isSel = orderType == key
                    FilterChip(
                        selected = isSel,
                        onClick = { orderType = key },
                        label = { Text(label, fontSize = 12.sp) },
                        modifier = Modifier.weight(1f).testTag("ordertype_$key"),
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = themeColor.copy(alpha = 0.2f),
                            selectedLabelColor = themeColor
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Quantity & Stepper
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedTextField(
                    value = quantityText,
                    onValueChange = { quantityText = it.filter { c -> c.isDigit() } },
                    label = { Text("Quantity (Lot size: $lotSize)") },
                    modifier = Modifier.weight(1f).testTag("input_quantity"),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    shape = RoundedCornerShape(10.dp),
                    trailingIcon = {
                        Row {
                            IconButton(
                                onClick = {
                                    val current = quantityText.toIntOrNull() ?: lotSize
                                    if (current > lotSize) quantityText = "${current - lotSize}"
                                },
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(Icons.Default.Remove, contentDescription = "Decrease")
                            }
                            IconButton(
                                onClick = {
                                    val current = quantityText.toIntOrNull() ?: 0
                                    quantityText = "${current + lotSize}"
                                },
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(Icons.Default.Add, contentDescription = "Increase")
                            }
                        }
                    }
                )

                if (orderType == "LIMIT" || orderType == "SL") {
                    OutlinedTextField(
                        value = limitPriceText,
                        onValueChange = { limitPriceText = it },
                        label = { Text("Limit Price (₹)") },
                        modifier = Modifier.weight(1f).testTag("input_limit_price"),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        shape = RoundedCornerShape(10.dp)
                    )
                }
            }

            if (orderType == "SL") {
                Spacer(modifier = Modifier.height(10.dp))
                OutlinedTextField(
                    value = triggerPriceText,
                    onValueChange = { triggerPriceText = it },
                    label = { Text("Trigger Price (₹)") },
                    modifier = Modifier.fillMaxWidth().testTag("input_trigger_price"),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    shape = RoundedCornerShape(10.dp)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Margin info summary
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .padding(10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Margin Required", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(
                        text = formatInr(requiredMargin),
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (hasSufficientMargin) MaterialTheme.colorScheme.onSurface else TradeRed
                    )
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text("Available Margin", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(
                        text = formatInr(availableMargin),
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Submit Button
            Button(
                onClick = {
                    if (quantity > 0) {
                        onSubmitOrder(side, productType, orderType, quantity, limitPrice, triggerPrice)
                        onDismiss()
                    }
                },
                enabled = hasSufficientMargin && quantity > 0,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("submit_order_button"),
                colors = ButtonDefaults.buttonColors(
                    containerColor = themeColor,
                    contentColor = Color.White
                ),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text(
                    text = "$side $quantity QTY • ${if (orderType == "MARKET") "AT MARKET" else "AT ₹$limitPrice"}",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
        }
    }
}
