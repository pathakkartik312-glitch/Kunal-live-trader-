package com.example.ui.screens.orders

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entities.HoldingEntity
import com.example.data.local.entities.OrderEntity
import com.example.data.local.entities.PositionEntity
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.TradingViewModel
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OrdersPositionsHoldingsScreen(
    viewModel: TradingViewModel,
    onNavigateInstrument: (symbol: String) -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()
    var selectedTab by remember { mutableStateOf(0) } // 0: Positions, 1: Holdings, 2: Orders
    val tabs = listOf("Positions (${uiState.positions.filter { it.isOpen }.size})", "Holdings (${uiState.holdings.size})", "Orders (${uiState.orders.size})")

    val openPositions = uiState.positions.filter { it.isOpen }
    val totalPositionsPnl = openPositions.sumOf { it.pnl }

    val totalHoldingInvested = uiState.holdings.sumOf { it.investedValue }
    val totalHoldingCurrent = uiState.holdings.sumOf { it.currentValue }
    val totalHoldingPnl = totalHoldingCurrent - totalHoldingInvested
    val holdingPnlPercent = if (totalHoldingInvested > 0) (totalHoldingPnl / totalHoldingInvested) * 100.0 else 0.0

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text("Portfolio & Orders", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            // Tab Row
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = MaterialTheme.colorScheme.primary
            ) {
                tabs.forEachIndexed { index, title ->
                    Tab(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        text = {
                            Text(
                                text = title,
                                fontSize = 13.sp,
                                fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Medium
                            )
                        }
                    )
                }
            }

            when (selectedTab) {
                0 -> {
                    // POSITIONS TAB
                    if (openPositions.isEmpty()) {
                        EmptyStateView(
                            icon = Icons.Default.TrendingUp,
                            title = "No Open Positions",
                            subtitle = "You have no active intraday or derivatives positions."
                        )
                    } else {
                        LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            contentPadding = PaddingValues(14.dp)
                        ) {
                            // Summary Header for Positions
                            item {
                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(bottom = 12.dp),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(14.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column {
                                            Text("Total Real-time MTM P&L", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                            Text(
                                                text = formatInr(totalPositionsPnl, showSign = true),
                                                fontSize = 20.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = if (totalPositionsPnl >= 0) TradeGreen else TradeRed
                                            )
                                        }
                                        StatusBadge(status = "${openPositions.size} ACTIVE")
                                    }
                                }
                            }

                            items(openPositions, key = { it.id }) { pos ->
                                PositionRow(
                                    position = pos,
                                    onExit = { viewModel.exitPosition(pos) },
                                    onClick = { onNavigateInstrument(pos.symbol) }
                                )
                            }
                        }
                    }
                }
                1 -> {
                    // HOLDINGS TAB
                    if (uiState.holdings.isEmpty()) {
                        EmptyStateView(
                            icon = Icons.Default.AccountBalanceWallet,
                            title = "No Holdings in Demat",
                            subtitle = "Stocks bought under CNC (Delivery) will appear here."
                        )
                    } else {
                        LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            contentPadding = PaddingValues(14.dp)
                        ) {
                            item {
                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(bottom = 12.dp),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Column(modifier = Modifier.padding(14.dp)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Column {
                                                Text("Total Investment", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                                Text(formatInr(totalHoldingInvested), fontSize = 16.sp, fontWeight = FontWeight.Bold)
                                            }
                                            Column(horizontalAlignment = Alignment.End) {
                                                Text("Current Value", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                                Text(formatInr(totalHoldingCurrent), fontSize = 16.sp, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                        Spacer(modifier = Modifier.height(10.dp))
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text("Overall P&L", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                            Text(
                                                text = "${formatInr(totalHoldingPnl, showSign = true)} (${if (holdingPnlPercent >= 0) "+" else ""}${String.format(Locale.ENGLISH, "%.2f", holdingPnlPercent)}%)",
                                                fontSize = 15.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = if (totalHoldingPnl >= 0) TradeGreen else TradeRed
                                            )
                                        }
                                    }
                                }
                            }

                            items(uiState.holdings, key = { it.id }) { holding ->
                                HoldingRow(
                                    holding = holding,
                                    onClick = { onNavigateInstrument(holding.symbol) }
                                )
                            }
                        }
                    }
                }
                2 -> {
                    // ORDERS TAB
                    if (uiState.orders.isEmpty()) {
                        EmptyStateView(
                            icon = Icons.Default.ReceiptLong,
                            title = "No Orders Placed Yet",
                            subtitle = "Your executed and pending market orders will show here."
                        )
                    } else {
                        LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            contentPadding = PaddingValues(14.dp)
                        ) {
                            items(uiState.orders, key = { it.id }) { order ->
                                OrderRow(
                                    order = order,
                                    onCancel = { viewModel.cancelOrder(order.id) },
                                    onClick = { onNavigateInstrument(order.symbol) }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PositionRow(
    position: PositionEntity,
    onExit: () -> Unit,
    onClick: () -> Unit
) {
    val isProfit = position.pnl >= 0
    Card(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .testTag("position_item_${position.symbol}"),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(if (position.side == "BUY") TradeGreenLight else TradeRedLight)
                            .padding(horizontal = 5.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "${position.side} ${position.quantity} Qty",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (position.side == "BUY") TradeGreen else TradeRed
                        )
                    }
                    Text(
                        text = position.symbol,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                Text(
                    text = "${formatInr(position.pnl, showSign = true)} (${if (position.pnlPercent >= 0) "+" else ""}${String.format(Locale.ENGLISH, "%.2f", position.pnlPercent)}%)",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isProfit) TradeGreen else TradeRed
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    Column {
                        Text("Avg. Price", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(formatInr(position.averageBuyPrice), fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    }
                    Column {
                        Text("LTP", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(formatInr(position.ltp), fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    }
                    Column {
                        Text("Product", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(position.productType, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    }
                }

                OutlinedButton(
                    onClick = onExit,
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                    shape = RoundedCornerShape(6.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = TradeRed),
                    modifier = Modifier.height(30.dp).testTag("exit_pos_btn")
                ) {
                    Text("Exit", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun HoldingRow(
    holding: HoldingEntity,
    onClick: () -> Unit
) {
    val isProfit = holding.pnl >= 0
    Card(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .testTag("holding_item_${holding.symbol}"),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = holding.symbol,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "${holding.quantity} Qty • Avg: ${formatInr(holding.averageBuyPrice)}",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = formatInr(holding.currentValue),
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "${formatInr(holding.pnl, showSign = true)} (${if (holding.pnlPercent >= 0) "+" else ""}${String.format(Locale.ENGLISH, "%.2f", holding.pnlPercent)}%)",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isProfit) TradeGreen else TradeRed
                    )
                }
            }
        }
    }
}

@Composable
fun OrderRow(
    order: OrderEntity,
    onCancel: () -> Unit,
    onClick: () -> Unit
) {
    val isBuy = order.side == "BUY"
    val timeFormat = SimpleDateFormat("dd MMM, hh:mm a", Locale.ENGLISH)
    val timeStr = timeFormat.format(Date(order.timestamp))

    Card(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .testTag("order_item_${order.id}"),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(if (isBuy) TradeGreenLight else TradeRedLight)
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = order.side,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isBuy) TradeGreen else TradeRed
                        )
                    }
                    Text(
                        text = order.symbol,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                StatusBadge(status = order.status)
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "${order.quantity} Qty • ${order.orderType} • ${order.productType}",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = timeStr,
                        fontSize = 10.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = if (order.status == "EXECUTED") "₹${String.format(Locale.ENGLISH, "%.2f", order.executedPrice)}" else "₹${String.format(Locale.ENGLISH, "%.2f", order.price)}",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    if (order.status == "PENDING") {
                        TextButton(
                            onClick = onCancel,
                            contentPadding = PaddingValues(0.dp),
                            modifier = Modifier.height(24.dp).testTag("cancel_order_btn")
                        ) {
                            Text("Cancel Order", fontSize = 11.sp, color = TradeRed, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}
