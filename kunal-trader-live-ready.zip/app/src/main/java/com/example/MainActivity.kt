package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.lifecycleScope
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.data.local.AppDatabase
import com.example.data.repository.MarketSimulationEngine
import com.example.data.repository.TradingRepository
import com.example.ui.navigation.NavRoutes
import com.example.ui.screens.MainAppScreen
import com.example.ui.screens.admin.*
import com.example.ui.screens.auth.ForgotPasswordScreen
import com.example.ui.screens.auth.LoginScreen
import com.example.ui.screens.auth.OtpScreen
import com.example.ui.screens.auth.SignupScreen
import com.example.ui.screens.auth.SplashScreen
import com.example.ui.screens.details.IndexDetailScreen
import com.example.ui.screens.details.InstrumentDetailScreen
import com.example.ui.screens.markets.OptionChainScreen
import com.example.ui.screens.profile.KycUploadScreen
import com.example.ui.screens.profile.NotificationsScreen
import com.example.ui.screens.profile.SupportScreen
import com.example.ui.screens.wallet.BankManagementScreen
import com.example.ui.screens.wallet.DepositScreen
import com.example.ui.screens.wallet.WithdrawScreen
import com.example.ui.theme.KunalTraderTheme
import com.example.ui.viewmodel.AdminViewModel
import com.example.ui.viewmodel.TradingViewModel
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private lateinit var simulationEngine: MarketSimulationEngine

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val database = AppDatabase.getDatabase(applicationContext, lifecycleScope)
        val repository = TradingRepository(database)
        simulationEngine = MarketSimulationEngine(database, lifecycleScope)

        // Launch simulated live market feed ticks and order execution loop
        simulationEngine.startSimulation()

        val tradingViewModel = TradingViewModel(repository)
        val adminViewModel = AdminViewModel(repository)

        setContent {
            KunalTraderTheme {
                val navController = rememberNavController()
                val snackbarHostState = remember { SnackbarHostState() }
                val tradingUiState by tradingViewModel.uiState.collectAsState()
                val adminUiState by adminViewModel.uiState.collectAsState()

                // Display snackbars for notifications and messages
                LaunchedEffect(tradingUiState.message, tradingUiState.error) {
                    tradingUiState.message?.let {
                        snackbarHostState.showSnackbar(it)
                        tradingViewModel.clearMessage()
                    }
                    tradingUiState.error?.let {
                        snackbarHostState.showSnackbar(it)
                        tradingViewModel.clearMessage()
                    }
                }

                LaunchedEffect(adminUiState.message, adminUiState.error) {
                    adminUiState.message?.let {
                        snackbarHostState.showSnackbar(it)
                        adminViewModel.clearMessage()
                    }
                    adminUiState.error?.let {
                        snackbarHostState.showSnackbar(it)
                        adminViewModel.clearMessage()
                    }
                }

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    snackbarHost = { SnackbarHost(snackbarHostState) }
                ) { innerPadding ->
                    NavHost(
                        navController = navController,
                        startDestination = NavRoutes.SPLASH,
                        modifier = Modifier.padding(innerPadding)
                    ) {
                        // Splash Screen
                        composable(NavRoutes.SPLASH) {
                            SplashScreen(
                                onSplashFinished = {
                                    navController.navigate(NavRoutes.LOGIN) {
                                        popUpTo(NavRoutes.SPLASH) { inclusive = true }
                                    }
                                }
                            )
                        }

                        // User Auth Screens
                        composable(NavRoutes.LOGIN) {
                            LoginScreen(
                                viewModel = tradingViewModel,
                                onLoginSuccess = {
                                    navController.navigate(NavRoutes.MAIN_APP) {
                                        popUpTo(NavRoutes.LOGIN) { inclusive = true }
                                    }
                                },
                                onNavigateSignup = { navController.navigate(NavRoutes.SIGNUP) },
                                onNavigateForgotPassword = { navController.navigate(NavRoutes.FORGOT_PASSWORD) },
                                onNavigateAdmin = { navController.navigate(NavRoutes.ADMIN_LOGIN) }
                            )
                        }

                        composable(NavRoutes.SIGNUP) {
                            SignupScreen(
                                viewModel = tradingViewModel,
                                onSignupSuccess = {
                                    navController.navigate(NavRoutes.MAIN_APP) {
                                        popUpTo(NavRoutes.LOGIN) { inclusive = true }
                                    }
                                },
                                onNavigateLogin = { navController.popBackStack() }
                            )
                        }

                        composable(NavRoutes.FORGOT_PASSWORD) {
                            ForgotPasswordScreen(
                                viewModel = tradingViewModel,
                                onPasswordResetSuccess = {
                                    navController.navigate(NavRoutes.LOGIN) {
                                        popUpTo(NavRoutes.FORGOT_PASSWORD) { inclusive = true }
                                    }
                                },
                                onNavigateBack = { navController.popBackStack() }
                            )
                        }

                        composable(
                            route = "otp_verify/{phone}?name={name}&email={email}&pin={pin}",
                            arguments = listOf(
                                navArgument("phone") { type = NavType.StringType },
                                navArgument("name") { type = NavType.StringType; defaultValue = "Kunal" },
                                navArgument("email") { type = NavType.StringType; defaultValue = "demo@kunaltrader.com" },
                                navArgument("pin") { type = NavType.StringType; defaultValue = "1234" }
                            )
                        ) { backStackEntry ->
                            val phone = backStackEntry.arguments?.getString("phone") ?: ""
                            val name = backStackEntry.arguments?.getString("name") ?: "Demo User"
                            val email = backStackEntry.arguments?.getString("email") ?: "demo@kunaltrader.com"
                            val pin = backStackEntry.arguments?.getString("pin") ?: "1234"

                            OtpScreen(
                                phone = phone,
                                fullName = name,
                                email = email,
                                pin = pin,
                                viewModel = tradingViewModel,
                                onOtpSuccess = {
                                    navController.navigate(NavRoutes.MAIN_APP) {
                                        popUpTo(NavRoutes.LOGIN) { inclusive = true }
                                    }
                                }
                            )
                        }

                        // Main User Trading App
                        composable(NavRoutes.MAIN_APP) {
                            MainAppScreen(
                                viewModel = tradingViewModel,
                                onNavigateInstrument = { symbol ->
                                    navController.navigate(NavRoutes.instrumentDetail(symbol))
                                },
                                onNavigateOptionChain = { symbol ->
                                    navController.navigate(NavRoutes.optionChain(symbol))
                                },
                                onNavigateDeposit = { navController.navigate(NavRoutes.DEPOSIT) },
                                onNavigateWithdraw = { navController.navigate(NavRoutes.WITHDRAW) },
                                onNavigateBanks = { navController.navigate(NavRoutes.BANK_ACCOUNTS) },
                                onNavigateKyc = { navController.navigate(NavRoutes.KYC_UPLOAD) },
                                onNavigateNotifications = { navController.navigate(NavRoutes.NOTIFICATIONS) },
                                onNavigateSupport = { navController.navigate(NavRoutes.SUPPORT) },
                                onNavigateAdmin = { navController.navigate(NavRoutes.ADMIN_LOGIN) },
                                onLogout = {
                                    navController.navigate(NavRoutes.LOGIN) {
                                        popUpTo(NavRoutes.MAIN_APP) { inclusive = true }
                                    }
                                }
                            )
                        }

                        // Instrument Detail Screen
                        composable(
                            route = NavRoutes.INSTRUMENT_DETAIL,
                            arguments = listOf(navArgument("symbol") { type = NavType.StringType })
                        ) { backStackEntry ->
                            val rawSymbol = backStackEntry.arguments?.getString("symbol") ?: "NIFTY 50"
                            val symbol = try { java.net.URLDecoder.decode(rawSymbol, "UTF-8") } catch (e: Exception) { rawSymbol }
                            val isIndex = symbol in listOf("SENSEX", "NIFTY 50", "NIFTY", "BANKNIFTY", "FINNIFTY", "MIDCPNIFTY") ||
                                    tradingUiState.instruments.find { it.symbol == symbol }?.segment == "INDEX"

                            if (isIndex) {
                                IndexDetailScreen(
                                    symbol = symbol,
                                    viewModel = tradingViewModel,
                                    onNavigateBack = { navController.popBackStack() },
                                    onNavigateOptionChain = { sym ->
                                        navController.navigate(NavRoutes.optionChain(sym))
                                    },
                                    onNavigateStock = { stockSym ->
                                        navController.navigate(NavRoutes.instrumentDetail(stockSym))
                                    }
                                )
                            } else {
                                InstrumentDetailScreen(
                                    symbol = symbol,
                                    viewModel = tradingViewModel,
                                    onNavigateBack = { navController.popBackStack() },
                                    onNavigateOptionChain = { sym ->
                                        navController.navigate(NavRoutes.optionChain(sym))
                                    }
                                )
                            }
                        }

                        // Option Chain Screen
                        composable(
                            route = NavRoutes.OPTION_CHAIN,
                            arguments = listOf(navArgument("symbol") { type = NavType.StringType })
                        ) { backStackEntry ->
                            val rawSymbol = backStackEntry.arguments?.getString("symbol") ?: "NIFTY 50"
                            val symbol = try { java.net.URLDecoder.decode(rawSymbol, "UTF-8") } catch (e: Exception) { rawSymbol }
                            OptionChainScreen(
                                symbol = symbol,
                                viewModel = tradingViewModel,
                                onNavigateBack = { navController.popBackStack() }
                            )
                        }

                        // Wallet & Bank Screens
                        composable(NavRoutes.DEPOSIT) {
                            DepositScreen(
                                viewModel = tradingViewModel,
                                onNavigateBack = { navController.popBackStack() }
                            )
                        }

                        composable(NavRoutes.WITHDRAW) {
                            WithdrawScreen(
                                viewModel = tradingViewModel,
                                onNavigateBack = { navController.popBackStack() }
                            )
                        }

                        composable(NavRoutes.BANK_ACCOUNTS) {
                            BankManagementScreen(
                                viewModel = tradingViewModel,
                                onNavigateBack = { navController.popBackStack() }
                            )
                        }

                        // Profile Sub-screens
                        composable(NavRoutes.KYC_UPLOAD) {
                            KycUploadScreen(
                                viewModel = tradingViewModel,
                                onNavigateBack = { navController.popBackStack() }
                            )
                        }

                        composable(NavRoutes.NOTIFICATIONS) {
                            NotificationsScreen(
                                viewModel = tradingViewModel,
                                onNavigateBack = { navController.popBackStack() }
                            )
                        }

                        composable(NavRoutes.SUPPORT) {
                            SupportScreen(
                                onNavigateBack = { navController.popBackStack() }
                            )
                        }

                        // Admin Portal Screens
                        composable(NavRoutes.ADMIN_LOGIN) {
                            AdminLoginScreen(
                                viewModel = adminViewModel,
                                onLoginSuccess = {
                                    navController.navigate(NavRoutes.ADMIN_DASHBOARD) {
                                        popUpTo(NavRoutes.ADMIN_LOGIN) { inclusive = true }
                                    }
                                },
                                onNavigateBack = { navController.popBackStack() }
                            )
                        }

                        composable(NavRoutes.ADMIN_DASHBOARD) {
                            AdminDashboardScreen(
                                viewModel = adminViewModel,
                                onNavigateUsers = { navController.navigate(NavRoutes.ADMIN_USERS) },
                                onNavigateKyc = { navController.navigate(NavRoutes.ADMIN_KYC) },
                                onNavigateDeposits = { navController.navigate(NavRoutes.ADMIN_DEPOSITS) },
                                onNavigateWithdrawals = { navController.navigate(NavRoutes.ADMIN_WITHDRAWALS) },
                                onNavigateBanks = { navController.navigate(NavRoutes.ADMIN_BANKS) },
                                onNavigateInstruments = { navController.navigate(NavRoutes.ADMIN_INSTRUMENTS) },
                                onNavigateTrades = { navController.navigate(NavRoutes.ADMIN_TRADES) },
                                onNavigateAudit = { navController.navigate(NavRoutes.ADMIN_AUDIT_LOGS) },
                                onNavigateNotifications = { navController.navigate(NavRoutes.ADMIN_NOTIFICATIONS) },
                                onLogout = {
                                    adminViewModel.logout()
                                    navController.navigate(NavRoutes.MAIN_APP) {
                                        popUpTo(NavRoutes.ADMIN_DASHBOARD) { inclusive = true }
                                    }
                                }
                            )
                        }

                        composable(NavRoutes.ADMIN_USERS) {
                            AdminUsersScreen(
                                viewModel = adminViewModel,
                                onSelectUser = { user ->
                                    adminViewModel.selectUser(user)
                                    navController.navigate(NavRoutes.ADMIN_USER_DETAIL)
                                },
                                onNavigateBack = { navController.popBackStack() }
                            )
                        }

                        composable(NavRoutes.ADMIN_USER_DETAIL) {
                            AdminUserDetailScreen(
                                viewModel = adminViewModel,
                                onNavigateBack = { navController.popBackStack() }
                            )
                        }

                        composable(NavRoutes.ADMIN_KYC) {
                            AdminKycScreen(
                                viewModel = adminViewModel,
                                onNavigateBack = { navController.popBackStack() }
                            )
                        }

                        composable(NavRoutes.ADMIN_DEPOSITS) {
                            AdminDepositsScreen(
                                viewModel = adminViewModel,
                                onNavigateBack = { navController.popBackStack() }
                            )
                        }

                        composable(NavRoutes.ADMIN_WITHDRAWALS) {
                            AdminWithdrawalsScreen(
                                viewModel = adminViewModel,
                                onNavigateBack = { navController.popBackStack() }
                            )
                        }

                        composable(NavRoutes.ADMIN_BANKS) {
                            AdminBanksScreen(
                                viewModel = adminViewModel,
                                onNavigateBack = { navController.popBackStack() }
                            )
                        }

                        composable(NavRoutes.ADMIN_INSTRUMENTS) {
                            AdminInstrumentsScreen(
                                viewModel = adminViewModel,
                                onNavigateBack = { navController.popBackStack() }
                            )
                        }

                        composable(NavRoutes.ADMIN_TRADES) {
                            AdminTradesScreen(
                                viewModel = adminViewModel,
                                onNavigateBack = { navController.popBackStack() }
                            )
                        }

                        composable(NavRoutes.ADMIN_AUDIT_LOGS) {
                            AdminAuditLogsScreen(
                                viewModel = adminViewModel,
                                onNavigateBack = { navController.popBackStack() }
                            )
                        }

                        composable(NavRoutes.ADMIN_NOTIFICATIONS) {
                            AdminNotificationsScreen(
                                viewModel = adminViewModel,
                                onNavigateBack = { navController.popBackStack() }
                            )
                        }
                    }
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        simulationEngine.stopSimulation()
    }
}
