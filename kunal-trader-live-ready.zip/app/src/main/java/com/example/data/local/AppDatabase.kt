package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.local.dao.*
import com.example.data.local.entities.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        UserEntity::class,
        WalletEntity::class,
        InstrumentEntity::class,
        OptionStrikeEntity::class,
        OrderEntity::class,
        PositionEntity::class,
        HoldingEntity::class,
        TransactionEntity::class,
        BankAccountEntity::class,
        NotificationEntity::class,
        AuditLogEntity::class,
        WatchlistItemEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun userDao(): UserDao
    abstract fun walletDao(): WalletDao
    abstract fun instrumentDao(): InstrumentDao
    abstract fun optionStrikeDao(): OptionStrikeDao
    abstract fun orderDao(): OrderDao
    abstract fun positionDao(): PositionDao
    abstract fun holdingDao(): HoldingDao
    abstract fun transactionDao(): TransactionDao
    abstract fun bankAccountDao(): BankAccountDao
    abstract fun notificationDao(): NotificationDao
    abstract fun auditLogDao(): AuditLogDao
    abstract fun watchlistDao(): WatchlistDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "kunal_trader_db"
                )
                    .addCallback(DatabaseCallback(scope))
                    .build()
                INSTANCE = instance
                instance
            }
        }

        private class DatabaseCallback(
            private val scope: CoroutineScope
        ) : RoomDatabase.Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                INSTANCE?.let { database ->
                    scope.launch(Dispatchers.IO) {
                        populateInitialData(database)
                    }
                }
            }
        }

        suspend fun populateInitialData(database: AppDatabase) {
            val userCount = database.userDao().findByEmail("kunal@trader.demo")
            if (userCount == null) {
                for (user in DataSeeder.getInitialUsers()) {
                    database.userDao().insertUser(user)
                }
                for (wallet in DataSeeder.getInitialWallets()) {
                    database.walletDao().insertOrUpdateWallet(wallet)
                }
                database.instrumentDao().insertInstruments(DataSeeder.getInitialInstruments())
                database.optionStrikeDao().insertStrikes(DataSeeder.getInitialOptionStrikes())
                for (bank in DataSeeder.getInitialAdminBanks()) {
                    database.bankAccountDao().insertBankAccount(bank)
                }
                for (h in DataSeeder.getInitialHoldings()) {
                    database.holdingDao().insertHolding(h)
                }
                for (p in DataSeeder.getInitialPositions()) {
                    database.positionDao().insertPosition(p)
                }
                for (o in DataSeeder.getInitialOrders()) {
                    database.orderDao().insertOrder(o)
                }
                for (t in DataSeeder.getInitialTransactions()) {
                    database.transactionDao().insertTransaction(t)
                }
                for (n in DataSeeder.getInitialNotifications()) {
                    database.notificationDao().insertNotification(n)
                }
                for (a in DataSeeder.getInitialAuditLogs()) {
                    database.auditLogDao().insertAuditLog(a)
                }
                for (w in DataSeeder.getInitialWatchlist()) {
                    database.watchlistDao().addToWatchlist(w)
                }
            }
        }
    }
}
