package com.example.data.local.dao

import androidx.room.*
import com.example.data.local.entities.*
import kotlinx.coroutines.flow.Flow

@Dao
interface UserDao {
    @Query("SELECT * FROM users WHERE id = :id")
    fun getUserById(id: Long): Flow<UserEntity?>

    @Query("SELECT * FROM users WHERE id = :id")
    suspend fun getUserByIdOnce(id: Long): UserEntity?

    @Query("SELECT * FROM users WHERE email = :email OR phone = :phone LIMIT 1")
    suspend fun findByEmailOrPhone(email: String, phone: String): UserEntity?

    @Query("SELECT * FROM users WHERE email = :email LIMIT 1")
    suspend fun findByEmail(email: String): UserEntity?

    @Query("SELECT * FROM users WHERE LOWER(email) = LOWER(:query) OR phone = :query OR REPLACE(phone, ' ', '') = REPLACE(:query, ' ', '') OR REPLACE(phone, '+91', '') = REPLACE(:query, '+91', '') OR LOWER(username) = LOWER(:query) LIMIT 1")
    suspend fun findByCredential(query: String): UserEntity?

    @Query("UPDATE users SET pin = :newPin WHERE id = :userId")
    suspend fun updatePassword(userId: Long, newPin: String)

    @Query("SELECT * FROM users ORDER BY id DESC")
    fun getAllUsers(): Flow<List<UserEntity>>

    @Query("SELECT * FROM users WHERE kycStatus = 'PENDING' ORDER BY id DESC")
    fun getPendingKycUsers(): Flow<List<UserEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUser(user: UserEntity): Long

    @Update
    suspend fun updateUser(user: UserEntity)

    @Delete
    suspend fun deleteUser(user: UserEntity)

    @Query("DELETE FROM users WHERE id = :id")
    suspend fun deleteUserById(id: Long)
}

@Dao
interface WalletDao {
    @Query("SELECT * FROM wallets WHERE userId = :userId")
    fun getWalletByUserId(userId: Long): Flow<WalletEntity?>

    @Query("SELECT * FROM wallets WHERE userId = :userId")
    suspend fun getWalletByUserIdOnce(userId: Long): WalletEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateWallet(wallet: WalletEntity)

    @Query("UPDATE wallets SET availableMargin = :avail, usedMargin = :used, totalBalance = :total, realizedPnl = :rPnl WHERE userId = :userId")
    suspend fun updateBalances(userId: Long, avail: Double, used: Double, total: Double, rPnl: Double)
}

@Dao
interface InstrumentDao {
    @Query("SELECT * FROM instruments WHERE isActive = 1 ORDER BY segment ASC, symbol ASC")
    fun getAllActiveInstruments(): Flow<List<InstrumentEntity>>

    @Query("SELECT * FROM instruments ORDER BY segment ASC, symbol ASC")
    fun getAllInstruments(): Flow<List<InstrumentEntity>>

    @Query("SELECT * FROM instruments WHERE segment = :segment AND isActive = 1")
    fun getInstrumentsBySegment(segment: String): Flow<List<InstrumentEntity>>

    @Query("SELECT * FROM instruments WHERE indexCategory = :indexCategory AND isActive = 1")
    fun getInstrumentsByIndex(indexCategory: String): Flow<List<InstrumentEntity>>

    @Query("SELECT * FROM instruments WHERE symbol = :symbol LIMIT 1")
    fun getInstrumentBySymbol(symbol: String): Flow<InstrumentEntity?>

    @Query("SELECT * FROM instruments WHERE symbol = :symbol LIMIT 1")
    suspend fun getInstrumentBySymbolOnce(symbol: String): InstrumentEntity?

    @Query("SELECT * FROM instruments WHERE symbol LIKE '%' || :query || '%' OR name LIKE '%' || :query || '%'")
    fun searchInstruments(query: String): Flow<List<InstrumentEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertInstruments(instruments: List<InstrumentEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertInstrument(instrument: InstrumentEntity)

    @Update
    suspend fun updateInstrument(instrument: InstrumentEntity)

    @Query("UPDATE instruments SET ltp = :ltp, change = :change, changePercent = :changePercent, highPrice = CASE WHEN :ltp > highPrice THEN :ltp ELSE highPrice END, lowPrice = CASE WHEN :ltp < lowPrice THEN :ltp ELSE lowPrice END WHERE symbol = :symbol")
    suspend fun updateLtp(symbol: String, ltp: Double, change: Double, changePercent: Double)

    @Query("DELETE FROM instruments WHERE symbol = :symbol")
    suspend fun deleteInstrumentBySymbol(symbol: String)
}

@Dao
interface OptionStrikeDao {
    @Query("SELECT * FROM option_strikes WHERE underlyingSymbol = :symbol ORDER BY strikePrice ASC")
    fun getOptionChain(symbol: String): Flow<List<OptionStrikeEntity>>

    @Query("SELECT * FROM option_strikes WHERE underlyingSymbol = :symbol AND expiryDate = :expiry ORDER BY strikePrice ASC")
    fun getOptionChainByExpiry(symbol: String, expiry: String): Flow<List<OptionStrikeEntity>>

    @Query("SELECT DISTINCT expiryDate FROM option_strikes WHERE underlyingSymbol = :symbol")
    fun getAvailableExpiries(symbol: String): Flow<List<String>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStrikes(strikes: List<OptionStrikeEntity>)

    @Update
    suspend fun updateStrike(strike: OptionStrikeEntity)

    @Query("DELETE FROM option_strikes WHERE id = :id")
    suspend fun deleteStrikeById(id: Long)
}

@Dao
interface OrderDao {
    @Query("SELECT * FROM orders WHERE userId = :userId ORDER BY timestamp DESC")
    fun getOrdersByUserId(userId: Long): Flow<List<OrderEntity>>

    @Query("SELECT * FROM orders ORDER BY timestamp DESC")
    fun getAllOrders(): Flow<List<OrderEntity>>

    @Query("SELECT * FROM orders WHERE id = :id")
    suspend fun getOrderById(id: Long): OrderEntity?

    @Query("SELECT * FROM orders WHERE status = 'PENDING'")
    fun getPendingOrders(): Flow<List<OrderEntity>>

    @Query("SELECT * FROM orders WHERE status = 'PENDING'")
    suspend fun getPendingOrdersOnce(): List<OrderEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrder(order: OrderEntity): Long

    @Update
    suspend fun updateOrder(order: OrderEntity)

    @Query("DELETE FROM orders WHERE id = :id")
    suspend fun deleteOrderById(id: Long)
}

@Dao
interface PositionDao {
    @Query("SELECT * FROM positions WHERE userId = :userId AND isOpen = 1 ORDER BY openedAt DESC")
    fun getOpenPositionsByUserId(userId: Long): Flow<List<PositionEntity>>

    @Query("SELECT * FROM positions WHERE userId = :userId ORDER BY openedAt DESC")
    fun getAllPositionsByUserId(userId: Long): Flow<List<PositionEntity>>

    @Query("SELECT * FROM positions WHERE isOpen = 1")
    fun getAllOpenPositions(): Flow<List<PositionEntity>>

    @Query("SELECT * FROM positions WHERE userId = :userId AND symbol = :symbol AND isOpen = 1 LIMIT 1")
    suspend fun findOpenPosition(userId: Long, symbol: String): PositionEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPosition(position: PositionEntity): Long

    @Update
    suspend fun updatePosition(position: PositionEntity)

    @Delete
    suspend fun deletePosition(position: PositionEntity)

    @Query("DELETE FROM positions WHERE id = :id")
    suspend fun deletePositionById(id: Long)
}

@Dao
interface HoldingDao {
    @Query("SELECT * FROM holdings WHERE userId = :userId AND quantity > 0 ORDER BY id DESC")
    fun getHoldingsByUserId(userId: Long): Flow<List<HoldingEntity>>

    @Query("SELECT * FROM holdings WHERE userId = :userId")
    fun getAllHoldingsByUserId(userId: Long): Flow<List<HoldingEntity>>

    @Query("SELECT * FROM holdings WHERE userId = :userId AND symbol = :symbol LIMIT 1")
    suspend fun findHolding(userId: Long, symbol: String): HoldingEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHolding(holding: HoldingEntity): Long

    @Update
    suspend fun updateHolding(holding: HoldingEntity)

    @Delete
    suspend fun deleteHolding(holding: HoldingEntity)
}

@Dao
interface TransactionDao {
    @Query("SELECT * FROM transactions WHERE userId = :userId ORDER BY timestamp DESC")
    fun getTransactionsByUserId(userId: Long): Flow<List<TransactionEntity>>

    @Query("SELECT * FROM transactions ORDER BY timestamp DESC")
    fun getAllTransactions(): Flow<List<TransactionEntity>>

    @Query("SELECT * FROM transactions WHERE type = 'DEPOSIT' AND status = 'PENDING' ORDER BY timestamp DESC")
    fun getPendingDeposits(): Flow<List<TransactionEntity>>

    @Query("SELECT * FROM transactions WHERE type = 'WITHDRAWAL' AND status = 'PENDING' ORDER BY timestamp DESC")
    fun getPendingWithdrawals(): Flow<List<TransactionEntity>>

    @Query("SELECT * FROM transactions WHERE id = :id")
    suspend fun getTransactionById(id: Long): TransactionEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransaction(transaction: TransactionEntity): Long

    @Update
    suspend fun updateTransaction(transaction: TransactionEntity)

    @Query("DELETE FROM transactions WHERE id = :id")
    suspend fun deleteTransactionById(id: Long)
}

@Dao
interface BankAccountDao {
    @Query("SELECT * FROM bank_accounts WHERE userId = :userId")
    fun getBankAccountsByUserId(userId: Long): Flow<List<BankAccountEntity>>

    @Query("SELECT * FROM bank_accounts WHERE isAdminDepositBank = 1")
    fun getAdminDepositBanks(): Flow<List<BankAccountEntity>>

    @Query("SELECT * FROM bank_accounts")
    fun getAllBankAccounts(): Flow<List<BankAccountEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBankAccount(bankAccount: BankAccountEntity): Long

    @Update
    suspend fun updateBankAccount(bankAccount: BankAccountEntity)

    @Delete
    suspend fun deleteBankAccount(bankAccount: BankAccountEntity)

    @Query("DELETE FROM bank_accounts WHERE id = :id")
    suspend fun deleteBankAccountById(id: Long)
}

@Dao
interface NotificationDao {
    @Query("SELECT * FROM notifications WHERE userId = :userId OR userId = 0 ORDER BY timestamp DESC")
    fun getNotificationsForUser(userId: Long): Flow<List<NotificationEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotification(notification: NotificationEntity): Long

    @Query("UPDATE notifications SET isRead = 1 WHERE userId = :userId OR userId = 0")
    suspend fun markAllAsRead(userId: Long)

    @Query("DELETE FROM notifications WHERE id = :id")
    suspend fun deleteNotificationById(id: Long)
}

@Dao
interface AuditLogDao {
    @Query("SELECT * FROM audit_logs ORDER BY timestamp DESC")
    fun getAllAuditLogs(): Flow<List<AuditLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAuditLog(log: AuditLogEntity): Long
}

@Dao
interface WatchlistDao {
    @Query("SELECT * FROM watchlist_items WHERE userId = :userId")
    fun getWatchlistForUser(userId: Long): Flow<List<WatchlistItemEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun addToWatchlist(item: WatchlistItemEntity): Long

    @Query("DELETE FROM watchlist_items WHERE userId = :userId AND symbol = :symbol")
    suspend fun removeFromWatchlist(userId: Long, symbol: String)

    @Query("SELECT EXISTS(SELECT 1 FROM watchlist_items WHERE userId = :userId AND symbol = :symbol)")
    fun isInWatchlist(userId: Long, symbol: String): Flow<Boolean>
}
