package com.example.data.market

/**
 * Production boundary for market data.
 *
 * Demo builds can keep using the existing MarketSimulationEngine. A licensed
 * provider is plugged in here for production without changing Compose screens.
 */
interface MarketDataProvider {
    suspend fun quotes(symbols: List<String>): Result<List<MarketQuote>>
}
