package com.example.data.market

/**
 * Normalized market quote used by the app. The provider layer keeps the UI
 * independent from any specific market-data vendor.
 */
data class MarketQuote(
    val symbol: String,
    val exchange: String,
    val ltp: Double,
    val change: Double,
    val changePercent: Double,
    val volume: Long = 0L,
    val timestamp: Long = System.currentTimeMillis()
)
