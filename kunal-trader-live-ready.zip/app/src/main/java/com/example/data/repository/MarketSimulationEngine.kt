package com.example.data.repository

import com.example.data.local.AppDatabase
import com.example.data.local.entities.OrderEntity
import com.example.data.local.entities.PositionEntity
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.firstOrNull
import kotlin.random.Random

class MarketSimulationEngine(
    private val database: AppDatabase,
    private val scope: CoroutineScope
) {
    private var isRunning = false
    private var simulationJob: Job? = null

    fun startSimulation() {
        if (isRunning) return
        isRunning = true
        simulationJob = scope.launch(Dispatchers.IO) {
            while (isActive && isRunning) {
                try {
                    tickMarket()
                } catch (e: Exception) {
                    // Ignore simulation exceptions
                }
                delay(1800) // 1.8 second live tick interval
            }
        }
    }

    fun stopSimulation() {
        isRunning = false
        simulationJob?.cancel()
    }

    private suspend fun tickMarket() {
        val instruments = database.instrumentDao().getAllActiveInstruments().firstOrNull() ?: return
        for (inst in instruments) {
            // Slight random fluctuation based on price scale
            val pctDelta = (Random.nextDouble(-0.35, 0.38)) / 100.0
            val delta = inst.ltp * pctDelta
            val newLtp = Math.round((inst.ltp + delta) * 100.0) / 100.0
            val newChange = Math.round((newLtp - inst.closePrice) * 100.0) / 100.0
            val newChangePct = Math.round(((newLtp - inst.closePrice) / inst.closePrice * 100.0) * 100.0) / 100.0

            database.instrumentDao().updateLtp(
                symbol = inst.symbol,
                ltp = newLtp,
                change = newChange,
                changePercent = newChangePct
            )

            // Update open positions for this symbol
            val openPositions = database.positionDao().getAllOpenPositions().firstOrNull() ?: emptyList()
            for (pos in openPositions.filter { it.symbol == inst.symbol }) {
                val pnl = if (pos.side == "BUY") {
                    (newLtp - pos.averageBuyPrice) * pos.quantity
                } else {
                    (pos.averageBuyPrice - newLtp) * pos.quantity
                }
                val pnlPercent = if (pos.averageBuyPrice > 0) {
                    (pnl / (pos.averageBuyPrice * pos.quantity)) * 100.0
                } else 0.0

                database.positionDao().updatePosition(
                    pos.copy(
                        ltp = newLtp,
                        pnl = Math.round(pnl * 100.0) / 100.0,
                        pnlPercent = Math.round(pnlPercent * 100.0) / 100.0
                    )
                )
            }

            // Check pending orders for trigger
            val pendingOrders = database.orderDao().getPendingOrdersOnce()
            for (order in pendingOrders.filter { it.symbol == inst.symbol }) {
                var canExecute = false
                if (order.orderType == "LIMIT") {
                    if (order.side == "BUY" && newLtp <= order.price) canExecute = true
                    if (order.side == "SELL" && newLtp >= order.price) canExecute = true
                } else if (order.orderType == "SL") {
                    if (order.side == "BUY" && newLtp >= order.triggerPrice) canExecute = true
                    if (order.side == "SELL" && newLtp <= order.triggerPrice) canExecute = true
                }

                if (canExecute) {
                    executeOrderInternal(order, newLtp)
                }
            }
        }
    }

    private suspend fun executeOrderInternal(order: OrderEntity, executionPrice: Double) {
        database.orderDao().updateOrder(
            order.copy(
                status = "EXECUTED",
                executedPrice = executionPrice,
                statusReason = "Triggered at simulated price ₹$executionPrice"
            )
        )

        // Create or update position / holding
        if (order.productType == "DELIVERY") {
            val holding = database.holdingDao().findHolding(order.userId, order.symbol)
            if (holding != null) {
                if (order.side == "BUY") {
                    val newQty = holding.quantity + order.quantity
                    val newInvested = holding.investedValue + (executionPrice * order.quantity)
                    val newAvg = newInvested / newQty
                    database.holdingDao().updateHolding(
                        holding.copy(
                            quantity = newQty,
                            averageBuyPrice = Math.round(newAvg * 100.0) / 100.0,
                            investedValue = newInvested,
                            currentValue = newQty * executionPrice,
                            pnl = (newQty * executionPrice) - newInvested,
                            pnlPercent = (((newQty * executionPrice) - newInvested) / newInvested) * 100.0
                        )
                    )
                }
            } else if (order.side == "BUY") {
                val totalCost = executionPrice * order.quantity
                database.holdingDao().insertHolding(
                    com.example.data.local.entities.HoldingEntity(
                        userId = order.userId,
                        symbol = order.symbol,
                        name = order.name,
                        quantity = order.quantity,
                        averageBuyPrice = executionPrice,
                        ltp = executionPrice,
                        investedValue = totalCost,
                        currentValue = totalCost,
                        pnl = 0.0,
                        pnlPercent = 0.0
                    )
                )
            }
        } else {
            // Intraday or F&O Position
            val existingPos = database.positionDao().findOpenPosition(order.userId, order.symbol)
            if (existingPos != null && existingPos.side == order.side) {
                val newQty = existingPos.quantity + order.quantity
                val newTotalCost = (existingPos.averageBuyPrice * existingPos.quantity) + (executionPrice * order.quantity)
                val newAvg = newTotalCost / newQty
                database.positionDao().updatePosition(
                    existingPos.copy(
                        quantity = newQty,
                        averageBuyPrice = Math.round(newAvg * 100.0) / 100.0,
                        ltp = executionPrice
                    )
                )
            } else if (existingPos != null && existingPos.side != order.side) {
                // Exit or reduce position
                if (order.quantity >= existingPos.quantity) {
                    // Close position
                    val realizedPnl = if (existingPos.side == "BUY") {
                        (executionPrice - existingPos.averageBuyPrice) * existingPos.quantity
                    } else {
                        (existingPos.averageBuyPrice - executionPrice) * existingPos.quantity
                    }
                    database.positionDao().updatePosition(
                        existingPos.copy(
                            isOpen = false,
                            closedAt = System.currentTimeMillis(),
                            pnl = realizedPnl
                        )
                    )

                    // Credit/Debit wallet
                    val wallet = database.walletDao().getWalletByUserIdOnce(order.userId)
                    if (wallet != null) {
                        val newBalance = wallet.totalBalance + realizedPnl
                        val newAvail = wallet.availableMargin + (existingPos.averageBuyPrice * existingPos.quantity) + realizedPnl
                        val newUsed = (wallet.usedMargin - (existingPos.averageBuyPrice * existingPos.quantity)).coerceAtLeast(0.0)
                        database.walletDao().updateBalances(
                            userId = order.userId,
                            avail = newAvail,
                            used = newUsed,
                            total = newBalance,
                            rPnl = wallet.realizedPnl + realizedPnl
                        )
                    }
                }
            } else {
                database.positionDao().insertPosition(
                    PositionEntity(
                        userId = order.userId,
                        symbol = order.symbol,
                        name = order.name,
                        segment = order.segment,
                        productType = order.productType,
                        side = order.side,
                        quantity = order.quantity,
                        averageBuyPrice = executionPrice,
                        ltp = executionPrice,
                        pnl = 0.0,
                        pnlPercent = 0.0,
                        isOpen = true
                    )
                )
            }
        }
    }
}
