package com.example.data.market

/**
 * Adapter for the production backend. The backend URL and authentication must
 * be supplied through secure build/deployment configuration; no provider key
 * belongs in the Android source tree.
 */
class LiveMarketDataProvider(
    private val api: MarketApi
) : MarketDataProvider {
    override suspend fun quotes(symbols: List<String>): Result<List<MarketQuote>> = runCatching {
        require(symbols.isNotEmpty()) { "At least one symbol is required" }
        api.quotes(symbols.joinToString(",")).quotes.map { it.toDomain() }
    }
}
