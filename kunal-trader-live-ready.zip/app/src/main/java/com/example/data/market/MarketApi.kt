package com.example.data.market

import retrofit2.http.GET
import retrofit2.http.Query

/**
 * Generic backend contract. The production server should authenticate the app,
 * enforce entitlements/rate limits, and return normalized quotes from the
 * licensed market-data source.
 */
interface MarketApi {
    @GET("v1/market/quotes")
    suspend fun quotes(@Query("symbols") symbols: String): MarketQuotesResponse
}

data class MarketQuotesResponse(
    val quotes: List<MarketQuoteDto> = emptyList()
)

data class MarketQuoteDto(
    val symbol: String,
    val exchange: String,
    val ltp: Double,
    val change: Double,
    val changePercent: Double,
    val volume: Long = 0L,
    val timestamp: Long = 0L
) {
    fun toDomain() = MarketQuote(
        symbol = symbol,
        exchange = exchange,
        ltp = ltp,
        change = change,
        changePercent = changePercent,
        volume = volume,
        timestamp = if (timestamp > 0) timestamp else System.currentTimeMillis()
    )
}
