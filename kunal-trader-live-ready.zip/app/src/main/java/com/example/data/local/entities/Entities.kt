package com.example.data.local.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "users")
data class UserEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val username: String,
    val fullName: String,
    val email: String,
    val phone: String,
    val pin: String = "1234",
    val role: String = "USER", // "USER", "ADMIN"
    val status: String = "ACTIVE", // "ACTIVE", "BLOCKED", "DEACTIVATED"
    val kycStatus: String = "PENDING", // "PENDING", "APPROVED", "REJECTED"
    val kycDocumentType: String = "PAN Card",
    val kycDocumentNumber: String = "ABCDE1234F",
    val kycDocumentUrl: String = "",
    val kycRemarks: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "wallets")
data class WalletEntity(
    @PrimaryKey
    val userId: Long,
    val totalBalance: Double = 500000.0, // ₹5,00,000 initial virtual cash
    val availableMargin: Double = 500000.0,
    val usedMargin: Double = 0.0,
    val realizedPnl: Double = 0.0,
    val unrealizedPnl: Double = 0.0,
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "instruments")
data class InstrumentEntity(
    @PrimaryKey
    val symbol: String, // e.g. "RELIANCE", "NIFTY24SEP25000CE", "GOLD24OCTFUT"
    val name: String,
    val segment: String, // "CASH", "INDEX", "FNO_INDEX", "FNO_STOCK", "COMMODITY"
    val exchange: String, // "NSE", "BSE", "MCX"
    val indexCategory: String = "NONE", // "NIFTY 50", "SENSEX", "BANKNIFTY", "COMMODITY", "NONE"
    val ltp: Double,
    val openPrice: Double,
    val highPrice: Double,
    val lowPrice: Double,
    val closePrice: Double,
    val change: Double,
    val changePercent: Double,
    val volume: Long = 1250000,
    val lotSize: Int = 1,
    val tickSize: Double = 0.05,
    val expiry: String = "",
    val strike: Double = 0.0,
    val optionType: String = "", // "CE", "PE", ""
    val isConstituent: Boolean = true,
    val isActive: Boolean = true
)

@Entity(tableName = "option_strikes")
data class OptionStrikeEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val underlyingSymbol: String, // "NIFTY", "BANKNIFTY", "SENSEX", "RELIANCE", "GOLD"
    val expiryDate: String, // e.g. "28 SEP 2026"
    val strikePrice: Double,
    val callSymbol: String,
    val callLtp: Double,
    val callChange: Double,
    val callOi: Long,
    val callIv: Double,
    val putSymbol: String,
    val putLtp: Double,
    val putChange: Double,
    val putOi: Long,
    val putIv: Double
)

@Entity(tableName = "orders")
data class OrderEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val userId: Long,
    val symbol: String,
    val name: String,
    val segment: String,
    val orderType: String, // "MARKET", "LIMIT", "SL"
    val productType: String, // "INTRADAY" (MIS), "DELIVERY" (CNC), "NORMAL" (NRML)
    val side: String, // "BUY", "SELL"
    val quantity: Int,
    val price: Double,
    val triggerPrice: Double = 0.0,
    val executedPrice: Double = 0.0,
    val status: String, // "EXECUTED", "PENDING", "CANCELLED", "REJECTED"
    val statusReason: String = "",
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "positions")
data class PositionEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val userId: Long,
    val symbol: String,
    val name: String,
    val segment: String,
    val productType: String, // "INTRADAY", "NORMAL"
    val side: String, // "BUY", "SELL"
    val quantity: Int,
    val averageBuyPrice: Double,
    val ltp: Double,
    val pnl: Double = 0.0,
    val pnlPercent: Double = 0.0,
    val isOpen: Boolean = true,
    val openedAt: Long = System.currentTimeMillis(),
    val closedAt: Long = 0
)

@Entity(tableName = "holdings")
data class HoldingEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val userId: Long,
    val symbol: String,
    val name: String,
    val quantity: Int,
    val averageBuyPrice: Double,
    val ltp: Double,
    val investedValue: Double,
    val currentValue: Double,
    val pnl: Double,
    val pnlPercent: Double,
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "transactions")
data class TransactionEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val userId: Long,
    val type: String, // "DEPOSIT", "WITHDRAWAL", "TRADE_BUY", "TRADE_SELL", "ADJUSTMENT"
    val amount: Double,
    val status: String, // "SUCCESS", "PENDING", "REJECTED"
    val utrOrRef: String,
    val bankAccount: String,
    val remarks: String = "",
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "bank_accounts")
data class BankAccountEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val userId: Long, // 0 for Admin Demo Banks
    val bankName: String,
    val accountNumber: String,
    val ifsc: String,
    val accountHolder: String,
    val upiId: String = "",
    val isPrimary: Boolean = false,
    val isAdminDepositBank: Boolean = false
)

@Entity(tableName = "notifications")
data class NotificationEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val userId: Long, // 0 means broadcast to all users
    val title: String,
    val message: String,
    val category: String, // "TRADE", "WALLET", "KYC", "SYSTEM", "ALERT"
    val timestamp: Long = System.currentTimeMillis(),
    val isRead: Boolean = false
)

@Entity(tableName = "audit_logs")
data class AuditLogEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val adminId: Long,
    val adminUsername: String,
    val action: String, // e.g. "APPROVE_DEPOSIT", "REJECT_KYC", "DELETE_TRADE", "UPDATE_INSTRUMENT"
    val targetType: String, // "USER", "DEPOSIT", "WITHDRAWAL", "ORDER", "KYC", "INSTRUMENT"
    val targetId: String,
    val reason: String,
    val details: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "watchlist_items")
data class WatchlistItemEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val userId: Long,
    val symbol: String,
    val addedAt: Long = System.currentTimeMillis()
)
