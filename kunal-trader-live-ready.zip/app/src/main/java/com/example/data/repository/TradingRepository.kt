package com.example.data.repository

import com.example.data.local.AppDatabase
import com.example.data.local.entities.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

class TradingRepository(private val database: AppDatabase) {

    // User & Auth
    fun getUser(userId: Long): Flow<UserEntity?> = database.userDao().getUserById(userId)
    fun getAllUsers(): Flow<List<UserEntity>> = database.userDao().getAllUsers()
    fun getPendingKycUsers(): Flow<List<UserEntity>> = database.userDao().getPendingKycUsers()

    suspend fun findUserByCredential(query: String): UserEntity? = withContext(Dispatchers.IO) {
        val clean = query.trim()
        database.userDao().findByCredential(clean)
            ?: database.userDao().findByEmailOrPhone(clean, clean)
    }

    suspend fun login(emailOrPhone: String, pin: String): Result<UserEntity> = withContext(Dispatchers.IO) {
        val cleanQuery = emailOrPhone.trim()
        val cleanPin = pin.trim()
        val user = database.userDao().findByCredential(cleanQuery)
            ?: database.userDao().findByEmailOrPhone(cleanQuery, cleanQuery)
        if (user == null) {
            Result.failure(Exception("Invalid mobile number/email or password"))
        } else if (user.pin != cleanPin) {
            Result.failure(Exception("Invalid mobile number/email or password"))
        } else if (user.status == "BLOCKED") {
            Result.failure(Exception("Account is blocked by administrator"))
        } else if (user.status == "DEACTIVATED") {
            Result.failure(Exception("Account is deactivated"))
        } else {
            Result.success(user)
        }
    }

    suspend fun loginWithOtp(phoneOrEmail: String): Result<UserEntity> = withContext(Dispatchers.IO) {
        val cleanQuery = phoneOrEmail.trim()
        val user = database.userDao().findByCredential(cleanQuery)
            ?: database.userDao().findByEmailOrPhone(cleanQuery, cleanQuery)
        if (user == null) {
            Result.failure(Exception("No account found with $cleanQuery. Please sign up."))
        } else if (user.status == "BLOCKED") {
            Result.failure(Exception("Account is blocked by administrator"))
        } else {
            Result.success(user)
        }
    }

    suspend fun resetPassword(phoneOrEmail: String, newPin: String): Result<UserEntity> = withContext(Dispatchers.IO) {
        val cleanQuery = phoneOrEmail.trim()
        val user = database.userDao().findByCredential(cleanQuery)
            ?: database.userDao().findByEmailOrPhone(cleanQuery, cleanQuery)
        if (user == null) {
            Result.failure(Exception("No account found with '$cleanQuery'"))
        } else {
            val cleanNewPin = newPin.trim()
            database.userDao().updatePassword(user.id, cleanNewPin)
            val updatedUser = user.copy(pin = cleanNewPin)
            database.notificationDao().insertNotification(
                NotificationEntity(
                    userId = user.id,
                    title = "Security Alert: Password Changed",
                    message = "Your trading terminal security PIN/password has been successfully updated.",
                    category = "SYSTEM"
                )
            )
            Result.success(updatedUser)
        }
    }

    suspend fun registerUser(
        fullName: String,
        email: String,
        phone: String,
        pin: String
    ): Result<UserEntity> = withContext(Dispatchers.IO) {
        val cleanEmail = email.trim()
        val cleanPhone = phone.trim()
        val existing = database.userDao().findByCredential(cleanEmail)
            ?: database.userDao().findByCredential(cleanPhone)
            ?: database.userDao().findByEmailOrPhone(cleanEmail, cleanPhone)
        if (existing != null) {
            return@withContext Result.failure(Exception("An account with this email or mobile number already exists"))
        }
        val newUser = UserEntity(
            username = cleanEmail.substringBefore("@").lowercase(),
            fullName = fullName.trim(),
            email = cleanEmail,
            phone = cleanPhone,
            pin = pin.trim(),
            role = "USER",
            status = "ACTIVE",
            kycStatus = "PENDING"
        )
        val newId = database.userDao().insertUser(newUser)
        // Create initial wallet with ₹5,00,000 demo margin
        database.walletDao().insertOrUpdateWallet(
            WalletEntity(
                userId = newId,
                totalBalance = 500000.0,
                availableMargin = 500000.0
            )
        )
        // Add initial deposit record
        database.transactionDao().insertTransaction(
            TransactionEntity(
                userId = newId,
                type = "DEPOSIT",
                amount = 500000.0,
                status = "SUCCESS",
                utrOrRef = "DEMO/WELCOME/${System.currentTimeMillis() % 100000}",
                bankAccount = "Kunal Trader Demo Escrow",
                remarks = "Initial Demo Trading Capital"
            )
        )
        // Welcome notification
        database.notificationDao().insertNotification(
            NotificationEntity(
                userId = newId,
                title = "Welcome to Kunal Trader!",
                message = "₹5,00,000 demo funds credited. You are ready to explore Indian stock, futures, options and commodity trading.",
                category = "SYSTEM"
            )
        )
        Result.success(newUser.copy(id = newId))
    }

    suspend fun updateUser(user: UserEntity) = withContext(Dispatchers.IO) {
        database.userDao().updateUser(user)
    }

    suspend fun deleteUser(userId: Long) = withContext(Dispatchers.IO) {
        database.userDao().deleteUserById(userId)
    }

    // Wallet & Transactions
    fun getWallet(userId: Long): Flow<WalletEntity?> = database.walletDao().getWalletByUserId(userId)
    fun getTransactions(userId: Long): Flow<List<TransactionEntity>> = database.transactionDao().getTransactionsByUserId(userId)
    fun getAllTransactions(): Flow<List<TransactionEntity>> = database.transactionDao().getAllTransactions()
    fun getPendingDeposits(): Flow<List<TransactionEntity>> = database.transactionDao().getPendingDeposits()
    fun getPendingWithdrawals(): Flow<List<TransactionEntity>> = database.transactionDao().getPendingWithdrawals()

    suspend fun requestDeposit(
        userId: Long,
        amount: Double,
        utr: String,
        bankName: String
    ): Long = withContext(Dispatchers.IO) {
        val txId = database.transactionDao().insertTransaction(
            TransactionEntity(
                userId = userId,
                type = "DEPOSIT",
                amount = amount,
                status = "PENDING",
                utrOrRef = utr,
                bankAccount = bankName,
                remarks = "Deposit request pending verification"
            )
        )
        database.notificationDao().insertNotification(
            NotificationEntity(
                userId = userId,
                title = "Deposit Request Submitted",
                message = "Your deposit request for ₹$amount (UTR: $utr) is received and pending admin approval.",
                category = "WALLET"
            )
        )
        txId
    }

    suspend fun requestWithdrawal(
        userId: Long,
        amount: Double,
        bankAccountStr: String
    ): Result<Long> = withContext(Dispatchers.IO) {
        val wallet = database.walletDao().getWalletByUserIdOnce(userId)
        if (wallet == null || wallet.availableMargin < amount) {
            return@withContext Result.failure(Exception("Insufficient available margin (Available: ₹${wallet?.availableMargin ?: 0.0})"))
        }

        // Lock margin
        val newAvail = wallet.availableMargin - amount
        val newUsed = wallet.usedMargin + amount
        database.walletDao().updateBalances(
            userId = userId,
            avail = newAvail,
            used = newUsed,
            total = wallet.totalBalance,
            rPnl = wallet.realizedPnl
        )

        val txId = database.transactionDao().insertTransaction(
            TransactionEntity(
                userId = userId,
                type = "WITHDRAWAL",
                amount = amount,
                status = "PENDING",
                utrOrRef = "WDR/REQ/${System.currentTimeMillis() % 100000}",
                bankAccount = bankAccountStr,
                remarks = "Withdrawal submitted for processing"
            )
        )

        database.notificationDao().insertNotification(
            NotificationEntity(
                userId = userId,
                title = "Withdrawal Request Received",
                message = "Withdrawal of ₹$amount to $bankAccountStr is under review.",
                category = "WALLET"
            )
        )

        Result.success(txId)
    }

    // Admin Deposit / Withdrawal Approval
    suspend fun approveDeposit(
        txId: Long,
        adminId: Long,
        adminUsername: String,
        reason: String
    ) = withContext(Dispatchers.IO) {
        val tx = database.transactionDao().getTransactionById(txId) ?: return@withContext
        database.transactionDao().updateTransaction(
            tx.copy(status = "SUCCESS", remarks = "Approved by Admin: $reason")
        )
        val wallet = database.walletDao().getWalletByUserIdOnce(tx.userId)
        if (wallet != null) {
            database.walletDao().updateBalances(
                userId = tx.userId,
                avail = wallet.availableMargin + tx.amount,
                used = wallet.usedMargin,
                total = wallet.totalBalance + tx.amount,
                rPnl = wallet.realizedPnl
            )
        }
        database.notificationDao().insertNotification(
            NotificationEntity(
                userId = tx.userId,
                title = "Deposit Approved ✅",
                message = "₹${tx.amount} has been added to your trading wallet.",
                category = "WALLET"
            )
        )
        database.auditLogDao().insertAuditLog(
            AuditLogEntity(
                adminId = adminId,
                adminUsername = adminUsername,
                action = "APPROVE_DEPOSIT",
                targetType = "DEPOSIT",
                targetId = txId.toString(),
                reason = reason,
                details = "Approved ₹${tx.amount} for User ID ${tx.userId}"
            )
        )
    }

    suspend fun rejectDeposit(
        txId: Long,
        adminId: Long,
        adminUsername: String,
        reason: String
    ) = withContext(Dispatchers.IO) {
        val tx = database.transactionDao().getTransactionById(txId) ?: return@withContext
        database.transactionDao().updateTransaction(
            tx.copy(status = "REJECTED", remarks = "Rejected: $reason")
        )
        database.notificationDao().insertNotification(
            NotificationEntity(
                userId = tx.userId,
                title = "Deposit Rejected ❌",
                message = "Deposit of ₹${tx.amount} was rejected. Reason: $reason",
                category = "WALLET"
            )
        )
        database.auditLogDao().insertAuditLog(
            AuditLogEntity(
                adminId = adminId,
                adminUsername = adminUsername,
                action = "REJECT_DEPOSIT",
                targetType = "DEPOSIT",
                targetId = txId.toString(),
                reason = reason,
                details = "Rejected deposit ₹${tx.amount} for User ID ${tx.userId}"
            )
        )
    }

    suspend fun approveWithdrawal(
        txId: Long,
        adminId: Long,
        adminUsername: String,
        reason: String
    ) = withContext(Dispatchers.IO) {
        val tx = database.transactionDao().getTransactionById(txId) ?: return@withContext
        database.transactionDao().updateTransaction(
            tx.copy(status = "SUCCESS", remarks = "Disbursed by Admin: $reason")
        )
        val wallet = database.walletDao().getWalletByUserIdOnce(tx.userId)
        if (wallet != null) {
            database.walletDao().updateBalances(
                userId = tx.userId,
                avail = wallet.availableMargin,
                used = (wallet.usedMargin - tx.amount).coerceAtLeast(0.0),
                total = wallet.totalBalance - tx.amount,
                rPnl = wallet.realizedPnl
            )
        }
        database.notificationDao().insertNotification(
            NotificationEntity(
                userId = tx.userId,
                title = "Withdrawal Disbursed 💸",
                message = "₹${tx.amount} has been successfully sent to your bank.",
                category = "WALLET"
            )
        )
        database.auditLogDao().insertAuditLog(
            AuditLogEntity(
                adminId = adminId,
                adminUsername = adminUsername,
                action = "APPROVE_WITHDRAWAL",
                targetType = "WITHDRAWAL",
                targetId = txId.toString(),
                reason = reason,
                details = "Disbursed ₹${tx.amount} for User ID ${tx.userId}"
            )
        )
    }

    suspend fun rejectWithdrawal(
        txId: Long,
        adminId: Long,
        adminUsername: String,
        reason: String
    ) = withContext(Dispatchers.IO) {
        val tx = database.transactionDao().getTransactionById(txId) ?: return@withContext
        database.transactionDao().updateTransaction(
            tx.copy(status = "REJECTED", remarks = "Rejected: $reason")
        )
        val wallet = database.walletDao().getWalletByUserIdOnce(tx.userId)
        if (wallet != null) {
            // Refund locked margin
            database.walletDao().updateBalances(
                userId = tx.userId,
                avail = wallet.availableMargin + tx.amount,
                used = (wallet.usedMargin - tx.amount).coerceAtLeast(0.0),
                total = wallet.totalBalance,
                rPnl = wallet.realizedPnl
            )
        }
        database.notificationDao().insertNotification(
            NotificationEntity(
                userId = tx.userId,
                title = "Withdrawal Cancelled/Rejected",
                message = "Withdrawal of ₹${tx.amount} was rejected and refunded to available margin. Reason: $reason",
                category = "WALLET"
            )
        )
        database.auditLogDao().insertAuditLog(
            AuditLogEntity(
                adminId = adminId,
                adminUsername = adminUsername,
                action = "REJECT_WITHDRAWAL",
                targetType = "WITHDRAWAL",
                targetId = txId.toString(),
                reason = reason,
                details = "Rejected withdrawal ₹${tx.amount} for User ID ${tx.userId}"
            )
        )
    }

    // KYC Operations
    suspend fun submitKyc(
        userId: Long,
        docType: String,
        docNumber: String
    ) = withContext(Dispatchers.IO) {
        val user = database.userDao().getUserByIdOnce(userId) ?: return@withContext
        database.userDao().updateUser(
            user.copy(
                kycDocumentType = docType,
                kycDocumentNumber = docNumber,
                kycStatus = "PENDING",
                kycRemarks = "Submitted on ${java.text.SimpleDateFormat("dd MMM yyyy", java.util.Locale.ENGLISH).format(java.util.Date())}"
            )
        )
        database.notificationDao().insertNotification(
            NotificationEntity(
                userId = userId,
                title = "KYC Documents Uploaded",
                message = "Your $docType ($docNumber) is undergoing verification.",
                category = "KYC"
            )
        )
    }

    suspend fun verifyKyc(
        userId: Long,
        status: String, // "APPROVED" or "REJECTED"
        remarks: String,
        adminId: Long,
        adminUsername: String
    ) = withContext(Dispatchers.IO) {
        val user = database.userDao().getUserByIdOnce(userId) ?: return@withContext
        database.userDao().updateUser(
            user.copy(kycStatus = status, kycRemarks = remarks)
        )
        database.notificationDao().insertNotification(
            NotificationEntity(
                userId = userId,
                title = if (status == "APPROVED") "KYC Approved! 🎉" else "KYC Rejected ⚠️",
                message = if (status == "APPROVED") "Your trading account KYC is fully verified." else "KYC verification failed: $remarks",
                category = "KYC"
            )
        )
        database.auditLogDao().insertAuditLog(
            AuditLogEntity(
                adminId = adminId,
                adminUsername = adminUsername,
                action = "VERIFY_KYC_$status",
                targetType = "KYC",
                targetId = userId.toString(),
                reason = remarks,
                details = "Set KYC status to $status for user ${user.fullName}"
            )
        )
    }

    // Instruments & Market Data
    fun getAllInstruments(): Flow<List<InstrumentEntity>> = database.instrumentDao().getAllInstruments()
    fun getActiveInstruments(): Flow<List<InstrumentEntity>> = database.instrumentDao().getAllActiveInstruments()
    fun getInstrumentsBySegment(segment: String): Flow<List<InstrumentEntity>> = database.instrumentDao().getInstrumentsBySegment(segment)
    fun getInstrumentsByIndex(indexCat: String): Flow<List<InstrumentEntity>> = database.instrumentDao().getInstrumentsByIndex(indexCat)
    fun getInstrument(symbol: String): Flow<InstrumentEntity?> = database.instrumentDao().getInstrumentBySymbol(symbol)
    suspend fun getInstrumentOnce(symbol: String): InstrumentEntity? = database.instrumentDao().getInstrumentBySymbolOnce(symbol)
    fun searchInstruments(query: String): Flow<List<InstrumentEntity>> = database.instrumentDao().searchInstruments(query)

    suspend fun saveInstrument(instrument: InstrumentEntity) = withContext(Dispatchers.IO) {
        database.instrumentDao().insertInstrument(instrument)
    }

    suspend fun deleteInstrument(symbol: String) = withContext(Dispatchers.IO) {
        database.instrumentDao().deleteInstrumentBySymbol(symbol)
    }

    // Option Chain
    private fun normalizeOptionUnderlying(symbol: String): String {
        val trimmed = symbol.trim()
        return when {
            trimmed.equals("NIFTY 50", ignoreCase = true) || trimmed.equals("NIFTY", ignoreCase = true) -> "NIFTY"
            trimmed.equals("SENSEX", ignoreCase = true) -> "SENSEX"
            trimmed.equals("BANKNIFTY", ignoreCase = true) || trimmed.equals("BANK NIFTY", ignoreCase = true) -> "BANKNIFTY"
            trimmed.equals("GOLD", ignoreCase = true) || trimmed.startsWith("GOLD", ignoreCase = true) -> "GOLD"
            trimmed.equals("SILVER", ignoreCase = true) || trimmed.startsWith("SILVER", ignoreCase = true) -> "SILVER"
            trimmed.equals("CRUDEOIL", ignoreCase = true) || trimmed.startsWith("CRUDE", ignoreCase = true) -> "CRUDEOIL"
            trimmed.equals("NATURALGAS", ignoreCase = true) || trimmed.startsWith("NATGAS", ignoreCase = true) -> "NATURALGAS"
            else -> trimmed
        }
    }

    fun getOptionChain(symbol: String): Flow<List<OptionStrikeEntity>> =
        database.optionStrikeDao().getOptionChain(normalizeOptionUnderlying(symbol))

    fun getOptionChainByExpiry(symbol: String, expiry: String): Flow<List<OptionStrikeEntity>> =
        database.optionStrikeDao().getOptionChainByExpiry(normalizeOptionUnderlying(symbol), expiry)

    fun getAvailableExpiries(symbol: String): Flow<List<String>> =
        database.optionStrikeDao().getAvailableExpiries(normalizeOptionUnderlying(symbol))

    suspend fun updateOptionStrike(strike: OptionStrikeEntity) = withContext(Dispatchers.IO) {
        database.optionStrikeDao().updateStrike(strike)
    }

    // Order Placement & Execution
    fun getOrdersForUser(userId: Long): Flow<List<OrderEntity>> = database.orderDao().getOrdersByUserId(userId)
    fun getAllOrders(): Flow<List<OrderEntity>> = database.orderDao().getAllOrders()
    fun getPositionsForUser(userId: Long): Flow<List<PositionEntity>> = database.positionDao().getOpenPositionsByUserId(userId)
    fun getAllPositionsForUser(userId: Long): Flow<List<PositionEntity>> = database.positionDao().getAllPositionsByUserId(userId)
    fun getHoldingsForUser(userId: Long): Flow<List<HoldingEntity>> = database.holdingDao().getHoldingsByUserId(userId)
    fun getAllOpenPositions(): Flow<List<PositionEntity>> = database.positionDao().getAllOpenPositions()

    suspend fun placeOrder(
        userId: Long,
        symbol: String,
        name: String,
        segment: String,
        orderType: String, // "MARKET", "LIMIT", "SL"
        productType: String, // "INTRADAY", "DELIVERY", "NORMAL"
        side: String, // "BUY", "SELL"
        quantity: Int,
        price: Double,
        triggerPrice: Double = 0.0
    ): Result<OrderEntity> = withContext(Dispatchers.IO) {
        val instrument = database.instrumentDao().getInstrumentBySymbolOnce(symbol)
        val executionPrice = instrument?.ltp ?: price
        val totalCost = (if (orderType == "MARKET") executionPrice else price) * quantity

        val wallet = database.walletDao().getWalletByUserIdOnce(userId)
        if (wallet == null) {
            return@withContext Result.failure(Exception("Wallet not found"))
        }

        if (side == "BUY" && wallet.availableMargin < totalCost) {
            return@withContext Result.failure(Exception("Insufficient margin. Required: ₹${Math.round(totalCost * 100.0) / 100.0}, Available: ₹${wallet.availableMargin}"))
        }

        val isImmediateMarket = (orderType == "MARKET")
        val orderStatus = if (isImmediateMarket) "EXECUTED" else "PENDING"
        val statusReason = if (isImmediateMarket) "Executed at Market Price" else "Placed in Order Book"

        val order = OrderEntity(
            userId = userId,
            symbol = symbol,
            name = name,
            segment = segment,
            orderType = orderType,
            productType = productType,
            side = side,
            quantity = quantity,
            price = price,
            triggerPrice = triggerPrice,
            executedPrice = if (isImmediateMarket) executionPrice else 0.0,
            status = orderStatus,
            statusReason = statusReason
        )
        val orderId = database.orderDao().insertOrder(order)
        val savedOrder = order.copy(id = orderId)

        if (isImmediateMarket) {
            // Apply immediately to Wallet and Positions / Holdings
            if (productType == "DELIVERY") {
                val existingHolding = database.holdingDao().findHolding(userId, symbol)
                if (side == "BUY") {
                    val newAvail = wallet.availableMargin - totalCost
                    val newUsed = wallet.usedMargin + totalCost
                    database.walletDao().updateBalances(userId, newAvail, newUsed, wallet.totalBalance, wallet.realizedPnl)

                    if (existingHolding != null) {
                        val newQty = existingHolding.quantity + quantity
                        val newInv = existingHolding.investedValue + totalCost
                        val newAvg = newInv / newQty
                        database.holdingDao().updateHolding(
                            existingHolding.copy(
                                quantity = newQty,
                                averageBuyPrice = Math.round(newAvg * 100.0) / 100.0,
                                investedValue = newInv,
                                currentValue = newQty * executionPrice,
                                pnl = (newQty * executionPrice) - newInv,
                                pnlPercent = (((newQty * executionPrice) - newInv) / newInv) * 100.0
                            )
                        )
                    } else {
                        database.holdingDao().insertHolding(
                            HoldingEntity(
                                userId = userId,
                                symbol = symbol,
                                name = name,
                                quantity = quantity,
                                averageBuyPrice = executionPrice,
                                ltp = executionPrice,
                                investedValue = totalCost,
                                currentValue = totalCost,
                                pnl = 0.0,
                                pnlPercent = 0.0
                            )
                        )
                    }
                } else {
                    // SELL Holding
                    if (existingHolding == null || existingHolding.quantity < quantity) {
                        return@withContext Result.failure(Exception("Insufficient holdings to sell"))
                    }
                    val saleProceeds = executionPrice * quantity
                    val costOfSold = existingHolding.averageBuyPrice * quantity
                    val profitOnSale = saleProceeds - costOfSold

                    val newQty = existingHolding.quantity - quantity
                    if (newQty <= 0) {
                        database.holdingDao().deleteHolding(existingHolding)
                    } else {
                        val newInv = existingHolding.investedValue - costOfSold
                        database.holdingDao().updateHolding(
                            existingHolding.copy(
                                quantity = newQty,
                                investedValue = newInv,
                                currentValue = newQty * executionPrice,
                                pnl = (newQty * executionPrice) - newInv,
                                pnlPercent = (((newQty * executionPrice) - newInv) / newInv) * 100.0
                            )
                        )
                    }

                    database.walletDao().updateBalances(
                        userId = userId,
                        avail = wallet.availableMargin + saleProceeds,
                        used = (wallet.usedMargin - costOfSold).coerceAtLeast(0.0),
                        total = wallet.totalBalance + profitOnSale,
                        rPnl = wallet.realizedPnl + profitOnSale
                    )
                }
            } else {
                // INTRADAY / F&O POSITIONS
                val existingPos = database.positionDao().findOpenPosition(userId, symbol)
                if (existingPos != null && existingPos.side == side) {
                    val newQty = existingPos.quantity + quantity
                    val newTotal = (existingPos.averageBuyPrice * existingPos.quantity) + totalCost
                    val newAvg = newTotal / newQty
                    database.positionDao().updatePosition(
                        existingPos.copy(
                            quantity = newQty,
                            averageBuyPrice = Math.round(newAvg * 100.0) / 100.0,
                            ltp = executionPrice
                        )
                    )
                } else if (existingPos != null && existingPos.side != side) {
                    // Exit position
                    val realizedPnl = if (existingPos.side == "BUY") {
                        (executionPrice - existingPos.averageBuyPrice) * existingPos.quantity
                    } else {
                        (existingPos.averageBuyPrice - executionPrice) * existingPos.quantity
                    }
                    database.positionDao().updatePosition(
                        existingPos.copy(isOpen = false, closedAt = System.currentTimeMillis(), pnl = realizedPnl)
                    )
                    val originalMargin = existingPos.averageBuyPrice * existingPos.quantity
                    database.walletDao().updateBalances(
                        userId = userId,
                        avail = wallet.availableMargin + originalMargin + realizedPnl,
                        used = (wallet.usedMargin - originalMargin).coerceAtLeast(0.0),
                        total = wallet.totalBalance + realizedPnl,
                        rPnl = wallet.realizedPnl + realizedPnl
                    )
                } else {
                    val newAvail = wallet.availableMargin - totalCost
                    val newUsed = wallet.usedMargin + totalCost
                    database.walletDao().updateBalances(userId, newAvail, newUsed, wallet.totalBalance, wallet.realizedPnl)
                    database.positionDao().insertPosition(
                        PositionEntity(
                            userId = userId,
                            symbol = symbol,
                            name = name,
                            segment = segment,
                            productType = productType,
                            side = side,
                            quantity = quantity,
                            averageBuyPrice = executionPrice,
                            ltp = executionPrice,
                            pnl = 0.0,
                            pnlPercent = 0.0,
                            isOpen = true
                        )
                    )
                }
            }

            database.notificationDao().insertNotification(
                NotificationEntity(
                    userId = userId,
                    title = "Order Executed ✅",
                    message = "$side $quantity Qty of $symbol @ ₹$executionPrice ($productType)",
                    category = "TRADE"
                )
            )
        } else {
            database.notificationDao().insertNotification(
                NotificationEntity(
                    userId = userId,
                    title = "Order Placed (Pending) ⏳",
                    message = "$side $quantity Qty of $symbol ($orderType) @ ₹$price placed.",
                    category = "TRADE"
                )
            )
        }

        Result.success(savedOrder)
    }

    suspend fun cancelOrder(orderId: Long, userId: Long): Result<Unit> = withContext(Dispatchers.IO) {
        val order = database.orderDao().getOrderById(orderId)
        if (order == null || order.status != "PENDING") {
            return@withContext Result.failure(Exception("Order cannot be cancelled or is already processed"))
        }
        database.orderDao().updateOrder(
            order.copy(status = "CANCELLED", statusReason = "Cancelled by user")
        )
        database.notificationDao().insertNotification(
            NotificationEntity(
                userId = userId,
                title = "Order Cancelled",
                message = "Order #${order.id} for ${order.symbol} has been cancelled.",
                category = "TRADE"
            )
        )
        Result.success(Unit)
    }

    suspend fun adminCancelOrder(
        orderId: Long,
        adminId: Long,
        adminUsername: String,
        reason: String
    ): Result<Unit> = withContext(Dispatchers.IO) {
        val order = database.orderDao().getOrderById(orderId)
        if (order == null) return@withContext Result.failure(Exception("Order not found"))
        database.orderDao().updateOrder(
            order.copy(status = "CANCELLED", statusReason = "Cancelled by Admin: $reason")
        )
        database.auditLogDao().insertAuditLog(
            AuditLogEntity(
                adminId = adminId,
                adminUsername = adminUsername,
                action = "ADMIN_CANCEL_ORDER",
                targetType = "ORDER",
                targetId = orderId.toString(),
                reason = reason,
                details = "Cancelled order for user #${order.userId}, Symbol ${order.symbol}"
            )
        )
        Result.success(Unit)
    }

    suspend fun adminPlaceTradeForUser(
        adminId: Long,
        adminUsername: String,
        targetUserId: Long,
        segment: String, // Stock, Index, Stock Option, Index Option, Commodity, Commodity Option
        symbol: String,
        name: String,
        side: String, // BUY, SELL
        orderType: String, // MARKET, LIMIT, SL
        productType: String, // INTRADAY, CNC, NRML
        quantity: Int,
        price: Double,
        strikePrice: Double? = null,
        optionType: String? = null, // CE, PE
        expiry: String? = null,
        lotSize: Int = 1,
        notes: String,
        status: String = "EXECUTED" // EXECUTED, PENDING
    ): Result<OrderEntity> = withContext(Dispatchers.IO) {
        val wallet = database.walletDao().getWalletByUserIdOnce(targetUserId)
            ?: return@withContext Result.failure(Exception("Target user wallet not found"))

        val finalSymbol = when {
            optionType != null && strikePrice != null && expiry != null -> {
                "${symbol.replace(" ", "")} ${expiry} ${strikePrice.toInt()}${optionType}"
            }
            strikePrice != null && optionType != null -> {
                "${symbol.replace(" ", "")} ${strikePrice.toInt()}${optionType}"
            }
            else -> symbol
        }

        val totalCost = price * quantity
        val newOrder = OrderEntity(
            userId = targetUserId,
            symbol = finalSymbol,
            name = name.ifBlank { finalSymbol },
            segment = segment,
            productType = productType,
            side = side,
            orderType = orderType,
            quantity = quantity,
            price = price,
            executedPrice = if (status == "EXECUTED") price else 0.0,
            status = status,
            statusReason = if (status == "EXECUTED") "Simulated Admin Order Placement" else "Admin Placed (Pending)"
        )

        val orderId = database.orderDao().insertOrder(newOrder)
        val savedOrder = newOrder.copy(id = orderId)

        if (status == "EXECUTED") {
            if (productType == "CNC" && segment == "EQUITY") {
                if (side == "BUY") {
                    val existing = database.holdingDao().findHolding(targetUserId, finalSymbol)
                    if (existing != null) {
                        val newQty = existing.quantity + quantity
                        val newInv = existing.investedValue + totalCost
                        val newAvg = newInv / newQty
                        database.holdingDao().updateHolding(
                            existing.copy(
                                quantity = newQty,
                                averageBuyPrice = Math.round(newAvg * 100.0) / 100.0,
                                investedValue = newInv,
                                currentValue = newQty * price,
                                pnl = (newQty * price) - newInv,
                                pnlPercent = (((newQty * price) - newInv) / newInv) * 100.0
                            )
                        )
                    } else {
                        database.holdingDao().insertHolding(
                            HoldingEntity(
                                userId = targetUserId,
                                symbol = finalSymbol,
                                name = name.ifBlank { finalSymbol },
                                quantity = quantity,
                                averageBuyPrice = price,
                                ltp = price,
                                investedValue = totalCost,
                                currentValue = totalCost,
                                pnl = 0.0,
                                pnlPercent = 0.0
                            )
                        )
                    }
                    val newAvail = (wallet.availableMargin - totalCost).coerceAtLeast(0.0)
                    val newUsed = wallet.usedMargin + totalCost
                    database.walletDao().updateBalances(targetUserId, newAvail, newUsed, wallet.totalBalance, wallet.realizedPnl)
                }
            } else {
                // Open Position
                val existingPos = database.positionDao().findOpenPosition(targetUserId, finalSymbol)
                if (existingPos != null && existingPos.side == side) {
                    val newQty = existingPos.quantity + quantity
                    val newAvg = ((existingPos.averageBuyPrice * existingPos.quantity) + totalCost) / newQty
                    database.positionDao().updatePosition(
                        existingPos.copy(
                            quantity = newQty,
                            averageBuyPrice = Math.round(newAvg * 100.0) / 100.0,
                            ltp = price
                        )
                    )
                } else {
                    database.positionDao().insertPosition(
                        PositionEntity(
                            userId = targetUserId,
                            symbol = finalSymbol,
                            name = name.ifBlank { finalSymbol },
                            segment = segment,
                            productType = productType,
                            side = side,
                            quantity = quantity,
                            averageBuyPrice = price,
                            ltp = price,
                            pnl = 0.0,
                            pnlPercent = 0.0,
                            isOpen = true
                        )
                    )
                }
                val newAvail = (wallet.availableMargin - totalCost).coerceAtLeast(0.0)
                val newUsed = wallet.usedMargin + totalCost
                database.walletDao().updateBalances(targetUserId, newAvail, newUsed, wallet.totalBalance, wallet.realizedPnl)
            }
        }

        database.auditLogDao().insertAuditLog(
            AuditLogEntity(
                adminId = adminId,
                adminUsername = adminUsername,
                action = "ADMIN_PLACE_TRADE",
                targetType = "USER_TRADE",
                targetId = orderId.toString(),
                reason = notes.ifBlank { "Admin manual trade injection" },
                details = "Admin created simulated trade: $side $quantity Qty of $finalSymbol @ ₹$price for User #$targetUserId (Status: $status)"
            )
        )

        database.notificationDao().insertNotification(
            NotificationEntity(
                userId = targetUserId,
                title = "Trade Added by Admin",
                message = "Trade order #$orderId: $side $quantity $finalSymbol @ ₹$price has been placed on your account.",
                category = "TRADE"
            )
        )

        Result.success(savedOrder)
    }

    suspend fun adminEditTrade(
        adminId: Long,
        adminUsername: String,
        orderId: Long,
        newPrice: Double,
        newQuantity: Int,
        newStatus: String,
        reason: String
    ): Result<Unit> = withContext(Dispatchers.IO) {
        val order = database.orderDao().getOrderById(orderId)
            ?: return@withContext Result.failure(Exception("Order not found"))

        val updatedOrder = order.copy(
            price = newPrice,
            executedPrice = if (newStatus == "EXECUTED") newPrice else order.executedPrice,
            quantity = newQuantity,
            status = newStatus,
            statusReason = "Modified by Admin: $reason"
        )
        database.orderDao().updateOrder(updatedOrder)

        // Update corresponding open position if exists
        val pos = database.positionDao().findOpenPosition(order.userId, order.symbol)
        if (pos != null) {
            database.positionDao().updatePosition(
                pos.copy(
                    quantity = newQuantity,
                    averageBuyPrice = newPrice,
                    ltp = newPrice
                )
            )
        }

        database.auditLogDao().insertAuditLog(
            AuditLogEntity(
                adminId = adminId,
                adminUsername = adminUsername,
                action = "ADMIN_EDIT_TRADE",
                targetType = "ORDER",
                targetId = orderId.toString(),
                reason = reason.ifBlank { "Admin manual trade modification" },
                details = "Modified trade #$orderId for User #${order.userId}: Qty=$newQuantity, Price=₹$newPrice, Status=$newStatus"
            )
        )

        Result.success(Unit)
    }

    suspend fun adminDeleteOrCorrectTrade(
        orderId: Long,
        adminId: Long,
        adminUsername: String,
        auditReason: String
    ): Result<Unit> = withContext(Dispatchers.IO) {
        if (auditReason.isBlank()) {
            return@withContext Result.failure(Exception("Mandatory audit reason is required for trade correction"))
        }
        val order = database.orderDao().getOrderById(orderId)
        if (order != null) {
            database.orderDao().deleteOrderById(orderId)

            // If an open position exists for this symbol, remove it and restore margin
            val pos = database.positionDao().findOpenPosition(order.userId, order.symbol)
            if (pos != null) {
                database.positionDao().deletePosition(pos)
                val wallet = database.walletDao().getWalletByUserIdOnce(order.userId)
                if (wallet != null) {
                    val marginToRestore = pos.averageBuyPrice * pos.quantity
                    database.walletDao().updateBalances(
                        userId = order.userId,
                        avail = wallet.availableMargin + marginToRestore,
                        used = (wallet.usedMargin - marginToRestore).coerceAtLeast(0.0),
                        total = wallet.totalBalance,
                        rPnl = wallet.realizedPnl
                    )
                }
            }

            database.auditLogDao().insertAuditLog(
                AuditLogEntity(
                    adminId = adminId,
                    adminUsername = adminUsername,
                    action = "CORRECT_DELETE_TRADE",
                    targetType = "ORDER",
                    targetId = orderId.toString(),
                    reason = auditReason,
                    details = "Deleted trade record ${order.symbol} (${order.side} ${order.quantity} Qty) for User ID #${order.userId} & recalculated positions"
                )
            )
            Result.success(Unit)
        } else {
            Result.failure(Exception("Trade record not found"))
        }
    }

    // Bank Accounts
    fun getBankAccountsForUser(userId: Long): Flow<List<BankAccountEntity>> = database.bankAccountDao().getBankAccountsByUserId(userId)
    fun getAdminDepositBanks(): Flow<List<BankAccountEntity>> = database.bankAccountDao().getAdminDepositBanks()
    fun getAllBankAccounts(): Flow<List<BankAccountEntity>> = database.bankAccountDao().getAllBankAccounts()

    suspend fun addBankAccount(account: BankAccountEntity) = withContext(Dispatchers.IO) {
        database.bankAccountDao().insertBankAccount(account)
    }

    suspend fun updateBankAccount(account: BankAccountEntity) = withContext(Dispatchers.IO) {
        database.bankAccountDao().updateBankAccount(account)
    }

    suspend fun deleteBankAccount(id: Long) = withContext(Dispatchers.IO) {
        database.bankAccountDao().deleteBankAccountById(id)
    }

    // Watchlist
    fun getWatchlist(userId: Long): Flow<List<WatchlistItemEntity>> = database.watchlistDao().getWatchlistForUser(userId)
    fun isInWatchlist(userId: Long, symbol: String): Flow<Boolean> = database.watchlistDao().isInWatchlist(userId, symbol)

    suspend fun toggleWatchlist(userId: Long, symbol: String, isCurrentlyIn: Boolean) = withContext(Dispatchers.IO) {
        if (isCurrentlyIn) {
            database.watchlistDao().removeFromWatchlist(userId, symbol)
        } else {
            database.watchlistDao().addToWatchlist(WatchlistItemEntity(userId = userId, symbol = symbol))
        }
    }

    // Notifications
    fun getNotifications(userId: Long): Flow<List<NotificationEntity>> = database.notificationDao().getNotificationsForUser(userId)
    suspend fun markAllNotificationsRead(userId: Long) = withContext(Dispatchers.IO) {
        database.notificationDao().markAllAsRead(userId)
    }

    suspend fun sendBroadcastNotification(
        adminId: Long,
        adminUsername: String,
        title: String,
        message: String,
        targetUserId: Long = 0
    ) = withContext(Dispatchers.IO) {
        database.notificationDao().insertNotification(
            NotificationEntity(
                userId = targetUserId,
                title = title,
                message = message,
                category = "ADMIN"
            )
        )
        database.auditLogDao().insertAuditLog(
            AuditLogEntity(
                adminId = adminId,
                adminUsername = adminUsername,
                action = "SEND_NOTIFICATION",
                targetType = "NOTIFICATION",
                targetId = targetUserId.toString(),
                reason = "Admin Message Dispatch",
                details = "Sent notification '$title' to target $targetUserId"
            )
        )
    }

    // Audit Logs
    fun getAllAuditLogs(): Flow<List<AuditLogEntity>> = database.auditLogDao().getAllAuditLogs()
}
