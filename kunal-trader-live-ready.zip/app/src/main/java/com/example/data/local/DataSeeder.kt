package com.example.data.local

import com.example.data.local.entities.*
import kotlin.random.Random

object DataSeeder {

    fun getInitialUsers(): List<UserEntity> {
        return listOf(
            UserEntity(
                id = 1,
                username = "kunal_trader",
                fullName = "Kunal Sharma",
                email = "kunal@trader.demo",
                phone = "+91 98765 43210",
                pin = "1234",
                role = "USER",
                status = "ACTIVE",
                kycStatus = "APPROVED",
                kycDocumentType = "PAN Card",
                kycDocumentNumber = "ABCDE1234F",
                kycRemarks = "Verified automatically with demo KYC check"
            ),
            UserEntity(
                id = 2,
                username = "admin_master",
                fullName = "Master Administrator",
                email = "admin@kunaltrader.com",
                phone = "+91 99999 88888",
                pin = "9999",
                role = "ADMIN",
                status = "ACTIVE",
                kycStatus = "APPROVED",
                kycDocumentType = "Director ID",
                kycDocumentNumber = "DIR98765432",
                kycRemarks = "Platform Superuser"
            ),
            UserEntity(
                id = 3,
                username = "priya_investor",
                fullName = "Priya Verma",
                email = "priya@demo.com",
                phone = "+91 98111 22233",
                pin = "1234",
                role = "USER",
                status = "ACTIVE",
                kycStatus = "PENDING",
                kycDocumentType = "Aadhaar Card",
                kycDocumentNumber = "9876 5432 1098",
                kycRemarks = "Awaiting admin document verification"
            )
        )
    }

    fun getInitialWallets(): List<WalletEntity> {
        return listOf(
            WalletEntity(
                userId = 1,
                totalBalance = 500000.0,
                availableMargin = 412500.0,
                usedMargin = 87500.0,
                realizedPnl = 12450.0,
                unrealizedPnl = 8320.0
            ),
            WalletEntity(
                userId = 2,
                totalBalance = 10000000.0,
                availableMargin = 10000000.0,
                usedMargin = 0.0,
                realizedPnl = 0.0,
                unrealizedPnl = 0.0
            ),
            WalletEntity(
                userId = 3,
                totalBalance = 250000.0,
                availableMargin = 250000.0,
                usedMargin = 0.0,
                realizedPnl = 0.0,
                unrealizedPnl = 0.0
            )
        )
    }

    fun getInitialAdminBanks(): List<BankAccountEntity> {
        return listOf(
            BankAccountEntity(
                id = 1,
                userId = 0,
                bankName = "HDFC Bank (Demo Deposit Escrow)",
                accountNumber = "50200098765432",
                ifsc = "HDFC0000128",
                accountHolder = "KUNAL TRADER CLEARING CORP",
                upiId = "kunaltrader@hdfcbank",
                isPrimary = true,
                isAdminDepositBank = true
            ),
            BankAccountEntity(
                id = 2,
                userId = 0,
                bankName = "ICICI Bank (Demo Instant UPI)",
                accountNumber = "000405012987",
                ifsc = "ICIC0000004",
                accountHolder = "KUNAL TRADER SETTLEMENT",
                upiId = "pay.kunaltrader@icici",
                isPrimary = false,
                isAdminDepositBank = true
            ),
            BankAccountEntity(
                id = 3,
                userId = 1,
                bankName = "State Bank of India",
                accountNumber = "30987654321",
                ifsc = "SBIN0001234",
                accountHolder = "Kunal Sharma",
                upiId = "kunal@oksbi",
                isPrimary = true,
                isAdminDepositBank = false
            )
        )
    }

    // Comprehensive list of all NIFTY 50 Stocks + Sensex constituents + Commodities + Indices
    fun getInitialInstruments(): List<InstrumentEntity> {
        val list = mutableListOf<InstrumentEntity>()

        // 1. Major Benchmark Indices
        list.add(InstrumentEntity("NIFTY 50", "Nifty 50 Index", "INDEX", "NSE", "NIFTY 50", 25380.50, 25250.00, 25420.75, 25210.00, 25260.00, 120.50, 0.48, lotSize = 25))
        list.add(InstrumentEntity("SENSEX", "BSE Sensex Index", "INDEX", "BSE", "SENSEX", 82950.20, 82600.00, 83120.50, 82500.00, 82580.00, 370.20, 0.45, lotSize = 10))
        list.add(InstrumentEntity("BANKNIFTY", "Nifty Bank Index", "INDEX", "NSE", "BANKNIFTY", 51840.90, 51500.00, 52020.00, 51420.00, 51550.00, 290.90, 0.56, lotSize = 15))
        list.add(InstrumentEntity("FINNIFTY", "Nifty Financial Services", "INDEX", "NSE", "NONE", 23920.10, 23800.00, 24010.00, 23780.00, 23810.00, 110.10, 0.46, lotSize = 25))
        list.add(InstrumentEntity("MIDCPNIFTY", "Nifty Midcap Select", "INDEX", "NSE", "NONE", 13150.75, 13080.00, 13200.00, 13050.00, 13075.00, 75.75, 0.58, lotSize = 50))

        // 2. All 50 NIFTY Constituent Stocks (also covering SENSEX and BANKNIFTY where applicable)
        val nifty50Stocks = listOf(
            Triple("RELIANCE", "Reliance Industries Ltd", 3012.40),
            Triple("TCS", "Tata Consultancy Services Ltd", 4485.60),
            Triple("HDFCBANK", "HDFC Bank Ltd", 1664.20),
            Triple("INFY", "Infosys Ltd", 1935.80),
            Triple("ICICIBANK", "ICICI Bank Ltd", 1248.50),
            Triple("SBIN", "State Bank of India", 824.70),
            Triple("BHARTIARTL", "Bharti Airtel Ltd", 1585.30),
            Triple("ITC", "ITC Ltd", 512.90),
            Triple("KOTAKBANK", "Kotak Mahindra Bank Ltd", 1820.40),
            Triple("LT", "Larsen & Toubro Ltd", 3740.10),
            Triple("HINDUNILVR", "Hindustan Unilever Ltd", 2835.60),
            Triple("AXISBANK", "Axis Bank Ltd", 1198.70),
            Triple("TATAMOTORS", "Tata Motors Ltd", 1085.25),
            Triple("MARUTI", "Maruti Suzuki India Ltd", 12540.00),
            Triple("SUNPHARMA", "Sun Pharmaceutical Ind Ltd", 1865.40),
            Triple("BAJFINANCE", "Bajaj Finance Ltd", 7420.00),
            Triple("TITAN", "Titan Company Ltd", 3640.80),
            Triple("TATASTEEL", "Tata Steel Ltd", 158.40),
            Triple("NTPC", "NTPC Ltd", 412.30),
            Triple("POWERGRID", "Power Grid Corp of India Ltd", 342.10),
            Triple("ASIANPAINT", "Asian Paints Ltd", 3240.50),
            Triple("M&M", "Mahindra & Mahindra Ltd", 2810.90),
            Triple("ADANIENT", "Adani Enterprises Ltd", 3120.00),
            Triple("ADANIPORTS", "Adani Ports and SEZ Ltd", 1485.60),
            Triple("ULTRACEMCO", "UltraTech Cement Ltd", 11450.00),
            Triple("COALINDIA", "Coal India Ltd", 518.20),
            Triple("BAJAJFINSV", "Bajaj Finserv Ltd", 1890.30),
            Triple("NESTLEIND", "Nestle India Ltd", 2540.00),
            Triple("JSWSTEEL", "JSW Steel Ltd", 965.80),
            Triple("TECHM", "Tech Mahindra Ltd", 1620.40),
            Triple("ONGC", "Oil & Natural Gas Corp Ltd", 312.40),
            Triple("HCLTECH", "HCL Technologies Ltd", 1785.60),
            Triple("WIPRO", "Wipro Ltd", 535.20),
            Triple("TRENT", "Trent Ltd", 7120.00),
            Triple("BEL", "Bharat Electronics Ltd", 310.40),
            Triple("BPCL", "Bharat Petroleum Corp Ltd", 358.90),
            Triple("GRASIM", "Grasim Industries Ltd", 2680.00),
            Triple("CIPLA", "Cipla Ltd", 1640.50),
            Triple("DRREDDY", "Dr. Reddy's Laboratories Ltd", 6850.00),
            Triple("EICHERMOT", "Eicher Motors Ltd", 4980.20),
            Triple("HINDALCO", "Hindalco Industries Ltd", 710.60),
            Triple("HEROMOTOCO", "Hero MotoCorp Ltd", 5640.00),
            Triple("APOLLOHOSP", "Apollo Hospitals Enterprise", 6980.00),
            Triple("DIVISLAB", "Divi's Laboratories Ltd", 5240.00),
            Triple("SBILIFE", "SBI Life Insurance Co Ltd", 1795.00),
            Triple("HDFCLIFE", "HDFC Life Insurance Co Ltd", 735.40),
            Triple("BRITANNIA", "Britannia Industries Ltd", 6020.00),
            Triple("SHRIRAMFIN", "Shriram Finance Ltd", 3350.00),
            Triple("TATACONSUM", "Tata Consumer Products Ltd", 1180.50),
            Triple("INDUSINDBK", "IndusInd Bank Ltd", 1445.80)
        )

        val sensexList = setOf("RELIANCE", "TCS", "HDFCBANK", "INFY", "ICICIBANK", "SBIN", "BHARTIARTL", "ITC", "KOTAKBANK", "LT", "HINDUNILVR", "AXISBANK", "TATAMOTORS", "MARUTI", "SUNPHARMA", "BAJFINANCE", "TITAN", "TATASTEEL", "NTPC", "POWERGRID", "ASIANPAINT", "M&M", "ADANIPORTS", "ULTRACEMCO", "BAJAJFINSV", "NESTLEIND", "JSWSTEEL", "TECHM", "HCLTECH", "WIPRO")
        val bankNiftyList = setOf("HDFCBANK", "ICICIBANK", "SBIN", "KOTAKBANK", "AXISBANK", "INDUSINDBK")

        for (stock in nifty50Stocks) {
            val basePrice = stock.third
            val changePercent = (Random.nextDouble(-2.5, 3.2)).let { Math.round(it * 100.0) / 100.0 }
            val change = Math.round((basePrice * changePercent / 100.0) * 100.0) / 100.0
            val open = basePrice - change * 0.4
            val high = basePrice + Math.abs(change) * 0.8 + 2.0
            val low = basePrice - Math.abs(change) * 0.8 - 2.0
            val close = basePrice - change

            var indexCat = "NIFTY 50"
            if (bankNiftyList.contains(stock.first)) {
                indexCat = "BANKNIFTY"
            } else if (sensexList.contains(stock.first)) {
                indexCat = "SENSEX"
            }

            list.add(
                InstrumentEntity(
                    symbol = stock.first,
                    name = stock.second,
                    segment = "CASH",
                    exchange = "NSE",
                    indexCategory = indexCat,
                    ltp = basePrice,
                    openPrice = Math.round(open * 100.0) / 100.0,
                    highPrice = Math.round(high * 100.0) / 100.0,
                    lowPrice = Math.round(low * 100.0) / 100.0,
                    closePrice = Math.round(close * 100.0) / 100.0,
                    change = change,
                    changePercent = changePercent,
                    volume = Random.nextLong(350000, 8500000),
                    lotSize = 1,
                    isConstituent = true
                )
            )
        }

        // 3. Additional BANKNIFTY constituents (Mid-tier banks)
        val otherBanks = listOf(
            Triple("PNB", "Punjab National Bank", 112.40),
            Triple("BANKBARODA", "Bank of Baroda", 254.60),
            Triple("FEDERALBNK", "The Federal Bank Ltd", 198.30),
            Triple("IDFCFIRSTB", "IDFC First Bank Ltd", 74.80),
            Triple("AUBANK", "AU Small Finance Bank Ltd", 645.00),
            Triple("BANDHANBNK", "Bandhan Bank Ltd", 204.50)
        )
        for (b in otherBanks) {
            list.add(
                InstrumentEntity(
                    symbol = b.first,
                    name = b.second,
                    segment = "CASH",
                    exchange = "NSE",
                    indexCategory = "BANKNIFTY",
                    ltp = b.third,
                    openPrice = b.third * 0.99,
                    highPrice = b.third * 1.02,
                    lowPrice = b.third * 0.985,
                    closePrice = b.third * 0.992,
                    change = 1.2,
                    changePercent = 0.8,
                    volume = 2400000,
                    lotSize = 1
                )
            )
        }

        // 4. Commodities (MCX Market)
        list.add(InstrumentEntity("GOLD", "Gold 1KG (995 Purity)", "COMMODITY", "MCX", "COMMODITY", 74850.00, 74500.00, 75100.00, 74300.00, 74450.00, 400.00, 0.54, lotSize = 1, tickSize = 1.0))
        list.add(InstrumentEntity("SILVER", "Silver 30KG", "COMMODITY", "MCX", "COMMODITY", 88420.00, 87900.00, 89100.00, 87600.00, 87800.00, 620.00, 0.71, lotSize = 30, tickSize = 1.0))
        list.add(InstrumentEntity("CRUDEOIL", "Crude Oil 100 BBL", "COMMODITY", "MCX", "COMMODITY", 6245.00, 6180.00, 6310.00, 6150.00, 6190.00, 55.00, 0.89, lotSize = 100, tickSize = 1.0))
        list.add(InstrumentEntity("NATURALGAS", "Natural Gas 1250 MMBTU", "COMMODITY", "MCX", "COMMODITY", 195.40, 192.00, 198.50, 190.20, 191.80, 3.60, 1.88, lotSize = 1250, tickSize = 0.10))
        list.add(InstrumentEntity("COPPER", "Copper 2500 KGS", "COMMODITY", "MCX", "COMMODITY", 824.50, 819.00, 829.00, 817.00, 818.50, 6.00, 0.73, lotSize = 2500, tickSize = 0.05))
        list.add(InstrumentEntity("ZINC", "Zinc 5000 KGS", "COMMODITY", "MCX", "COMMODITY", 278.30, 275.00, 281.00, 274.00, 276.00, 2.30, 0.83, lotSize = 5000, tickSize = 0.05))

        // 5. Index Futures
        list.add(InstrumentEntity("NIFTY-FUT", "NIFTY Near-Month Futures", "FNO_INDEX", "NSE", "NIFTY 50", 25425.00, 25300.00, 25480.00, 25270.00, 25310.00, 115.00, 0.45, lotSize = 25, expiry = "28 SEP 2026"))
        list.add(InstrumentEntity("BANKNIFTY-FUT", "BANKNIFTY Near-Month Futures", "FNO_INDEX", "NSE", "BANKNIFTY", 51960.00, 51600.00, 52150.00, 51500.00, 51640.00, 320.00, 0.62, lotSize = 15, expiry = "28 SEP 2026"))
        list.add(InstrumentEntity("SENSEX-FUT", "SENSEX Near-Month Futures", "FNO_INDEX", "BSE", "SENSEX", 83100.00, 82800.00, 83300.00, 82700.00, 82750.00, 350.00, 0.42, lotSize = 10, expiry = "28 SEP 2026"))

        // 6. Stock Futures
        list.add(InstrumentEntity("RELIANCE-FUT", "RELIANCE Near-Month Futures", "FNO_STOCK", "NSE", "NIFTY 50", 3022.00, 2990.00, 3040.00, 2980.00, 3000.00, 22.00, 0.73, lotSize = 250, expiry = "28 SEP 2026"))
        list.add(InstrumentEntity("TCS-FUT", "TCS Near-Month Futures", "FNO_STOCK", "NSE", "NIFTY 50", 4505.00, 4460.00, 4530.00, 4450.00, 4470.00, 35.00, 0.78, lotSize = 175, expiry = "28 SEP 2026"))
        list.add(InstrumentEntity("HDFCBANK-FUT", "HDFCBANK Near-Month Futures", "FNO_STOCK", "NSE", "BANKNIFTY", 1672.00, 1655.00, 1680.00, 1650.00, 1658.00, 14.00, 0.84, lotSize = 550, expiry = "28 SEP 2026"))

        // 7. Commodity Futures
        list.add(InstrumentEntity("GOLD-FUT", "GOLD Near-Month Futures", "COMMODITY", "MCX", "COMMODITY", 75100.00, 74700.00, 75350.00, 74500.00, 74650.00, 450.00, 0.60, lotSize = 1, expiry = "05 OCT 2026"))
        list.add(InstrumentEntity("CRUDEOIL-FUT", "CRUDEOIL Near-Month Futures", "COMMODITY", "MCX", "COMMODITY", 6270.00, 6200.00, 6340.00, 6180.00, 6210.00, 60.00, 0.97, lotSize = 100, expiry = "19 OCT 2026"))

        return list
    }

    fun getInitialOptionStrikes(): List<OptionStrikeEntity> {
        val list = mutableListOf<OptionStrikeEntity>()
        val expiry = "28 SEP 2026"

        // NIFTY Option Chain (Around ATM 25400)
        val niftyAtm = 25400.0
        for (i in -6..6) {
            val strike = niftyAtm + (i * 100)
            val dist = strike - niftyAtm
            // Realistic call/put premiums
            val callLtp = Math.max(12.5, 340.0 - dist * 0.75 + (if (dist < 0) -dist * 0.25 else 0.0))
            val putLtp = Math.max(12.5, 290.0 + dist * 0.75 + (if (dist > 0) dist * 0.25 else 0.0))
            val callOi = (1500000 - Math.abs(dist) * 2000).toLong().coerceAtLeast(120000)
            val putOi = (1650000 - Math.abs(dist) * 2200).toLong().coerceAtLeast(110000)

            list.add(
                OptionStrikeEntity(
                    underlyingSymbol = "NIFTY 50",
                    expiryDate = expiry,
                    strikePrice = strike,
                    callSymbol = "NIFTY24SEP${strike.toInt()}CE",
                    callLtp = Math.round(callLtp * 100.0) / 100.0,
                    callChange = Math.round((Random.nextDouble(-15.0, 22.0)) * 10.0) / 10.0,
                    callOi = callOi,
                    callIv = 14.2 + (Math.abs(dist) / 1000.0),
                    putSymbol = "NIFTY24SEP${strike.toInt()}PE",
                    putLtp = Math.round(putLtp * 100.0) / 100.0,
                    putChange = Math.round((Random.nextDouble(-20.0, 15.0)) * 10.0) / 10.0,
                    putOi = putOi,
                    putIv = 14.8 + (Math.abs(dist) / 1000.0)
                )
            )
        }

        // BANKNIFTY Option Chain (Around ATM 51800)
        val bnfAtm = 51800.0
        for (i in -5..5) {
            val strike = bnfAtm + (i * 200)
            val dist = strike - bnfAtm
            val callLtp = Math.max(25.0, 520.0 - dist * 0.6)
            val putLtp = Math.max(25.0, 480.0 + dist * 0.6)

            list.add(
                OptionStrikeEntity(
                    underlyingSymbol = "BANKNIFTY",
                    expiryDate = expiry,
                    strikePrice = strike,
                    callSymbol = "BANKNIFTY24SEP${strike.toInt()}CE",
                    callLtp = Math.round(callLtp * 100.0) / 100.0,
                    callChange = Math.round((Random.nextDouble(-30.0, 45.0)) * 10.0) / 10.0,
                    callOi = (800000 - Math.abs(dist) * 1200).toLong().coerceAtLeast(65000),
                    callIv = 16.5,
                    putSymbol = "BANKNIFTY24SEP${strike.toInt()}PE",
                    putLtp = Math.round(putLtp * 100.0) / 100.0,
                    putChange = Math.round((Random.nextDouble(-45.0, 30.0)) * 10.0) / 10.0,
                    putOi = (920000 - Math.abs(dist) * 1300).toLong().coerceAtLeast(70000),
                    putIv = 17.1
                )
            )
        }

        // SENSEX Option Chain (Around ATM 83000)
        val sensexAtm = 83000.0
        for (i in -4..4) {
            val strike = sensexAtm + (i * 500)
            val dist = strike - sensexAtm
            val callLtp = Math.max(45.0, 780.0 - dist * 0.6)
            val putLtp = Math.max(45.0, 720.0 + dist * 0.6)

            list.add(
                OptionStrikeEntity(
                    underlyingSymbol = "SENSEX",
                    expiryDate = expiry,
                    strikePrice = strike,
                    callSymbol = "SENSEX24SEP${strike.toInt()}CE",
                    callLtp = Math.round(callLtp * 100.0) / 100.0,
                    callChange = 18.5,
                    callOi = 450000,
                    callIv = 13.8,
                    putSymbol = "SENSEX24SEP${strike.toInt()}PE",
                    putLtp = Math.round(putLtp * 100.0) / 100.0,
                    putChange = -15.0,
                    putOi = 510000,
                    putIv = 14.2
                )
            )
        }

        // Stock Option Chain: RELIANCE (Around ATM 3000)
        val relAtm = 3000.0
        for (i in -4..4) {
            val strike = relAtm + (i * 40)
            val dist = strike - relAtm
            val callLtp = Math.max(5.0, 68.0 - dist * 0.7)
            val putLtp = Math.max(5.0, 55.0 + dist * 0.7)

            list.add(
                OptionStrikeEntity(
                    underlyingSymbol = "RELIANCE",
                    expiryDate = expiry,
                    strikePrice = strike,
                    callSymbol = "RELIANCE24SEP${strike.toInt()}CE",
                    callLtp = Math.round(callLtp * 100.0) / 100.0,
                    callChange = 4.2,
                    callOi = 280000,
                    callIv = 21.0,
                    putSymbol = "RELIANCE24SEP${strike.toInt()}PE",
                    putLtp = Math.round(putLtp * 100.0) / 100.0,
                    putChange = -3.8,
                    putOi = 320000,
                    putIv = 22.4
                )
            )
        }

        // Commodity Option Chain: GOLD (Around ATM 75000) & CRUDEOIL (6200)
        val goldAtm = 75000.0
        for (i in -3..3) {
            val strike = goldAtm + (i * 500)
            val dist = strike - goldAtm
            val callLtp = Math.max(80.0, 850.0 - dist * 0.7)
            val putLtp = Math.max(80.0, 780.0 + dist * 0.7)

            list.add(
                OptionStrikeEntity(
                    underlyingSymbol = "GOLD",
                    expiryDate = "05 OCT 2026",
                    strikePrice = strike,
                    callSymbol = "GOLD24OCT${strike.toInt()}CE",
                    callLtp = Math.round(callLtp * 10.0) / 10.0,
                    callChange = 25.0,
                    callOi = 12000,
                    callIv = 12.5,
                    putSymbol = "GOLD24OCT${strike.toInt()}PE",
                    putLtp = Math.round(putLtp * 10.0) / 10.0,
                    putChange = -18.0,
                    putOi = 14500,
                    putIv = 13.0
                )
            )
        }

        val crudeAtm = 6200.0
        for (i in -3..3) {
            val strike = crudeAtm + (i * 100)
            val dist = strike - crudeAtm
            val callLtp = Math.max(15.0, 160.0 - dist * 0.6)
            val putLtp = Math.max(15.0, 140.0 + dist * 0.6)

            list.add(
                OptionStrikeEntity(
                    underlyingSymbol = "CRUDEOIL",
                    expiryDate = "19 OCT 2026",
                    strikePrice = strike,
                    callSymbol = "CRUDEOIL24OCT${strike.toInt()}CE",
                    callLtp = Math.round(callLtp * 10.0) / 10.0,
                    callChange = 8.5,
                    callOi = 45000,
                    callIv = 28.5,
                    putSymbol = "CRUDEOIL24OCT${strike.toInt()}PE",
                    putLtp = Math.round(putLtp * 10.0) / 10.0,
                    putChange = -7.2,
                    putOi = 48000,
                    putIv = 29.1
                )
            )
        }

        // SILVER Options (Around ATM 88500)
        val silverAtm = 88500.0
        for (i in -3..3) {
            val strike = silverAtm + (i * 1000)
            val dist = strike - silverAtm
            val callLtp = Math.max(90.0, 1200.0 - dist * 0.65)
            val putLtp = Math.max(90.0, 1100.0 + dist * 0.65)
            list.add(
                OptionStrikeEntity(
                    underlyingSymbol = "SILVER",
                    expiryDate = "05 OCT 2026",
                    strikePrice = strike,
                    callSymbol = "SILVER24OCT${strike.toInt()}CE",
                    callLtp = Math.round(callLtp * 10.0) / 10.0,
                    callChange = 32.0,
                    callOi = 8500,
                    callIv = 18.2,
                    putSymbol = "SILVER24OCT${strike.toInt()}PE",
                    putLtp = Math.round(putLtp * 10.0) / 10.0,
                    putChange = -24.0,
                    putOi = 9200,
                    putIv = 18.9
                )
            )
        }

        // NATURALGAS Options (Around ATM 195)
        val ngAtm = 195.0
        for (i in -3..3) {
            val strike = ngAtm + (i * 5)
            val dist = strike - ngAtm
            val callLtp = Math.max(1.5, 9.5 - dist * 0.55)
            val putLtp = Math.max(1.5, 8.2 + dist * 0.55)
            list.add(
                OptionStrikeEntity(
                    underlyingSymbol = "NATURALGAS",
                    expiryDate = "19 OCT 2026",
                    strikePrice = strike,
                    callSymbol = "NATGAS24OCT${strike.toInt()}CE",
                    callLtp = Math.round(callLtp * 10.0) / 10.0,
                    callChange = 0.8,
                    callOi = 22000,
                    callIv = 35.0,
                    putSymbol = "NATGAS24OCT${strike.toInt()}PE",
                    putLtp = Math.round(putLtp * 10.0) / 10.0,
                    putChange = -0.6,
                    putOi = 26000,
                    putIv = 36.5
                )
            )
        }

        // TCS Options (Around ATM 4500)
        val tcsAtm = 4500.0
        for (i in -3..3) {
            val strike = tcsAtm + (i * 50)
            val dist = strike - tcsAtm
            val callLtp = Math.max(10.0, 95.0 - dist * 0.6)
            val putLtp = Math.max(10.0, 80.0 + dist * 0.6)
            list.add(
                OptionStrikeEntity(
                    underlyingSymbol = "TCS",
                    expiryDate = expiry,
                    strikePrice = strike,
                    callSymbol = "TCS24SEP${strike.toInt()}CE",
                    callLtp = Math.round(callLtp * 100.0) / 100.0,
                    callChange = 6.4,
                    callOi = 160000,
                    callIv = 19.5,
                    putSymbol = "TCS24SEP${strike.toInt()}PE",
                    putLtp = Math.round(putLtp * 100.0) / 100.0,
                    putChange = -5.2,
                    putOi = 185000,
                    putIv = 20.1
                )
            )
        }

        // HDFCBANK Options (Around ATM 1660)
        val hdfcAtm = 1660.0
        for (i in -3..3) {
            val strike = hdfcAtm + (i * 20)
            val dist = strike - hdfcAtm
            val callLtp = Math.max(4.0, 38.0 - dist * 0.6)
            val putLtp = Math.max(4.0, 32.0 + dist * 0.6)
            list.add(
                OptionStrikeEntity(
                    underlyingSymbol = "HDFCBANK",
                    expiryDate = expiry,
                    strikePrice = strike,
                    callSymbol = "HDFCBANK24SEP${strike.toInt()}CE",
                    callLtp = Math.round(callLtp * 100.0) / 100.0,
                    callChange = 2.8,
                    callOi = 420000,
                    callIv = 18.0,
                    putSymbol = "HDFCBANK24SEP${strike.toInt()}PE",
                    putLtp = Math.round(putLtp * 100.0) / 100.0,
                    putChange = -2.1,
                    putOi = 490000,
                    putIv = 18.5
                )
            )
        }

        // INFY Options (Around ATM 1940)
        val infyAtm = 1940.0
        for (i in -3..3) {
            val strike = infyAtm + (i * 20)
            val dist = strike - infyAtm
            val callLtp = Math.max(5.0, 42.0 - dist * 0.6)
            val putLtp = Math.max(5.0, 36.0 + dist * 0.6)
            list.add(
                OptionStrikeEntity(
                    underlyingSymbol = "INFY",
                    expiryDate = expiry,
                    strikePrice = strike,
                    callSymbol = "INFY24SEP${strike.toInt()}CE",
                    callLtp = Math.round(callLtp * 100.0) / 100.0,
                    callChange = 3.2,
                    callOi = 310000,
                    callIv = 22.0,
                    putSymbol = "INFY24SEP${strike.toInt()}PE",
                    putLtp = Math.round(putLtp * 100.0) / 100.0,
                    putChange = -2.9,
                    putOi = 340000,
                    putIv = 22.8
                )
            )
        }

        return list
    }

    fun getInitialHoldings(): List<HoldingEntity> {
        return listOf(
            HoldingEntity(
                id = 1,
                userId = 1,
                symbol = "RELIANCE",
                name = "Reliance Industries Ltd",
                quantity = 25,
                averageBuyPrice = 2840.00,
                ltp = 3012.40,
                investedValue = 71000.00,
                currentValue = 75310.00,
                pnl = 4310.00,
                pnlPercent = 6.07
            ),
            HoldingEntity(
                id = 2,
                userId = 1,
                symbol = "TCS",
                name = "Tata Consultancy Services Ltd",
                quantity = 15,
                averageBuyPrice = 4210.00,
                ltp = 4485.60,
                investedValue = 63150.00,
                currentValue = 67284.00,
                pnl = 4134.00,
                pnlPercent = 6.55
            ),
            HoldingEntity(
                id = 3,
                userId = 1,
                symbol = "HDFCBANK",
                name = "HDFC Bank Ltd",
                quantity = 40,
                averageBuyPrice = 1680.00,
                ltp = 1664.20,
                investedValue = 67200.00,
                currentValue = 66568.00,
                pnl = -632.00,
                pnlPercent = -0.94
            )
        )
    }

    fun getInitialPositions(): List<PositionEntity> {
        return listOf(
            PositionEntity(
                id = 1,
                userId = 1,
                symbol = "NIFTY24SEP25400CE",
                name = "NIFTY 28 SEP 25400 CE",
                segment = "FNO_INDEX",
                productType = "INTRADAY",
                side = "BUY",
                quantity = 50,
                averageBuyPrice = 182.50,
                ltp = 215.80,
                pnl = 1665.00,
                pnlPercent = 18.25,
                isOpen = true
            ),
            PositionEntity(
                id = 2,
                userId = 1,
                symbol = "GOLD24OCTFUT",
                name = "GOLD 05 OCT FUT",
                segment = "COMMODITY",
                productType = "NORMAL",
                side = "BUY",
                quantity = 1,
                averageBuyPrice = 74600.00,
                ltp = 75100.00,
                pnl = 500.00,
                pnlPercent = 0.67,
                isOpen = true
            )
        )
    }

    fun getInitialOrders(): List<OrderEntity> {
        return listOf(
            OrderEntity(
                id = 1,
                userId = 1,
                symbol = "NIFTY24SEP25400CE",
                name = "NIFTY 28 SEP 25400 CE",
                segment = "FNO_INDEX",
                orderType = "MARKET",
                productType = "INTRADAY",
                side = "BUY",
                quantity = 50,
                price = 182.50,
                executedPrice = 182.50,
                status = "EXECUTED",
                statusReason = "Completed in simulated exchange"
            ),
            OrderEntity(
                id = 2,
                userId = 1,
                symbol = "GOLD24OCTFUT",
                name = "GOLD 05 OCT FUT",
                segment = "COMMODITY",
                orderType = "LIMIT",
                productType = "NORMAL",
                side = "BUY",
                quantity = 1,
                price = 74600.00,
                executedPrice = 74600.00,
                status = "EXECUTED"
            ),
            OrderEntity(
                id = 3,
                userId = 1,
                symbol = "INFY",
                name = "Infosys Ltd",
                segment = "CASH",
                orderType = "LIMIT",
                productType = "DELIVERY",
                side = "BUY",
                quantity = 20,
                price = 1910.00,
                executedPrice = 0.0,
                status = "PENDING",
                statusReason = "Waiting for LTP <= 1910.00"
            )
        )
    }

    fun getInitialTransactions(): List<TransactionEntity> {
        return listOf(
            TransactionEntity(
                id = 1,
                userId = 1,
                type = "DEPOSIT",
                amount = 500000.0,
                status = "SUCCESS",
                utrOrRef = "UPI/DEMO/498273918234",
                bankAccount = "HDFC Bank (Demo Escrow)",
                remarks = "Welcome Demo Trading Capital Credited"
            ),
            TransactionEntity(
                id = 2,
                userId = 3,
                type = "DEPOSIT",
                amount = 250000.0,
                status = "PENDING",
                utrOrRef = "IMPS/DEMO/9981240182",
                bankAccount = "ICICI Bank (Demo Instant)",
                remarks = "Awaiting Admin Approval"
            )
        )
    }

    fun getInitialNotifications(): List<NotificationEntity> {
        return listOf(
            NotificationEntity(
                id = 1,
                userId = 1,
                title = "Welcome to Kunal Trader!",
                message = "Your demo trading account has been credited with ₹5,00,000 virtual margin. Explore Cash, F&O, and Commodities.",
                category = "SYSTEM"
            ),
            NotificationEntity(
                id = 2,
                userId = 1,
                title = "Order Executed",
                message = "BUY order for 50 Qty of NIFTY24SEP25400CE @ ₹182.50 was executed successfully.",
                category = "TRADE"
            ),
            NotificationEntity(
                id = 3,
                userId = 0,
                title = "Market Update",
                message = "Indian benchmark indices hit fresh highs with NIFTY crossing 25,350 and SENSEX testing 83,000.",
                category = "ALERT"
            )
        )
    }

    fun getInitialAuditLogs(): List<AuditLogEntity> {
        return listOf(
            AuditLogEntity(
                id = 1,
                adminId = 2,
                adminUsername = "admin_master",
                action = "SYSTEM_INITIALIZE",
                targetType = "SYSTEM",
                targetId = "0",
                reason = "Initial seed of instruments, indices, and demo users",
                details = "Seeded 50+ Nifty stocks, Sensex, BankNifty, and MCX commodities."
            )
        )
    }

    fun getInitialWatchlist(): List<WatchlistItemEntity> {
        return listOf(
            WatchlistItemEntity(id = 1, userId = 1, symbol = "NIFTY 50"),
            WatchlistItemEntity(id = 2, userId = 1, symbol = "BANKNIFTY"),
            WatchlistItemEntity(id = 3, userId = 1, symbol = "RELIANCE"),
            WatchlistItemEntity(id = 4, userId = 1, symbol = "TCS"),
            WatchlistItemEntity(id = 5, userId = 1, symbol = "HDFCBANK"),
            WatchlistItemEntity(id = 6, userId = 1, symbol = "GOLD"),
            WatchlistItemEntity(id = 7, userId = 1, symbol = "CRUDEOIL")
        )
    }
}
